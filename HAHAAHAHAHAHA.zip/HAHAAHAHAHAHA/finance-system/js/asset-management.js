class AssetManagementAPI {
    static async fetchAssetSummary() {
        // Simulated API call to get asset summary
        return {
            totalAssets: 2500000,
            netBookValue: 1800000,
            totalDepreciation: 700000,
            assetCount: 245,
            maintenanceDue: 12
        };
    }

    static async fetchAssetCategories() {
        // Simulated API call to get asset categories
        return [
            {
                name: "Buildings",
                value: 1200000,
                count: 3,
                depreciation: 180000
            },
            {
                name: "Equipment",
                value: 800000,
                count: 150,
                depreciation: 320000
            },
            {
                name: "Vehicles",
                value: 300000,
                count: 12,
                depreciation: 120000
            },
            {
                name: "IT Assets",
                value: 200000,
                count: 80,
                depreciation: 80000
            }
        ];
    }

    static async fetchAssetList() {
        // Simulated API call to get asset list
        return [
            {
                id: "AST001",
                name: "Main Office Building",
                category: "Buildings",
                purchaseDate: "2020-01-15",
                cost: 1000000,
                currentValue: 850000,
                status: "Active",
                location: "HQ"
            },
            {
                id: "AST145",
                name: "Production Line A",
                category: "Equipment",
                purchaseDate: "2023-06-01",
                cost: 500000,
                currentValue: 450000,
                status: "Active",
                location: "Factory 1"
            }
        ];
    }

    static async fetchRecentActivities() {
        // Simulated API call to get recent activities
        return [
            {
                date: "2025-08-14",
                type: "Maintenance",
                asset: "Production Line A",
                description: "Regular maintenance completed",
                cost: 5000
            },
            {
                date: "2025-08-13",
                type: "Disposal",
                asset: "Company Vehicle #5",
                description: "Vehicle sold",
                amount: 25000
            }
        ];
    }

    static async fetchMaintenanceSchedule() {
        // Simulated API call to get maintenance schedule
        return [
            {
                asset: "Production Line A",
                dueDate: "2025-08-20",
                type: "Regular Maintenance",
                estimatedCost: 5000,
                priority: "High"
            },
            {
                asset: "HVAC System",
                dueDate: "2025-09-01",
                type: "Annual Service",
                estimatedCost: 3000,
                priority: "Medium"
            }
        ];
    }
}

class AssetManagementManager {
    constructor() {
        this.showLoadingStates();
        this.initialize();
    }

    showLoadingStates() {
        const sections = [
            'asset-summary',
            'asset-categories',
            'asset-list',
            'recent-activities',
            'maintenance-schedule'
        ];
        
        sections.forEach(id => {
            const element = document.getElementById(id);
            element.innerHTML = '<div class="loading"></div>';
        });
    }

    async initialize() {
        await Promise.all([
            this.updateAssetSummary(),
            this.updateAssetCategories(),
            this.updateAssetList(),
            this.updateRecentActivities(),
            this.updateMaintenanceSchedule()
        ]);
    }

    async updateAssetSummary() {
        try {
            const data = await AssetManagementAPI.fetchAssetSummary();
            const summaryDiv = document.getElementById('asset-summary');
            
            summaryDiv.innerHTML = `
                <div class="financial-metrics">
                    <div class="metric">
                        <h3>Total Assets Value</h3>
                        <p>$${data.totalAssets.toLocaleString()}</p>
                    </div>
                    <div class="metric">
                        <h3>Net Book Value</h3>
                        <p>$${data.netBookValue.toLocaleString()}</p>
                    </div>
                    <div class="metric">
                        <h3>Total Depreciation</h3>
                        <p>$${data.totalDepreciation.toLocaleString()}</p>
                    </div>
                    <div class="metric">
                        <h3>Asset Count</h3>
                        <p>${data.assetCount}</p>
                    </div>
                    <div class="metric ${data.maintenanceDue > 0 ? 'warning' : ''}">
                        <h3>Maintenance Due</h3>
                        <p>${data.maintenanceDue}</p>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error updating asset summary:', error);
        }
    }

    async updateAssetCategories() {
        try {
            const categories = await AssetManagementAPI.fetchAssetCategories();
            const categoriesDiv = document.getElementById('asset-categories');
            
            categoriesDiv.innerHTML = `
                <div class="asset-categories">
                    ${categories.map(category => `
                        <div class="category-card">
                            <div class="category-header">
                                <h3>${category.name}</h3>
                                <span class="asset-count">${category.count} assets</span>
                            </div>
                            <div class="category-details">
                                <div class="detail">
                                    <span class="label">Value:</span>
                                    <span class="value">$${category.value.toLocaleString()}</span>
                                </div>
                                <div class="detail">
                                    <span class="label">Depreciation:</span>
                                    <span class="value">$${category.depreciation.toLocaleString()}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error updating asset categories:', error);
        }
    }

    async updateAssetList() {
        try {
            const assets = await AssetManagementAPI.fetchAssetList();
            const listDiv = document.getElementById('asset-list');
            
            listDiv.innerHTML = `
                <div class="asset-filters">
                    <button class="filter-btn active" data-status="all">All</button>
                    <button class="filter-btn" data-status="Active">Active</button>
                    <button class="filter-btn" data-status="Maintenance">Maintenance</button>
                    <button class="filter-btn" data-status="Disposed">Disposed</button>
                </div>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Asset ID</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Purchase Date</th>
                            <th>Cost</th>
                            <th>Current Value</th>
                            <th>Status</th>
                            <th>Location</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${assets.map(asset => `
                            <tr class="asset-row" data-status="${asset.status}">
                                <td>${asset.id}</td>
                                <td>${asset.name}</td>
                                <td>${asset.category}</td>
                                <td>${new Date(asset.purchaseDate).toLocaleDateString()}</td>
                                <td>$${asset.cost.toLocaleString()}</td>
                                <td>$${asset.currentValue.toLocaleString()}</td>
                                <td><span class="status-badge ${asset.status.toLowerCase()}">${asset.status}</span></td>
                                <td>${asset.location}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;

            // Add event listeners for asset filters
            const filters = listDiv.querySelectorAll('.filter-btn');
            filters.forEach(btn => {
                btn.addEventListener('click', () => {
                    filters.forEach(f => f.classList.remove('active'));
                    btn.classList.add('active');
                    const status = btn.dataset.status;
                    const rows = listDiv.querySelectorAll('.asset-row');
                    rows.forEach(row => {
                        if (status === 'all' || row.dataset.status === status) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    });
                });
            });
        } catch (error) {
            console.error('Error updating asset list:', error);
        }
    }

    async updateRecentActivities() {
        try {
            const activities = await AssetManagementAPI.fetchRecentActivities();
            const activitiesDiv = document.getElementById('recent-activities');
            
            activitiesDiv.innerHTML = `
                <div class="activities-list">
                    ${activities.map(activity => `
                        <div class="activity-item">
                            <div class="activity-icon ${activity.type.toLowerCase()}">
                                <i class="fas ${
                                    activity.type === 'Maintenance' ? 'fa-tools' :
                                    activity.type === 'Disposal' ? 'fa-trash-alt' :
                                    'fa-info-circle'
                                }"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-header">
                                    <span class="activity-date">${new Date(activity.date).toLocaleDateString()}</span>
                                    <span class="activity-type">${activity.type}</span>
                                </div>
                                <div class="activity-asset">${activity.asset}</div>
                                <div class="activity-description">${activity.description}</div>
                                <div class="activity-amount">
                                    ${activity.cost ? 
                                        `Cost: $${activity.cost.toLocaleString()}` : 
                                        `Amount: $${activity.amount.toLocaleString()}`
                                    }
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error updating recent activities:', error);
        }
    }

    async updateMaintenanceSchedule() {
        try {
            const schedule = await AssetManagementAPI.fetchMaintenanceSchedule();
            const scheduleDiv = document.getElementById('maintenance-schedule');
            
            scheduleDiv.innerHTML = `
                <div class="maintenance-list">
                    ${schedule.map(item => `
                        <div class="maintenance-item ${item.priority.toLowerCase()}">
                            <div class="maintenance-header">
                                <h3>${item.asset}</h3>
                                <span class="priority-badge ${item.priority.toLowerCase()}">
                                    ${item.priority}
                                </span>
                            </div>
                            <div class="maintenance-details">
                                <div class="detail">
                                    <i class="fas fa-calendar"></i>
                                    ${new Date(item.dueDate).toLocaleDateString()}
                                </div>
                                <div class="detail">
                                    <i class="fas fa-tools"></i>
                                    ${item.type}
                                </div>
                                <div class="detail">
                                    <i class="fas fa-money-bill"></i>
                                    $${item.estimatedCost.toLocaleString()}
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error updating maintenance schedule:', error);
        }
    }
}

// Add some specific styles for asset management
const styles = `
    .asset-categories {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
    }

    .category-card {
        background: var(--card-bg);
        border-radius: calc(var(--border-radius) - 4px);
        padding: 16px;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .category-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
    }

    .category-header h3 {
        margin: 0;
        font-size: 1.1rem;
    }

    .asset-count {
        font-size: 0.9rem;
        color: var(--primary-color);
        font-weight: 500;
    }

    .category-details {
        display: grid;
        gap: 8px;
    }

    .detail {
        display: flex;
        justify-content: space-between;
        font-size: 0.9rem;
    }

    .detail .label {
        color: var(--text-color);
        opacity: 0.7;
    }

    .detail .value {
        font-weight: 500;
    }

    .status-badge {
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.9rem;
        font-weight: 500;
    }

    .status-badge.active { background: var(--success-color); color: white; }
    .status-badge.maintenance { background: var(--warning-color); color: var(--text-color); }
    .status-badge.disposed { background: var(--danger-color); color: white; }

    .activities-list {
        display: grid;
        gap: 16px;
    }

    .activity-item {
        display: flex;
        gap: 16px;
        padding: 12px;
        background: var(--card-bg);
        border-radius: calc(var(--border-radius) - 4px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .activity-icon {
        width: 40px;
        height: 40px;
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
    }

    .activity-icon.maintenance { background: var(--warning-color); }
    .activity-icon.disposal { background: var(--danger-color); }

    .activity-content {
        flex: 1;
    }

    .activity-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 4px;
    }

    .activity-date {
        font-size: 0.9rem;
        color: var(--text-color);
        opacity: 0.7;
    }

    .activity-type {
        font-size: 0.9rem;
        font-weight: 500;
    }

    .activity-asset {
        font-weight: 500;
        margin-bottom: 4px;
    }

    .activity-description {
        font-size: 0.9rem;
        color: var(--text-color);
        opacity: 0.8;
        margin-bottom: 4px;
    }

    .activity-amount {
        font-size: 0.9rem;
        color: var(--primary-color);
        font-weight: 500;
    }

    .maintenance-list {
        display: grid;
        gap: 16px;
    }

    .maintenance-item {
        background: var(--card-bg);
        border-radius: calc(var(--border-radius) - 4px);
        padding: 16px;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .maintenance-item.high { border-left: 4px solid var(--danger-color); }
    .maintenance-item.medium { border-left: 4px solid var(--warning-color); }
    .maintenance-item.low { border-left: 4px solid var(--success-color); }

    .maintenance-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
    }

    .maintenance-header h3 {
        margin: 0;
        font-size: 1.1rem;
    }

    .priority-badge {
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: 500;
    }

    .priority-badge.high { background: var(--danger-color); color: white; }
    .priority-badge.medium { background: var(--warning-color); color: var(--text-color); }
    .priority-badge.low { background: var(--success-color); color: white; }

    .maintenance-details {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
    }

    .maintenance-details .detail {
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .maintenance-details .detail i {
        color: var(--primary-color);
        opacity: 0.8;
    }

    .full-width {
        grid-column: 1 / -1;
    }
`;

// Add styles to the document
const styleSheet = document.createElement("style");
styleSheet.textContent = styles;
document.head.appendChild(styleSheet);

// Initialize asset management when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.assetManager = new AssetManagementManager();
});
