class PayrollAPI {
    static async getSummary() {
        // Simulated API call for payroll summary
        return {
            totalEmployees: 156,
            monthlyPayroll: 875000,
            averageSalary: 67500,
            payrollTrend: '+2.3%'
        };
    }

    static async getNextPayroll() {
        // Simulated API call for next payroll information
        return {
            date: '2025-08-31',
            totalAmount: 875000,
            employeeCount: 156,
            status: 'pending'
        };
    }

    static async getEmployeeList() {
        // Simulated API call for employee list
        return [
            {
                id: 'EMP001',
                name: 'John Smith',
                department: 'Engineering',
                position: 'Senior Developer',
                salary: 85000,
                status: 'active'
            },
            // Add more employee data...
        ];
    }

    static async getDepartmentAnalysis() {
        // Simulated API call for department analysis
        return {
            departments: [
                {
                    name: 'Engineering',
                    headcount: 45,
                    totalPayroll: 380000,
                    averageSalary: 84444
                },
                // Add more department data...
            ]
        };
    }

    static async getPayrollHistory() {
        // Simulated API call for payroll history
        return [
            {
                date: '2025-07-31',
                totalAmount: 870000,
                employeeCount: 155,
                status: 'completed'
            },
            // Add more history data...
        ];
    }

    static async getTaxWithholdings() {
        // Simulated API call for tax withholdings
        return {
            federalTax: 175000,
            stateTax: 52500,
            socialSecurity: 70000,
            medicare: 17500
        };
    }

    static async getBenefitsOverview() {
        // Simulated API call for benefits overview
        return {
            healthInsurance: 87500,
            retirement401k: 43750,
            dental: 8750,
            vision: 4375
        };
    }
}

class PayrollManager {
    constructor() {
        this.initializeEventListeners();
        this.loadAllData();
    }

    initializeEventListeners() {
        // Add Employee button
        document.querySelector('.card-actions .primary').addEventListener('click', () => {
            // Implement new employee addition
            NotificationSystem.show('New employee form opened', 'info');
        });

        // Filter button
        document.querySelector('.action-btn').addEventListener('click', () => {
            // Implement filtering
            NotificationSystem.show('Filters applied', 'info');
        });
    }

    async loadAllData() {
        await Promise.all([
            this.loadPayrollSummary(),
            this.loadNextPayroll(),
            this.loadEmployeeList(),
            this.loadDepartmentAnalysis(),
            this.loadPayrollHistory(),
            this.loadTaxWithholdings(),
            this.loadBenefitsOverview()
        ]);
    }

    async loadPayrollSummary() {
        try {
            const data = await PayrollAPI.getSummary();
            document.getElementById('payroll-summary').innerHTML = `
                <div class="metrics-grid">
                    <div class="metric">
                        <span class="metric-label">Total Employees</span>
                        <span class="metric-value">${data.totalEmployees}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Monthly Payroll</span>
                        <span class="metric-value">$${this.formatNumber(data.monthlyPayroll)}</span>
                        <span class="metric-trend ${data.payrollTrend.startsWith('+') ? 'positive' : 'negative'}">
                            ${data.payrollTrend}
                        </span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Average Salary</span>
                        <span class="metric-value">$${this.formatNumber(data.averageSalary)}</span>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading payroll summary:', error);
            NotificationSystem.show('Failed to load payroll summary', 'error');
        }
    }

    async loadNextPayroll() {
        try {
            const data = await PayrollAPI.getNextPayroll();
            document.getElementById('next-payroll').innerHTML = `
                <div class="next-payroll-info">
                    <div class="date-banner">
                        <i class="fas fa-calendar"></i>
                        ${this.formatDate(data.date)}
                    </div>
                    <div class="payroll-details">
                        <div class="detail-item">
                            <span class="label">Total Amount:</span>
                            <span class="value">$${this.formatNumber(data.totalAmount)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Employees:</span>
                            <span class="value">${data.employeeCount}</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Status:</span>
                            <span class="status-badge ${data.status}">${data.status}</span>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading next payroll:', error);
            NotificationSystem.show('Failed to load next payroll information', 'error');
        }
    }

    async loadEmployeeList() {
        try {
            const employees = await PayrollAPI.getEmployeeList();
            document.getElementById('employee-list').innerHTML = `
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Position</th>
                            <th>Salary</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${employees.map(emp => `
                            <tr>
                                <td>${emp.id}</td>
                                <td>${emp.name}</td>
                                <td>${emp.department}</td>
                                <td>${emp.position}</td>
                                <td>$${this.formatNumber(emp.salary)}</td>
                                <td><span class="status-badge ${emp.status}">${emp.status}</span></td>
                                <td>
                                    <button class="icon-btn" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="icon-btn" title="Edit Employee">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        } catch (error) {
            console.error('Error loading employee list:', error);
            NotificationSystem.show('Failed to load employee list', 'error');
        }
    }

    async loadDepartmentAnalysis() {
        try {
            const data = await PayrollAPI.getDepartmentAnalysis();
            document.getElementById('department-analysis').innerHTML = `
                <div class="department-chart">
                    ${data.departments.map(dept => `
                        <div class="department-bar">
                            <div class="dept-header">
                                <span class="dept-name">${dept.name}</span>
                                <span class="dept-headcount">${dept.headcount} employees</span>
                            </div>
                            <div class="dept-metrics">
                                <div class="dept-metric">
                                    <span class="label">Total Payroll</span>
                                    <span class="value">$${this.formatNumber(dept.totalPayroll)}</span>
                                </div>
                                <div class="dept-metric">
                                    <span class="label">Average Salary</span>
                                    <span class="value">$${this.formatNumber(dept.averageSalary)}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading department analysis:', error);
            NotificationSystem.show('Failed to load department analysis', 'error');
        }
    }

    async loadPayrollHistory() {
        try {
            const history = await PayrollAPI.getPayrollHistory();
            document.getElementById('payroll-history').innerHTML = `
                <div class="history-list">
                    ${history.map(entry => `
                        <div class="history-item">
                            <div class="history-date">${this.formatDate(entry.date)}</div>
                            <div class="history-details">
                                <div class="detail-row">
                                    <span class="label">Amount:</span>
                                    <span class="value">$${this.formatNumber(entry.totalAmount)}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="label">Employees:</span>
                                    <span class="value">${entry.employeeCount}</span>
                                </div>
                            </div>
                            <div class="history-status">
                                <span class="status-badge ${entry.status}">${entry.status}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading payroll history:', error);
            NotificationSystem.show('Failed to load payroll history', 'error');
        }
    }

    async loadTaxWithholdings() {
        try {
            const data = await PayrollAPI.getTaxWithholdings();
            document.getElementById('tax-withholdings').innerHTML = `
                <div class="tax-breakdown">
                    ${Object.entries(data).map(([type, amount]) => `
                        <div class="tax-item">
                            <div class="tax-label">${this.formatTaxLabel(type)}</div>
                            <div class="tax-amount">$${this.formatNumber(amount)}</div>
                            <div class="tax-bar">
                                <div class="bar-fill" style="width: ${(amount / Object.values(data).reduce((a, b) => a + b)) * 100}%"></div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading tax withholdings:', error);
            NotificationSystem.show('Failed to load tax withholdings', 'error');
        }
    }

    async loadBenefitsOverview() {
        try {
            const data = await PayrollAPI.getBenefitsOverview();
            document.getElementById('benefits-overview').innerHTML = `
                <div class="benefits-grid">
                    ${Object.entries(data).map(([benefit, amount]) => `
                        <div class="benefit-card">
                            <div class="benefit-icon">
                                <i class="fas fa-${this.getBenefitIcon(benefit)}"></i>
                            </div>
                            <div class="benefit-details">
                                <div class="benefit-name">${this.formatBenefitLabel(benefit)}</div>
                                <div class="benefit-amount">$${this.formatNumber(amount)}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading benefits overview:', error);
            NotificationSystem.show('Failed to load benefits overview', 'error');
        }
    }

    formatNumber(number) {
        return new Intl.NumberFormat('en-US').format(number);
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    formatTaxLabel(key) {
        return key.split(/(?=[A-Z])/).join(' ').replace(/^\w/, c => c.toUpperCase());
    }

    formatBenefitLabel(key) {
        return key
            .replace(/([A-Z])/g, ' $1')
            .replace(/^\w/, c => c.toUpperCase())
            .replace('401k', '401(k)');
    }

    getBenefitIcon(benefit) {
        const icons = {
            healthInsurance: 'hospital',
            retirement401k: 'piggy-bank',
            dental: 'tooth',
            vision: 'eye'
        };
        return icons[benefit] || 'gift';
    }
}

// Initialize the manager when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PayrollManager();
});
