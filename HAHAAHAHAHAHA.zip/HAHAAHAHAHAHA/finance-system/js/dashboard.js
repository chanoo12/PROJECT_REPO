class DashboardAPI {
    static async getFinancialOverview() {
        // Aggregate data from all modules
        const [glData, payrollData, apArData, stockData] = await Promise.all([
            this.getFromGL(),
            this.getFromPayroll(),
            this.getFromAPAR(),
            this.getFromInventory()
        ]);

        const totalIncome = glData.revenue + apArData.receivables;
        const totalExpenses = payrollData.totalPayroll + apArData.payables + stockData.purchaseValue;
        const netSavings = totalIncome - totalExpenses;

        return {
            totalIncome: { value: totalIncome, trend: '+5.2%' },
            totalExpenses: { value: totalExpenses, trend: '+2.1%' },
            netSavings: { value: netSavings, trend: '+8.4%' },
            cashPosition: { value: glData.cashBalance, trend: '+3.2%' }
        };
    }

    static async getFromGL() {
        // Simulated GL data
        return {
            revenue: 2500000,
            expenses: 1800000,
            cashBalance: 850000,
            assets: 3500000,
            liabilities: 2000000,
            equity: 1500000
        };
    }

    static async getFromPayroll() {
        // Simulated payroll data
        return {
            totalPayroll: 750000,
            employeeCount: 156,
            nextPayroll: '2025-08-31',
            averageSalary: 67500,
            departments: {
                engineering: { count: 45, total: 380000 },
                sales: { count: 30, total: 225000 },
                operations: { count: 81, total: 145000 }
            }
        };
    }

    static async getFromAPAR() {
        // Simulated AP/AR data
        return {
            receivables: 450000,
            payables: 325000,
            overdueReceivables: 75000,
            overduePayables: 25000,
            nextDueDate: '2025-08-20',
            nextDueAmount: 50000
        };
    }

    static async getFromInventory() {
        // Simulated inventory data
        return {
            totalValue: 1250000,
            purchaseValue: 950000,
            itemCount: 2850,
            lowStockCount: 15,
            reorderNeeded: 8,
            lastMovement: '2025-08-14'
        };
    }

    static async getTaxDeadlines() {
        // Simulated tax deadline data
        return [
            {
                type: 'VAT',
                dueDate: '2025-09-30',
                amount: 125000,
                status: 'pending'
            },
            {
                type: 'Corporate Tax',
                dueDate: '2025-12-31',
                amount: 450000,
                status: 'upcoming'
            }
        ];
    }

    static async getBudgetSummary() {
        // Simulated budget data
        return {
            totalBudget: 2500000,
            spent: 1800000,
            remaining: 700000,
            departments: {
                engineering: { budget: 800000, spent: 650000 },
                sales: { budget: 500000, spent: 425000 },
                operations: { budget: 1200000, spent: 725000 }
            }
        };
    }
}

class DashboardManager {
    constructor() {
        this.initialize();
    }

    async initialize() {
        await Promise.all([
            this.loadFinancialOverview(),
            this.loadDepartmentSummaries(),
            this.loadOperationsOverview(),
            this.loadCriticalAlerts()
        ]);
    }

    async loadFinancialOverview() {
        try {
            const data = await DashboardAPI.getFinancialOverview();
            
            // Update Total Income
            this.updateMetricCard('total-income', {
                value: data.totalIncome.value,
                trend: data.totalIncome.trend,
                subtitle: 'Monthly Revenue'
            });

            // Update Total Expenses
            this.updateMetricCard('total-expenses', {
                value: data.totalExpenses.value,
                trend: data.totalExpenses.trend,
                subtitle: 'Monthly Expenses'
            });

            // Update Net Savings
            this.updateMetricCard('net-savings', {
                value: data.netSavings.value,
                trend: data.netSavings.trend,
                subtitle: 'Monthly Savings'
            });

            // Update Cash Position
            this.updateMetricCard('cash-position', {
                value: data.cashPosition.value,
                trend: data.cashPosition.trend,
                subtitle: 'Available Cash'
            });
        } catch (error) {
            console.error('Error loading financial overview:', error);
            NotificationSystem.show('Failed to load financial overview', 'error');
        }
    }

    async loadDepartmentSummaries() {
        try {
            const [glData, budgetData, taxData] = await Promise.all([
                DashboardAPI.getFromGL(),
                DashboardAPI.getBudgetSummary(),
                DashboardAPI.getTaxDeadlines()
            ]);

            // Update GL Summary
            document.getElementById('gl-summary').innerHTML = `
                <div class="metrics-grid">
                    <div class="metric">
                        <span class="metric-label">Total Assets</span>
                        <span class="metric-value">$${this.formatNumber(glData.assets)}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Total Liabilities</span>
                        <span class="metric-value">$${this.formatNumber(glData.liabilities)}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Equity</span>
                        <span class="metric-value">$${this.formatNumber(glData.equity)}</span>
                    </div>
                </div>
            `;

            // Update Budget Summary
            document.getElementById('budget-actual').innerHTML = `
                <div class="budget-progress">
                    <div class="progress-bar">
                        <div class="progress" style="width: ${(budgetData.spent / budgetData.totalBudget) * 100}%"></div>
                    </div>
                    <div class="budget-metrics">
                        <div class="metric">
                            <span class="metric-label">Total Budget</span>
                            <span class="metric-value">$${this.formatNumber(budgetData.totalBudget)}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Spent</span>
                            <span class="metric-value">$${this.formatNumber(budgetData.spent)}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Remaining</span>
                            <span class="metric-value">$${this.formatNumber(budgetData.remaining)}</span>
                        </div>
                    </div>
                </div>
            `;

            // Update Tax Summary
            document.getElementById('tax-summary').innerHTML = `
                <div class="tax-timeline">
                    ${taxData.map(tax => `
                        <div class="tax-item ${tax.status}">
                            <div class="tax-details">
                                <span class="tax-type">${tax.type}</span>
                                <span class="tax-amount">$${this.formatNumber(tax.amount)}</span>
                            </div>
                            <div class="tax-due-date">Due: ${this.formatDate(tax.dueDate)}</div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading department summaries:', error);
            NotificationSystem.show('Failed to load department summaries', 'error');
        }
    }

    async loadOperationsOverview() {
        try {
            const [payrollData, stockData, apArData] = await Promise.all([
                DashboardAPI.getFromPayroll(),
                DashboardAPI.getFromInventory(),
                DashboardAPI.getFromAPAR()
            ]);

            // Update Payroll Status
            document.getElementById('payroll-summary').innerHTML = `
                <div class="metrics-grid">
                    <div class="metric">
                        <span class="metric-label">Next Payroll</span>
                        <span class="metric-value">$${this.formatNumber(payrollData.totalPayroll)}</span>
                        <span class="metric-date">${this.formatDate(payrollData.nextPayroll)}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Employees</span>
                        <span class="metric-value">${payrollData.employeeCount}</span>
                    </div>
                </div>
            `;

            // Update Stock Summary
            document.getElementById('stock-summary').innerHTML = `
                <div class="metrics-grid">
                    <div class="metric">
                        <span class="metric-label">Total Value</span>
                        <span class="metric-value">$${this.formatNumber(stockData.totalValue)}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Items</span>
                        <span class="metric-value">${stockData.itemCount}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Low Stock</span>
                        <span class="metric-value warning">${stockData.lowStockCount}</span>
                    </div>
                </div>
            `;

            // Update AP/AR Status
            document.getElementById('apar-summary').innerHTML = `
                <div class="metrics-grid">
                    <div class="metric">
                        <span class="metric-label">Receivables</span>
                        <span class="metric-value">$${this.formatNumber(apArData.receivables)}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Payables</span>
                        <span class="metric-value">$${this.formatNumber(apArData.payables)}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Next Due</span>
                        <span class="metric-value">$${this.formatNumber(apArData.nextDueAmount)}</span>
                        <span class="metric-date">${this.formatDate(apArData.nextDueDate)}</span>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading operations overview:', error);
            NotificationSystem.show('Failed to load operations overview', 'error');
        }
    }

    async loadCriticalAlerts() {
        try {
            const [taxData, apArData, stockData] = await Promise.all([
                DashboardAPI.getTaxDeadlines(),
                DashboardAPI.getFromAPAR(),
                DashboardAPI.getFromInventory()
            ]);

            // Update Tax Deadlines
            document.getElementById('tax-deadlines').innerHTML = `
                <div class="alert-list">
                    ${taxData.map(tax => `
                        <div class="alert-item ${tax.status}">
                            <div class="alert-header">
                                <span class="alert-title">${tax.type}</span>
                                <span class="alert-amount">$${this.formatNumber(tax.amount)}</span>
                            </div>
                            <div class="alert-details">Due: ${this.formatDate(tax.dueDate)}</div>
                        </div>
                    `).join('')}
                </div>
            `;

            // Update Outstanding Payments
            document.getElementById('outstanding-payments').innerHTML = `
                <div class="alert-list">
                    <div class="alert-item ${apArData.overdueReceivables > 0 ? 'warning' : 'success'}">
                        <div class="alert-header">
                            <span class="alert-title">Overdue Receivables</span>
                            <span class="alert-amount">$${this.formatNumber(apArData.overdueReceivables)}</span>
                        </div>
                    </div>
                    <div class="alert-item ${apArData.overduePayables > 0 ? 'warning' : 'success'}">
                        <div class="alert-header">
                            <span class="alert-title">Overdue Payables</span>
                            <span class="alert-amount">$${this.formatNumber(apArData.overduePayables)}</span>
                        </div>
                    </div>
                </div>
            `;

            // Update Low Stock Alerts
            document.getElementById('low-stock-alerts').innerHTML = `
                <div class="alert-list">
                    <div class="alert-item ${stockData.lowStockCount > 0 ? 'warning' : 'success'}">
                        <div class="alert-header">
                            <span class="alert-title">Low Stock Items</span>
                            <span class="alert-count">${stockData.lowStockCount}</span>
                        </div>
                    </div>
                    <div class="alert-item ${stockData.reorderNeeded > 0 ? 'danger' : 'success'}">
                        <div class="alert-header">
                            <span class="alert-title">Reorder Required</span>
                            <span class="alert-count">${stockData.reorderNeeded}</span>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading critical alerts:', error);
            NotificationSystem.show('Failed to load critical alerts', 'error');
        }
    }

    updateMetricCard(id, data) {
        const element = document.getElementById(id);
        if (!element) return;

        element.innerHTML = `
            <div class="metric-card">
                <div class="metric-value">$${this.formatNumber(data.value)}</div>
                <div class="metric-subtitle">${data.subtitle}</div>
                <div class="metric-trend ${data.trend.startsWith('+') ? 'positive' : 'negative'}">
                    <i class="fas fa-${data.trend.startsWith('+') ? 'arrow-up' : 'arrow-down'}"></i>
                    ${data.trend}
                </div>
            </div>
        `;
    }

    formatNumber(number) {
        return new Intl.NumberFormat('en-US').format(number);
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
}

// Initialize the dashboard when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new DashboardManager();

});

document.addEventListener("DOMContentLoaded", function () {
    const pieCtx = document.getElementById('pieChart').getContext('2d');
    const barCtx = document.getElementById('barChart').getContext('2d');

    // Initial Data
    let pieData = [300, 150, 100];
    let barDataBudget = [120000, 90000, 50000];
    let barDataActual = [110000, 95000, 48000];
    const labels = ['Sales', 'Operations', 'HR'];

    // Pie Chart
    const pieChart = new Chart(pieCtx, {
        type: 'pie',
        data: {
            labels: ['Income', 'Expenses', 'Savings'],
            datasets: [{
                data: pieData,
                backgroundColor: [
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(255, 206, 86, 0.6)'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
                title: { display: true, text: 'Financial Distribution' }
            }
        }
    });

    // Bar Chart
    const barChart = new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Budget',
                    data: barDataBudget,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)'
                },
                {
                    label: 'Actual',
                    data: barDataActual,
                    backgroundColor: 'rgba(255, 99, 132, 0.6)'
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
                title: { display: true, text: 'Budget vs Actual' }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });



    // Update every 5 seconds
    setInterval(updateCharts, 5000);
});
