class BudgetingAPI {
    static async fetchBudgetOverview() {
        // Simulated API call to get budget overview
        return {
            totalBudget: 2000000,
            allocated: 1850000,
            remaining: 150000,
            fiscalYear: "2025"
        };
    }

    static async fetchDepartmentBudgets() {
        // Simulated API call to get department budgets
        return [
            {
                department: "Sales & Marketing",
                budget: 500000,
                spent: 420000,
                remaining: 80000
            },
            {
                department: "Research & Development",
                budget: 400000,
                spent: 380000,
                remaining: 20000
            },
            {
                department: "Operations",
                budget: 600000,
                spent: 550000,
                remaining: 50000
            },
            {
                department: "Human Resources",
                budget: 350000,
                spent: 300000,
                remaining: 50000
            }
        ];
    }

    static async fetchBudgetActual() {
        // Simulated API call to get budget vs actual data
        return {
            revenue: {
                budget: 3000000,
                actual: 2850000
            },
            expenses: {
                budget: 2000000,
                actual: 1850000
            },
            profit: {
                budget: 1000000,
                actual: 1000000
            }
        };
    }

    static async fetchBudgetActivities() {
        // Simulated API call to get recent budget activities
        return [
            {
                date: "2025-08-14",
                department: "Sales & Marketing",
                type: "Expense",
                description: "Q3 Marketing Campaign",
                amount: 50000
            },
            {
                date: "2025-08-13",
                department: "R&D",
                type: "Budget Adjustment",
                description: "Project Alpha Extension",
                amount: 25000
            }
        ];
    }
}

class BudgetingManager {
    constructor() {
        this.showLoadingStates();
        this.initialize();
    }

    showLoadingStates() {
        const sections = [
            'budget-overview',
            'department-budgets',
            'budget-actual',
            'budget-activities'
        ];
        
        sections.forEach(id => {
            const element = document.getElementById(id);
            element.innerHTML = '<div class="loading"></div>';
        });
    }

    async initialize() {
        await Promise.all([
            this.updateBudgetOverview(),
            this.updateDepartmentBudgets(),
            this.updateBudgetActual(),
            this.updateBudgetActivities()
        ]);
    }

    async updateBudgetOverview() {
        try {
            const data = await BudgetingAPI.fetchBudgetOverview();
            const overviewDiv = document.getElementById('budget-overview');
            
            overviewDiv.innerHTML = `
                <div class="financial-metrics">
                    <div class="metric">
                        <h3>Total Budget ${data.fiscalYear}</h3>
                        <p>$${data.totalBudget.toLocaleString()}</p>
                    </div>
                    <div class="metric">
                        <h3>Allocated</h3>
                        <p class="warning">$${data.allocated.toLocaleString()}</p>
                    </div>
                    <div class="metric">
                        <h3>Remaining</h3>
                        <p class="positive">$${data.remaining.toLocaleString()}</p>
                    </div>
                </div>
                <div class="budget-progress">
                    <div class="progress-bar">
                        <div class="progress" style="width: ${(data.allocated/data.totalBudget * 100)}%"></div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error updating budget overview:', error);
        }
    }

    async updateDepartmentBudgets() {
        try {
            const departments = await BudgetingAPI.fetchDepartmentBudgets();
            const budgetsDiv = document.getElementById('department-budgets');
            
            budgetsDiv.innerHTML = `
                <div class="department-budgets">
                    ${departments.map(dept => `
                        <div class="department-budget-card">
                            <div class="dept-header">
                                <h3>${dept.department}</h3>
                                <span class="remaining ${dept.remaining < dept.budget * 0.1 ? 'warning' : 'positive'}">
                                    $${dept.remaining.toLocaleString()} remaining
                                </span>
                            </div>
                            <div class="budget-progress">
                                <div class="progress-bar">
                                    <div class="progress" style="width: ${(dept.spent/dept.budget * 100)}%"></div>
                                </div>
                            </div>
                            <div class="dept-details">
                                <span>Budget: $${dept.budget.toLocaleString()}</span>
                                <span>Spent: $${dept.spent.toLocaleString()}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error updating department budgets:', error);
        }
    }

    async updateBudgetActual() {
        try {
            const data = await BudgetingAPI.fetchBudgetActual();
            const actualDiv = document.getElementById('budget-actual');
            
            actualDiv.innerHTML = `
                <div class="budget-vs-actual">
                    <div class="financial-metrics">
                        <div class="metric">
                            <h3>Revenue vs Budget</h3>
                            <p class="${data.revenue.actual >= data.revenue.budget ? 'positive' : 'negative'}">
                                $${data.revenue.actual.toLocaleString()} / $${data.revenue.budget.toLocaleString()}
                            </p>
                        </div>
                        <div class="metric">
                            <h3>Expenses vs Budget</h3>
                            <p class="${data.expenses.actual <= data.expenses.budget ? 'positive' : 'negative'}">
                                $${data.expenses.actual.toLocaleString()} / $${data.expenses.budget.toLocaleString()}
                            </p>
                        </div>
                        <div class="metric">
                            <h3>Profit vs Target</h3>
                            <p class="${data.profit.actual >= data.profit.budget ? 'positive' : 'negative'}">
                                $${data.profit.actual.toLocaleString()} / $${data.profit.budget.toLocaleString()}
                            </p>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error updating budget vs actual:', error);
        }
    }

    async updateBudgetActivities() {
        try {
            const activities = await BudgetingAPI.fetchBudgetActivities();
            const activitiesDiv = document.getElementById('budget-activities');
            
            activitiesDiv.innerHTML = `
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Department</th>
                            <th>Type</th>
                            <th>Description</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${activities.map(activity => `
                            <tr>
                                <td>${new Date(activity.date).toLocaleDateString()}</td>
                                <td>${activity.department}</td>
                                <td>${activity.type}</td>
                                <td>${activity.description}</td>
                                <td>$${activity.amount.toLocaleString()}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        } catch (error) {
            console.error('Error updating budget activities:', error);
        }
    }
}

// Add some specific styles for budgeting
const styles = `
    .budget-progress {
        margin: 16px 0;
    }

    .progress-bar {
        background: rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        height: 8px;
        overflow: hidden;
    }

    .progress {
        background: var(--primary-color);
        height: 100%;
        transition: width 0.3s ease;
    }

    .department-budgets {
        display: grid;
        gap: 16px;
    }

    .department-budget-card {
        background: var(--card-bg);
        border-radius: calc(var(--border-radius) - 4px);
        padding: 16px;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .dept-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
    }

    .dept-header h3 {
        margin: 0;
        font-size: 1.1rem;
        color: var(--text-color);
    }

    .remaining {
        font-size: 0.9rem;
        font-weight: 500;
    }

    .dept-details {
        display: flex;
        justify-content: space-between;
        margin-top: 8px;
        font-size: 0.9rem;
        color: var(--text-color);
        opacity: 0.8;
    }

    .budget-vs-actual {
        padding: 16px 0;
    }
`;

// Add styles to the document
const styleSheet = document.createElement("style");
styleSheet.textContent = styles;
document.head.appendChild(styleSheet);

// Initialize budgeting when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.budgetManager = new BudgetingManager();
});
