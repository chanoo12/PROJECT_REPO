import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import sqlite3 from "sqlite3";
import { open } from "sqlite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

// ---- Static files (serve your html/css/js) ----
app.use(express.static(path.join(__dirname)));

// ---- SQLite setup ----
let db;
async function initDB() {
  db = await open({
    filename: path.join(__dirname, "gl.db"),
    driver: sqlite3.Database
  });

  await db.exec(`
    PRAGMA journal_mode = WAL;

    CREATE TABLE IF NOT EXISTS journal_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      description TEXT NOT NULL,
      debit REAL DEFAULT 0,
      credit REAL DEFAULT 0,
      type TEXT DEFAULT 'general',  -- 'revenue' | 'expense' | 'asset' | 'liability' | 'general'
      status TEXT DEFAULT 'posted', -- 'posted' | 'draft'
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);

  // Seed if empty
  const row = await db.get(`SELECT COUNT(*) AS c FROM journal_entries;`);
  if (row.c === 0) {
    await db.exec(`
      INSERT INTO journal_entries (date, description, debit, credit, type, status) VALUES
      ('2025-08-10', 'Sale of goods', 0, 50000, 'revenue', 'posted'),
      ('2025-08-11', 'Office Supplies Purchase', 1200, 0, 'expense', 'posted'),
      ('2025-08-12', 'Inventory Purchase', 20000, 0, 'asset', 'posted'),
      ('2025-08-13', 'Accounts Payable Payment', 0, 15000, 'liability', 'posted');
    `);
  }
}
await initDB();

// ---- Helpers ----
function monthRangeStr(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const start = `${y}-${m}-01`;
  const nextMonth = new Date(y, date.getMonth() + 1, 1);
  const end = new Date(nextMonth - 1);
  const endStr = `${end.getFullYear()}-${String(end.getMonth() + 1).padStart(2, "0")}-${String(end.getDate()).padStart(2, "0")}`;
  return { start, end: endStr, label: end.toLocaleString('en-US', { month: 'long', year: 'numeric' }) };
}

// ---- API ROUTES ----

// Journal: list
app.get("/api/journal", async (req, res) => {
  const rows = await db.all(`SELECT * FROM journal_entries ORDER BY date DESC, id DESC`);
  res.json(rows);
});

// Journal: create
app.post("/api/journal", async (req, res) => {
  const { date, description, debit = 0, credit = 0, type = "general", status = "posted" } = req.body || {};
  if (!date || !description) return res.status(400).json({ error: "date and description are required" });
  const result = await db.run(
    `INSERT INTO journal_entries (date, description, debit, credit, type, status) VALUES (?,?,?,?,?,?)`,
    [date, description, debit, credit, type, status]
  );
  const newRow = await db.get(`SELECT * FROM journal_entries WHERE id = ?`, [result.lastID]);
  res.status(201).json(newRow);
});

// Journal: update
app.put("/api/journal/:id", async (req, res) => {
  const { id } = req.params;
  const existing = await db.get(`SELECT * FROM journal_entries WHERE id = ?`, [id]);
  if (!existing) return res.status(404).json({ error: "not found" });

  const { date, description, debit, credit, type, status } = { ...existing, ...req.body };
  await db.run(
    `UPDATE journal_entries SET date=?, description=?, debit=?, credit=?, type=?, status=? WHERE id=?`,
    [date, description, debit, credit, type, status, id]
  );
  const updated = await db.get(`SELECT * FROM journal_entries WHERE id = ?`, [id]);
  res.json(updated);
});

// Journal: delete
app.delete("/api/journal/:id", async (req, res) => {
  const { id } = req.params;
  await db.run(`DELETE FROM journal_entries WHERE id = ?`, [id]);
  res.json({ ok: true });
});

// GL Summary (simple derivation from journal)
app.get("/api/gl/summary", async (_req, res) => {
  const sums = await db.get(`
    SELECT
      ROUND(SUM(debit),2) AS totalDebits,
      ROUND(SUM(credit),2) AS totalCredits
    FROM journal_entries
  `);

  const netIncomeRow = await db.get(`
    SELECT
      ROUND(SUM(CASE WHEN type='revenue' THEN credit ELSE 0 END),2) as revenue,
      ROUND(SUM(CASE WHEN type='expense' THEN debit ELSE 0 END),2) as expenses
  `);
  const netIncome = (netIncomeRow.revenue || 0) - (netIncomeRow.expenses || 0);

  // Dummy assets/liabilities for now (or compute from types if you prefer)
  const assets = await db.get(`SELECT ROUND(SUM(CASE WHEN type='asset' THEN debit-credit ELSE 0 END),2) as v`);
  const liabilities = await db.get(`SELECT ROUND(SUM(CASE WHEN type='liability' THEN credit-debit ELSE 0 END),2) as v`);

  res.json({
    totalAssets: Math.max(0, assets.v || 0) + 1500000, // add base to look realistic
    totalLiabilities: Math.max(0, liabilities.v || 0) + 1000000,
    equity: (Math.max(0, assets.v || 0) + 1500000) - (Math.max(0, liabilities.v || 0) + 1000000),
    revenue: netIncomeRow.revenue || 0,
    expenses: netIncomeRow.expenses || 0,
    netIncome,
    trend: `${netIncome >= 0 ? "+" : ""}${(Math.random()*5).toFixed(1)}%`,
    totals: sums
  });
});

// Period overview (current month)
app.get("/api/period", async (_req, res) => {
  const { start, end, label } = monthRangeStr();
  const entriesCount = await db.get(
    `SELECT COUNT(*) AS c FROM journal_entries WHERE date BETWEEN ? AND ?`, [start, end]
  );
  res.json({
    currentPeriod: label,
    status: "open",
    entriesCount: entriesCount.c,
    lastClosing: `${new Date().getFullYear()}-${String(new Date().getMonth()).padStart(2,'0')}-31`,
    nextClosing: `${new Date().getFullYear()}-${String(new Date().getMonth()+1).padStart(2,'0')}-31`
  });
});

// Account balances (group by type — quick demo)
app.get("/api/account-balances", async (_req, res) => {
  const assets = await db.get(`SELECT ROUND(SUM(CASE WHEN type='asset' THEN debit-credit ELSE 0 END),2) AS balance`);
  const liabilities = await db.get(`SELECT ROUND(SUM(CASE WHEN type='liability' THEN credit-debit ELSE 0 END),2) AS balance`);
  res.json({
    assets: [
      { account: "Cash", balance: Math.max(0, (assets.balance || 0) * 0.4), change: "+2.3%" },
      { account: "Accounts Receivable", balance: Math.max(0, (assets.balance || 0) * 0.3), change: "-1.5%" },
      { account: "Inventory", balance: Math.max(0, (assets.balance || 0) * 0.3), change: "+0.8%" }
    ],
    liabilities: [
      { account: "Accounts Payable", balance: -Math.max(0, (liabilities.balance || 0) * 0.25), change: "-3.1%" },
      { account: "Long-term Debt", balance: -Math.max(0, (liabilities.balance || 0) * 0.75), change: "0.0%" }
    ]
  });
});

// Recent transactions (map from last 10 journal entries)
app.get("/api/recent-transactions", async (_req, res) => {
  const rows = await db.all(`
    SELECT * FROM journal_entries ORDER BY date DESC, id DESC LIMIT 10
  `);
  const mapped = rows.map(r => ({
    id: `TRX${String(r.id).padStart(3,"0")}`,
    date: r.date,
    description: r.description,
    debit: r.debit,
    credit: r.credit,
    department: r.type === 'expense' ? 'Operations' : (r.type === 'revenue' ? 'Sales' : 'Finance'),
    status: r.status
  }));
  res.json(mapped);
});

// Income statement (aggregate by type)
app.get("/api/income-statement", async (_req, res) => {
  const rev = await db.get(`SELECT ROUND(SUM(CASE WHEN type='revenue' THEN credit ELSE 0 END),2) AS sales`);
  const otherIncome = await db.get(`SELECT ROUND(SUM(CASE WHEN type='asset' THEN credit ELSE 0 END),2) AS otherIncome`);
  const cogs = await db.get(`SELECT ROUND(SUM(CASE WHEN description LIKE '%Inventory%' THEN debit ELSE 0 END),2) AS cogs`);
  const operational = await db.get(`SELECT ROUND(SUM(CASE WHEN type='expense' THEN debit ELSE 0 END),2) AS operational`);
  res.json({
    revenue: { sales: rev.sales || 0, otherIncome: otherIncome.otherIncome || 0 },
    expenses: { cogs: cogs.cogs || 0, operational: operational.operational || 0, administrative: Math.round((operational.operational || 0) * 0.4) },
    trends: { revenue: "+5.2%", expenses: "+2.1%", netIncome: "+8.4%" }
  });
});

// Balance sheet (very simplified)
app.get("/api/balance-sheet", async (_req, res) => {
  const curAssets = await db.get(`SELECT ROUND(SUM(CASE WHEN type='asset' THEN debit-credit ELSE 0 END),2) AS v`);
  const curLiab = await db.get(`SELECT ROUND(SUM(CASE WHEN type='liability' THEN credit-debit ELSE 0 END),2) AS v`);
  res.json({
    assets: { current: Math.max(0, (curAssets.v || 0) * 0.6), fixed: Math.max(0, (curAssets.v || 0) * 0.4) },
    liabilities: { current: Math.max(0, (curLiab.v || 0) * 0.5), longTerm: Math.max(0, (curLiab.v || 0) * 0.5) },
    equity: { capital: 1000000, retained: 500000 }
  });
});

// ---- Start server ----
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`GL server running http://localhost:${PORT}`));
