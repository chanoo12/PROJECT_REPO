class StockMovementAPI {
    static async getSummary() {
        // Simulated API call for stock summary
        return {
            totalItems: 2850,
            totalValue: 1250000,
            movementsToday: 45,
            valueChange: '+2.8%'
        };
    }

    static async getWarehouseStatus() {
        // Simulated API call for warehouse status
        return {
            capacity: 3500,
            used: 2850,
            locations: 8,
            efficiency: '81.4%'
        };
    }

    static async getMovementLog() {
        // Simulated API call for movement log
        return [
            {
                id: 'MOV001',
                date: '2025-08-14',
                type: 'inbound',
                quantity: 150,
                category: 'Electronics',
                location: 'Warehouse A',
                status: 'completed'
            },
            // Add more movement data...
        ];
    }

    static async getStockCategories() {
        // Simulated API call for stock categories
        return [
            {
                name: 'Electronics',
                items: 850,
                value: 450000,
                trend: '+1.2%'
            },
            // Add more category data...
        ];
    }

    static async getLowStockAlerts() {
        // Simulated API call for low stock alerts
        return [
            {
                item: 'Laptop X1',
                category: 'Electronics',
                currentStock: 5,
                minimumRequired: 10,
                status: 'critical'
            },
            // Add more alert data...
        ];
    }

    static async getValueByCategory() {
        // Simulated API call for value by category
        return [
            {
                category: 'Electronics',
                value: 450000,
                percentage: 36
            },
            // Add more category value data...
        ];
    }

    static async getValueDistribution() {
        // Simulated API call for value distribution
        return [
            {
                type: 'High Value',
                value: 750000,
                percentage: 60
            },
            {
                type: 'Medium Value',
                value: 375000,
                percentage: 30
            },
            {
                type: 'Low Value',
                value: 125000,
                percentage: 10
            }
        ];
    }
}

class StockMovementManager {
    constructor() {
        this.initializeEventListeners();
        this.loadAllData();
    }

    initializeEventListeners() {
        // New Movement button
        document.querySelector('.card-actions .primary').addEventListener('click', () => {
            // Implement new movement creation
            NotificationSystem.show('New movement form opened', 'info');
        });

        // Filter button
        document.querySelector('.action-btn').addEventListener('click', () => {
            // Implement filtering
            NotificationSystem.show('Filters applied', 'info');
        });
    }

    async loadAllData() {
        await Promise.all([
            this.loadStockSummary(),
            this.loadWarehouseStatus(),
            this.loadMovementLog(),
            this.loadStockCategories(),
            this.loadLowStockAlerts(),
            this.loadValueByCategory(),
            this.loadValueDistribution()
        ]);
    }

    async loadStockSummary() {
        try {
            const data = await StockMovementAPI.getSummary();
            document.getElementById('stock-summary').innerHTML = `
                <div class="metrics-grid">
                    <div class="metric">
                        <span class="metric-label">Total Items</span>
                        <span class="metric-value">${this.formatNumber(data.totalItems)}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Total Value</span>
                        <span class="metric-value">$${this.formatNumber(data.totalValue)}</span>
                        <span class="metric-trend ${data.valueChange.startsWith('+') ? 'positive' : 'negative'}">
                            ${data.valueChange}
                        </span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Today's Movements</span>
                        <span class="metric-value">${data.movementsToday}</span>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading stock summary:', error);
            NotificationSystem.show('Failed to load stock summary', 'error');
        }
    }

    async loadWarehouseStatus() {
        try {
            const data = await StockMovementAPI.getWarehouseStatus();
            document.getElementById('warehouse-status').innerHTML = `
                <div class="warehouse-metrics">
                    <div class="capacity-meter">
                        <div class="meter-fill" style="width: ${(data.used / data.capacity) * 100}%"></div>
                        <div class="meter-label">
                            ${data.used} / ${data.capacity} items (${data.efficiency} utilized)
                        </div>
                    </div>
                    <div class="warehouse-details">
                        <div class="detail-item">
                            <span class="label">Locations:</span>
                            <span class="value">${data.locations}</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Efficiency:</span>
                            <span class="value">${data.efficiency}</span>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading warehouse status:', error);
            NotificationSystem.show('Failed to load warehouse status', 'error');
        }
    }

    async loadMovementLog() {
        try {
            const movements = await StockMovementAPI.getMovementLog();
            document.getElementById('movement-log').innerHTML = `
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Quantity</th>
                            <th>Category</th>
                            <th>Location</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${movements.map(mov => `
                            <tr>
                                <td>${mov.id}</td>
                                <td>${this.formatDate(mov.date)}</td>
                                <td><span class="movement-type ${mov.type}">${mov.type}</span></td>
                                <td>${mov.quantity}</td>
                                <td>${mov.category}</td>
                                <td>${mov.location}</td>
                                <td><span class="status-badge ${mov.status}">${mov.status}</span></td>
                                <td>
                                    <button class="icon-btn" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="icon-btn" title="Print Label">
                                        <i class="fas fa-print"></i>
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        } catch (error) {
            console.error('Error loading movement log:', error);
            NotificationSystem.show('Failed to load movement log', 'error');
        }
    }

    async loadStockCategories() {
        try {
            const categories = await StockMovementAPI.getStockCategories();
            document.getElementById('stock-categories').innerHTML = `
                <div class="category-list">
                    ${categories.map(cat => `
                        <div class="category-item">
                            <div class="category-header">
                                <span class="category-name">${cat.name}</span>
                                <span class="category-trend ${cat.trend.startsWith('+') ? 'positive' : 'negative'}">
                                    ${cat.trend}
                                </span>
                            </div>
                            <div class="category-metrics">
                                <div class="metric">
                                    <span class="label">Items:</span>
                                    <span class="value">${this.formatNumber(cat.items)}</span>
                                </div>
                                <div class="metric">
                                    <span class="label">Value:</span>
                                    <span class="value">$${this.formatNumber(cat.value)}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading stock categories:', error);
            NotificationSystem.show('Failed to load stock categories', 'error');
        }
    }

    async loadLowStockAlerts() {
        try {
            const alerts = await StockMovementAPI.getLowStockAlerts();
            document.getElementById('low-stock-alerts').innerHTML = `
                <div class="alert-list">
                    ${alerts.map(alert => `
                        <div class="alert-item ${alert.status}">
                            <div class="alert-header">
                                <span class="alert-title">${alert.item}</span>
                                <span class="alert-category">${alert.category}</span>
                            </div>
                            <div class="alert-metrics">
                                <div class="stock-level">
                                    <span class="current">${alert.currentStock}</span>
                                    <span class="separator">/</span>
                                    <span class="required">${alert.minimumRequired}</span>
                                </div>
                                <button class="action-btn small">Reorder</button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading low stock alerts:', error);
            NotificationSystem.show('Failed to load low stock alerts', 'error');
        }
    }

    async loadValueByCategory() {
        try {
            const data = await StockMovementAPI.getValueByCategory();
            document.getElementById('value-by-category').innerHTML = `
                <div class="value-chart">
                    ${data.map(category => `
                        <div class="value-bar">
                            <div class="bar-label">${category.category}</div>
                            <div class="bar-container">
                                <div class="bar-fill" style="width: ${category.percentage}%">
                                    $${this.formatNumber(category.value)}
                                </div>
                            </div>
                            <div class="bar-percentage">${category.percentage}%</div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading value by category:', error);
            NotificationSystem.show('Failed to load value by category', 'error');
        }
    }

    async loadValueDistribution() {
        try {
            const data = await StockMovementAPI.getValueDistribution();
            document.getElementById('value-distribution').innerHTML = `
                <div class="distribution-chart">
                    <div class="pie-chart">
                        ${data.map((segment, index) => `
                            <div class="pie-segment" style="
                                --percentage: ${segment.percentage};
                                --rotation: ${data.slice(0, index).reduce((acc, curr) => acc + curr.percentage, 0)}deg;
                            "></div>
                        `).join('')}
                    </div>
                    <div class="distribution-legend">
                        ${data.map(segment => `
                            <div class="legend-item">
                                <span class="legend-color" style="background-color: var(--color-${segment.type.toLowerCase().replace(' ', '-')})"></span>
                                <span class="legend-label">${segment.type}</span>
                                <span class="legend-value">$${this.formatNumber(segment.value)}</span>
                                <span class="legend-percentage">${segment.percentage}%</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading value distribution:', error);
            NotificationSystem.show('Failed to load value distribution', 'error');
        }
    }

    formatNumber(number) {
        return new Intl.NumberFormat('en-US').format(number);
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
}

// Initialize the manager when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new StockMovementManager();
});
