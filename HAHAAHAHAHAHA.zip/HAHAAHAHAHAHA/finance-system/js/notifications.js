class NotificationSystem {
    constructor() {
        this.notifications = [];
        this.badge = document.querySelector('.notification-badge');
        this.panel = document.querySelector('.notification-panel');
        this.notificationIcon = document.querySelector('.notification-icon');
        this.notificationList = document.getElementById('notification-list');

        this.setupEventListeners();
        this.startNotificationPolling();
    }

    setupEventListeners() {
        this.notificationIcon.addEventListener('click', () => {
            this.toggleNotificationPanel();
        });

        // Close panel when clicking outside
        document.addEventListener('click', (e) => {
            if (!this.panel.contains(e.target) && !this.notificationIcon.contains(e.target)) {
                this.panel.style.display = 'none';
            }
        });
    }

    toggleNotificationPanel() {
        this.panel.style.display = this.panel.style.display === 'none' ? 'block' : 'none';
    }

    async fetchNotifications() {
        try {
            // Simulated API call - replace with actual API endpoint
            const departments = ['CRM', 'Inventory', 'HR', 'ProjectManagement'];
            const mockNotifications = departments.map(dept => this.generateMockNotification(dept));
            return mockNotifications;
        } catch (error) {
            console.error('Error fetching notifications:', error);
            return [];
        }
    }

    generateMockNotification(department) {
        const types = {
            CRM: ['New sales order', 'Updated customer invoice', 'Payment received'],
            Inventory: ['Stock level alert', 'New shipment arrived', 'Inventory adjustment'],
            HR: ['Payroll processed', 'New employee added', 'Benefits update'],
            ProjectManagement: ['Budget update', 'Project milestone', 'Expense approval']
        };

        const randomType = types[department][Math.floor(Math.random() * types[department].length)];
        return {
            id: Math.random().toString(36).substr(2, 9),
            department: department,
            type: randomType,
            message: `${randomType} from ${department}`,
            timestamp: new Date().toISOString(),
            read: false
        };
    }

    updateNotificationBadge() {
        const unreadCount = this.notifications.filter(n => !n.read).length;
        this.badge.textContent = unreadCount;
        this.badge.style.display = unreadCount > 0 ? 'block' : 'none';
    }

    renderNotification(notification) {
        const div = document.createElement('div');
        div.className = 'notification-item';
        div.innerHTML = `
            <strong>${notification.department}</strong>
            <p>${notification.message}</p>
            <small>${new Date(notification.timestamp).toLocaleString()}</small>
        `;
        div.addEventListener('click', () => this.markAsRead(notification.id));
        return div;
    }

    updateNotificationPanel() {
        this.notificationList.innerHTML = '';
        this.notifications
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .forEach(notification => {
                this.notificationList.appendChild(this.renderNotification(notification));
            });
    }

    markAsRead(notificationId) {
        const notification = this.notifications.find(n => n.id === notificationId);
        if (notification) {
            notification.read = true;
            this.updateNotificationBadge();
            this.updateNotificationPanel();
        }
    }

    async startNotificationPolling() {
        setInterval(async () => {
            const newNotifications = await this.fetchNotifications();
            this.notifications = [...this.notifications, ...newNotifications];
            this.updateNotificationBadge();
            this.updateNotificationPanel();
        }, 30000); // Poll every 30 seconds
    }
}

// Initialize notification system when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.notificationSystem = new NotificationSystem();
});
