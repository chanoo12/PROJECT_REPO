class PayablesReceivablesAPI {
    static async getSummary() {
        // Simulated API call for AP/AR summary
        return {
            totalReceivables: 458000,
            totalPayables: 325000,
            netPosition: 133000,
            receivablesTrend: '+5.2%',
            payablesTrend: '-2.1%'
        };
    }

    static async getAgingAnalysis() {
        // Simulated API call for aging analysis
        return {
            receivables: {
                current: 250000,
                '30days': 120000,
                '60days': 60000,
                '90days': 28000
            },
            payables: {
                current: 180000,
                '30days': 95000,
                '60days': 35000,
                '90days': 15000
            }
        };
    }

    static async getOutstandingInvoices() {
        // Simulated API call for AR invoices
        return [
            {
                id: 'INV-001',
                customer: 'Tech Corp',
                amount: 25000,
                dueDate: '2025-09-15',
                status: 'pending'
            },
            // Add more invoice data...
        ];
    }

    static async getPendingPayments() {
        // Simulated API call for AP payments
        return [
            {
                id: 'PAY-001',
                vendor: 'Office Supplies Co',
                amount: 15000,
                dueDate: '2025-08-30',
                status: 'scheduled'
            },
            // Add more payment data...
        ];
    }

    static async getPaymentSchedule() {
        // Simulated API call for payment schedule
        return [
            {
                date: '2025-08-20',
                type: 'payable',
                description: 'Monthly IT Services',
                amount: 8500
            },
            // Add more schedule data...
        ];
    }

    static async getRecentTransactions() {
        // Simulated API call for recent transactions
        return [
            {
                id: 'TRX-001',
                date: '2025-08-14',
                type: 'payment_received',
                amount: 12500,
                entity: 'Global Solutions Inc'
            },
            // Add more transaction data...
        ];
    }
}

class PayablesReceivablesManager {
    constructor() {
        this.initializeEventListeners();
        this.loadAllData();
    }

    initializeEventListeners() {
        // New Invoice button
        document.querySelector('.card-actions .primary').addEventListener('click', () => {
            // Implement new invoice creation
            NotificationSystem.show('New invoice creation form opened', 'info');
        });

        // Filter buttons
        document.querySelectorAll('.action-btn').forEach(btn => {
            if (!btn.classList.contains('primary')) {
                btn.addEventListener('click', () => {
                    // Implement filtering
                    NotificationSystem.show('Filters applied', 'info');
                });
            }
        });
    }

    async loadAllData() {
        await Promise.all([
            this.loadFinancialOverview(),
            this.loadAgingAnalysis(),
            this.loadOutstandingInvoices(),
            this.loadPendingPayments(),
            this.loadPaymentSchedule(),
            this.loadRecentTransactions()
        ]);
    }

    async loadFinancialOverview() {
        try {
            const data = await PayablesReceivablesAPI.getSummary();
            const schedule = await PayablesReceivablesAPI.getPaymentSchedule();

            // Total Receivables
            document.getElementById('total-receivables').innerHTML = `
                <div class="metric-value">$${this.formatNumber(data.totalReceivables)}</div>
                <div class="metric-trend ${data.receivablesTrend.startsWith('+') ? 'positive' : 'negative'}">
                    ${data.receivablesTrend}
                </div>
            `;

            // Total Payables
            document.getElementById('total-payables').innerHTML = `
                <div class="metric-value">$${this.formatNumber(data.totalPayables)}</div>
                <div class="metric-trend ${data.payablesTrend.startsWith('-') ? 'positive' : 'negative'}">
                    ${data.payablesTrend}
                </div>
            `;

            // Net Position
            document.getElementById('net-position').innerHTML = `
                <div class="metric-value">$${this.formatNumber(data.netPosition)}</div>
                <div class="metric-trend ${data.netPosition > 0 ? 'positive' : 'negative'}">
                    ${data.netPosition > 0 ? 'Positive' : 'Negative'} Balance
                </div>
            `;

            // Due This Week
            const dueThisWeek = schedule.filter(item => {
                const itemDate = new Date(item.date);
                const today = new Date();
                const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
                return itemDate >= today && itemDate <= nextWeek;
            });

            const dueThisWeekTotal = dueThisWeek.reduce((sum, item) => sum + item.amount, 0);

            document.getElementById('due-this-week').innerHTML = `
                <div class="metric-value">$${this.formatNumber(dueThisWeekTotal)}</div>
                <div class="metric-subtext">${dueThisWeek.length} transactions</div>
            `;
        } catch (error) {
            console.error('Error loading financial overview:', error);
            NotificationSystem.show('Failed to load financial overview', 'error');
        }
    }

    async loadAgingAnalysis() {
        try {
            const data = await PayablesReceivablesAPI.getAgingAnalysis();
            
            // AR Aging
            document.getElementById('ar-aging').innerHTML = this.createAgingChart(data.receivables, 'Receivables');

            // AP Aging
            document.getElementById('ap-aging').innerHTML = this.createAgingChart(data.payables, 'Payables');
        } catch (error) {
            console.error('Error loading aging analysis:', error);
            NotificationSystem.show('Failed to load aging analysis', 'error');
        }
    }

    createAgingChart(data, type) {
        const total = Object.values(data).reduce((sum, amount) => sum + amount, 0);
        return `
            <div class="aging-chart">
                ${Object.entries(data).map(([period, amount]) => `
                    <div class="aging-bar">
                        <div class="bar-label">${this.formatAgingPeriod(period)}</div>
                        <div class="bar-container">
                            <div class="bar-fill" style="width: ${(amount / total * 100)}%">
                                $${this.formatNumber(amount)}
                            </div>
                        </div>
                        <div class="bar-percentage">${Math.round(amount / total * 100)}%</div>
                    </div>
                `).join('')}
                <div class="total-row">
                    <span>Total ${type}</span>
                    <span>$${this.formatNumber(total)}</span>
                </div>
            </div>
        `;
    }

    formatAgingPeriod(period) {
        switch(period) {
            case 'current': return 'Current';
            case '30days': return '30 Days';
            case '60days': return '60 Days';
            case '90days': return '90+ Days';
            default: return period;
        }
    }

    async loadOutstandingInvoices() {
        try {
            const invoices = await PayablesReceivablesAPI.getOutstandingInvoices();
            document.getElementById('ar-invoices').innerHTML = `
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Invoice #</th>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${invoices.map(invoice => `
                            <tr>
                                <td>${invoice.id}</td>
                                <td>${invoice.customer}</td>
                                <td>$${this.formatNumber(invoice.amount)}</td>
                                <td>${this.formatDate(invoice.dueDate)}</td>
                                <td><span class="status-badge ${invoice.status}">${invoice.status}</span></td>
                                <td>
                                    <button class="icon-btn" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="icon-btn" title="Send Reminder">
                                        <i class="fas fa-bell"></i>
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        } catch (error) {
            console.error('Error loading outstanding invoices:', error);
            NotificationSystem.show('Failed to load outstanding invoices', 'error');
        }
    }

    async loadPendingPayments() {
        try {
            const payments = await PayablesReceivablesAPI.getPendingPayments();
            document.getElementById('ap-payments').innerHTML = `
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Payment #</th>
                            <th>Vendor</th>
                            <th>Amount</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${payments.map(payment => `
                            <tr>
                                <td>${payment.id}</td>
                                <td>${payment.vendor}</td>
                                <td>$${this.formatNumber(payment.amount)}</td>
                                <td>${this.formatDate(payment.dueDate)}</td>
                                <td><span class="status-badge ${payment.status}">${payment.status}</span></td>
                                <td>
                                    <button class="icon-btn" title="Process Payment">
                                        <i class="fas fa-credit-card"></i>
                                    </button>
                                    <button class="icon-btn" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        } catch (error) {
            console.error('Error loading pending payments:', error);
            NotificationSystem.show('Failed to load pending payments', 'error');
        }
    }

    async loadPaymentSchedule() {
        try {
            const schedule = await PayablesReceivablesAPI.getPaymentSchedule();
            document.getElementById('payment-schedule').innerHTML = `
                <div class="schedule-list">
                    ${schedule.map(item => `
                        <div class="schedule-item ${item.type}">
                            <div class="schedule-date">${this.formatDate(item.date)}</div>
                            <div class="schedule-details">
                                <div class="schedule-description">${item.description}</div>
                                <div class="schedule-amount">$${this.formatNumber(item.amount)}</div>
                            </div>
                            <div class="schedule-type">
                                <i class="fas fa-${item.type === 'payable' ? 'arrow-up' : 'arrow-down'}"></i>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading payment schedule:', error);
            NotificationSystem.show('Failed to load payment schedule', 'error');
        }
    }

    async loadRecentTransactions() {
        try {
            const transactions = await PayablesReceivablesAPI.getRecentTransactions();
            document.getElementById('recent-transactions').innerHTML = `
                <div class="transaction-list">
                    ${transactions.map(tx => `
                        <div class="transaction-item">
                            <div class="transaction-icon">
                                <i class="fas fa-${tx.type === 'payment_received' ? 'arrow-down' : 'arrow-up'}"></i>
                            </div>
                            <div class="transaction-details">
                                <div class="transaction-primary">
                                    <span class="transaction-entity">${tx.entity}</span>
                                    <span class="transaction-amount">$${this.formatNumber(tx.amount)}</span>
                                </div>
                                <div class="transaction-secondary">
                                    <span class="transaction-id">${tx.id}</span>
                                    <span class="transaction-date">${this.formatDate(tx.date)}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading recent transactions:', error);
            NotificationSystem.show('Failed to load recent transactions', 'error');
        }
    }

    formatNumber(number) {
        return new Intl.NumberFormat('en-US').format(number);
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
}

// Initialize the manager when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PayablesReceivablesManager();
});
