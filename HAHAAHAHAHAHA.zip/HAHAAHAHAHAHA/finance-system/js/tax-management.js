class TaxManagementAPI {
    static async fetchTaxSummary() {
        try {
            await new Promise(resolve => setTimeout(resolve, 800));
            return {
                totalTaxLiability: 250000,
                paidTaxes: 150000,
                remainingTaxes: 100000,
                nextPaymentDue: "2025-09-30",
                effectiveRate: 23.5,
                yearOverYearChange: -1.2,
                lastUpdated: new Date().toISOString(),
                availableCredits: 15000
            };
        } catch (error) {
            console.error('Error fetching tax summary:', error);
            throw new Error('Failed to fetch tax summary');
        }
    }

    static async fetchTaxCalendar() {
        try {
            await new Promise(resolve => setTimeout(resolve, 600));
            return [
                {
                    title: "VAT Return",
                    dueDate: "2025-09-30",
                    estimatedAmount: 45000,
                    status: "upcoming",
                    filingType: "Quarterly",
                    department: "Finance",
                    requiredDocs: ["Sales Records", "Purchase Records"]
                },
                {
                    title: "Corporate Tax",
                    dueDate: "2025-12-31",
                    estimatedAmount: 150000,
                    status: "upcoming",
                    filingType: "Annual",
                    department: "Finance",
                    requiredDocs: ["Financial Statements", "Asset Records"]
                },
                {
                    title: "Payroll Tax",
                    dueDate: "2025-08-31",
                    estimatedAmount: 35000,
                    status: "urgent",
                    filingType: "Monthly",
                    department: "HR",
                    requiredDocs: ["Payroll Records"]
                }
            ];
        } catch (error) {
            console.error('Error fetching tax calendar:', error);
            throw new Error('Failed to fetch tax calendar');
        }
    }

    static async fetchTaxLiabilities() {
        try {
            await new Promise(resolve => setTimeout(resolve, 700));
            return [
                {
                    type: "VAT",
                    amount: 45000,
                    period: "Q3 2025",
                    dueAmount: 45000,
                    paidAmount: 0,
                    credits: 5000,
                    trend: "+2.3%"
                },
                {
                    type: "Corporate Tax",
                    amount: 150000,
                    period: "FY 2025",
                    dueAmount: 150000,
                    paidAmount: 75000,
                    credits: 8000,
                    trend: "-1.5%"
                },
                {
                    type: "Payroll Tax",
                    amount: 35000,
                    period: "August 2025",
                    dueAmount: 35000,
                    paidAmount: 35000,
                    credits: 0,
                    trend: "+0.8%"
                },
                {
                    type: "Property Tax",
                    amount: 20000,
                    period: "2025",
                    dueAmount: 20000,
                    paidAmount: 20000,
                    credits: 2000,
                    trend: "0%"
                }
            ];
        } catch (error) {
            console.error('Error fetching tax liabilities:', error);
            throw new Error('Failed to fetch tax liabilities');
        }
    }

    static async fetchTaxTransactions() {
        try {
            await new Promise(resolve => setTimeout(resolve, 500));
            return [
                {
                    date: "2025-08-10",
                    type: "Payment",
                    taxType: "VAT",
                    amount: 42000,
                    reference: "VAT-Q2-2025",
                    status: "Completed",
                    method: "Bank Transfer",
                    processedBy: "Jane Wilson"
                },
                {
                    date: "2025-07-31",
                    type: "Payment",
                    taxType: "Payroll Tax",
                    amount: 35000,
                    reference: "PT-JUL-2025",
                    status: "Completed",
                    method: "Direct Debit",
                    processedBy: "System"
                },
                {
                    date: "2025-07-15",
                    type: "Filing",
                    taxType: "Corporate Tax",
                    amount: 75000,
                    reference: "CT-Q2-2025",
                    status: "Approved",
                    method: "Online Filing",
                    processedBy: "Tax Department"
                }
            ];
        } catch (error) {
            console.error('Error fetching tax transactions:', error);
            throw new Error('Failed to fetch tax transactions');
        }
    }
}

class TaxManagementManager {
    constructor() {
        this.showLoadingStates();
        this.initialize();
    }

    showLoadingStates() {
        const sections = [
            'total-tax-liability',
            'effective-tax-rate',
            'next-filing',
            'tax-credits',
            'tax-deadlines',
            'filing-status',
            'tax-categories',
            'category-trends',
            'tax-transactions',
            'filing-history'
        ];
        
        sections.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.innerHTML = '<div class="loading-spinner"><i class="fas fa-circle-notch fa-spin"></i></div>';
            }
        });
    }

    async initialize() {
        await Promise.all([
            this.loadTaxOverview(),
            this.loadTaxCalendar(),
            this.loadTaxCategories(),
            this.loadTransactionsAndHistory()
        ]);
    }

    async loadTaxOverview() {
        try {
            const summaryData = await TaxManagementAPI.fetchTaxSummary();
            const liabilitiesData = await TaxManagementAPI.fetchTaxLiabilities();

            // Total Tax Liability
            document.getElementById('total-tax-liability').innerHTML = `
                <div class="metric-value">$${summaryData.totalTaxLiability.toLocaleString()}</div>
                <div class="metric-subtext">
                    <span class="paid">$${summaryData.paidTaxes.toLocaleString()} paid</span>
                    <span class="separator">|</span>
                    <span class="remaining">$${summaryData.remainingTaxes.toLocaleString()} remaining</span>
                </div>
            `;

            // Effective Tax Rate
            const totalIncome = 2500000; // This should come from API
            const effectiveRate = (summaryData.totalTaxLiability / totalIncome) * 100;
            document.getElementById('effective-tax-rate').innerHTML = `
                <div class="metric-value">${effectiveRate.toFixed(1)}%</div>
                <div class="metric-trend ${effectiveRate < 25 ? 'positive' : 'negative'}">
                    ${effectiveRate < 25 ? 'Below' : 'Above'} Average
                </div>
            `;

            // Next Filing
            const nextFiling = await TaxManagementAPI.fetchTaxCalendar();
            const nextDue = nextFiling.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))[0];
            document.getElementById('next-filing').innerHTML = `
                <div class="metric-value">${new Date(nextDue.dueDate).toLocaleDateString('en-US', {month: 'short', day: 'numeric'})}</div>
                <div class="metric-subtext">${nextDue.title}</div>
                <div class="metric-amount">$${nextDue.estimatedAmount.toLocaleString()}</div>
            `;

            // Tax Credits
            const totalCredits = liabilitiesData.reduce((acc, curr) => {
                return acc + (curr.credits || 0);
            }, 0);
            document.getElementById('tax-credits').innerHTML = `
                <div class="metric-value">$${totalCredits.toLocaleString()}</div>
                <div class="metric-subtext">Available Credits</div>
            `;

        } catch (error) {
            console.error('Error loading tax overview:', error);
            NotificationSystem.show('Failed to load tax overview', 'error');
        }
    }

    async loadTaxCalendar() {
        try {
            const events = await TaxManagementAPI.fetchTaxCalendar();
            
            // Tax Deadlines
            document.getElementById('tax-deadlines').innerHTML = `
                <div class="deadline-timeline">
                    ${events.map(event => `
                        <div class="deadline-event ${event.status}">
                            <div class="event-date">
                                <span class="month">${new Date(event.dueDate).toLocaleDateString('en-US', {month: 'short'})}</span>
                                <span class="day">${new Date(event.dueDate).getDate()}</span>
                            </div>
                            <div class="event-info">
                                <h4>${event.title}</h4>
                                <span class="amount">$${event.estimatedAmount.toLocaleString()}</span>
                            </div>
                            <div class="event-status">
                                <span class="status-badge ${event.status}">${event.status}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;

            // Filing Status
            const filingStatuses = events.reduce((acc, event) => {
                acc[event.status] = (acc[event.status] || 0) + 1;
                return acc;
            }, {});

            document.getElementById('filing-status').innerHTML = `
                <div class="filing-status-grid">
                    <div class="status-card">
                        <div class="status-icon urgent">
                            <i class="fas fa-exclamation-circle"></i>
                        </div>
                        <div class="status-info">
                            <span class="count">${filingStatuses.urgent || 0}</span>
                            <span class="label">Urgent</span>
                        </div>
                    </div>
                    <div class="status-card">
                        <div class="status-icon upcoming">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="status-info">
                            <span class="count">${filingStatuses.upcoming || 0}</span>
                            <span class="label">Upcoming</span>
                        </div>
                    </div>
                    <div class="status-card">
                        <div class="status-icon completed">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="status-info">
                            <span class="count">${filingStatuses.completed || 0}</span>
                            <span class="label">Completed</span>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading tax calendar:', error);
            NotificationSystem.show('Failed to load tax calendar', 'error');
        }
    }

    async loadTaxCategories() {
        try {
            const liabilities = await TaxManagementAPI.fetchTaxLiabilities();
            
            // Category Breakdown
            const totalAmount = liabilities.reduce((sum, item) => sum + item.amount, 0);
            
            document.getElementById('tax-categories').innerHTML = `
                <div class="category-breakdown">
                    ${liabilities.map(liability => `
                        <div class="category-row">
                            <div class="category-info">
                                <span class="category-name">${liability.type}</span>
                                <span class="category-period">${liability.period}</span>
                            </div>
                            <div class="category-bar">
                                <div class="bar-fill" style="width: ${(liability.amount / totalAmount * 100)}%">
                                    $${liability.amount.toLocaleString()}
                                </div>
                            </div>
                            <div class="category-percentage">
                                ${((liability.amount / totalAmount) * 100).toFixed(1)}%
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;

            // Category Trends
            document.getElementById('category-trends').innerHTML = `
                <div class="trend-chart">
                    <div class="chart-grid">
                        ${liabilities.map(liability => {
                            const trendValue = Math.random() * 10 - 5; // Simulated trend data
                            return `
                                <div class="trend-item">
                                    <div class="trend-header">
                                        <span class="trend-title">${liability.type}</span>
                                        <span class="trend-value ${trendValue >= 0 ? 'positive' : 'negative'}">
                                            ${trendValue >= 0 ? '+' : ''}${trendValue.toFixed(1)}%
                                        </span>
                                    </div>
                                    <div class="trend-graph">
                                        <div class="trend-line" style="--trend: ${50 + trendValue * 5}%"></div>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading tax categories:', error);
            NotificationSystem.show('Failed to load tax categories', 'error');
        }
    }

    async loadTransactionsAndHistory() {
        try {
            const transactions = await TaxManagementAPI.fetchTaxTransactions();
            
            // Recent Transactions
            document.getElementById('tax-transactions').innerHTML = `
                <div class="transaction-list">
                    ${transactions.map(tx => `
                        <div class="transaction-item">
                            <div class="transaction-icon">
                                <i class="fas fa-${tx.type.toLowerCase() === 'payment' ? 'arrow-up' : 'arrow-down'}"></i>
                            </div>
                            <div class="transaction-info">
                                <div class="transaction-header">
                                    <span class="transaction-type">${tx.taxType}</span>
                                    <span class="transaction-amount">$${tx.amount.toLocaleString()}</span>
                                </div>
                                <div class="transaction-details">
                                    <span class="transaction-date">${new Date(tx.date).toLocaleDateString('en-US', {
                                        month: 'short',
                                        day: 'numeric',
                                        year: 'numeric'
                                    })}</span>
                                    <span class="transaction-ref">${tx.reference}</span>
                                </div>
                            </div>
                            <div class="transaction-status">
                                <span class="status-badge">Completed</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;

            // Filing History (using the same transaction data for demonstration)
            document.getElementById('filing-history').innerHTML = `
                <div class="history-list">
                    <table class="data-table compact">
                        <thead>
                            <tr>
                                <th>Period</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Amount</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${transactions.map((tx, index) => `
                                <tr>
                                    <td>Q${Math.floor(index/3) + 1} 2025</td>
                                    <td>${tx.taxType}</td>
                                    <td><span class="status-badge completed">Filed</span></td>
                                    <td>$${tx.amount.toLocaleString()}</td>
                                    <td>
                                        <button class="icon-btn" title="View Filing">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="icon-btn" title="Download PDF">
                                            <i class="fas fa-download"></i>
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        } catch (error) {
            console.error('Error loading transactions and history:', error);
            NotificationSystem.show('Failed to load transactions and history', 'error');
        }
    }
}

// Add some specific styles for tax management
const styles = `
    .tax-calendar {
        display: grid;
        gap: 16px;
    }

    .tax-event {
        background: var(--card-bg);
        border-radius: calc(var(--border-radius) - 4px);
        padding: 16px;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .tax-event.urgent {
        border-left: 4px solid var(--danger-color);
    }

    .tax-event.upcoming {
        border-left: 4px solid var(--warning-color);
    }

    .event-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
    }

    .event-header h3 {
        margin: 0;
        font-size: 1.1rem;
        color: var(--text-color);
    }

    .event-amount {
        font-weight: 600;
        color: var(--primary-color);
    }

    .event-details {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0.9rem;
    }

    .due-date {
        color: var(--text-color);
        opacity: 0.8;
    }

    .status-badge {
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: 500;
    }

    .status-badge.urgent {
        background-color: var(--danger-color);
        color: white;
    }

    .status-badge.upcoming {
        background-color: var(--warning-color);
        color: var(--text-color);
    }
`;

// Add styles to the document
const styleSheet = document.createElement("style");
styleSheet.textContent = styles;
document.head.appendChild(styleSheet);

// Initialize tax management when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.taxManager = new TaxManagementManager();
});
