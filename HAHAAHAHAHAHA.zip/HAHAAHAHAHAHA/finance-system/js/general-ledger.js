class GeneralLedgerAPI {
    static async getSummary() {
        // Simulated API call for GL summary
        return {
            totalAssets: 2500000,
            totalLiabilities: 1000000,
            equity: 1500000,
            revenue: 1250000,
            expenses: 750000,
            netIncome: 500000,
            trend: '+3.2%'
        };
    }

    static async getPeriodOverview() {
        // Simulated API call for period overview
        return {
            currentPeriod: 'August 2025',
            status: 'open',
            entriesCount: 145,
            lastClosing: '2025-07-31',
            nextClosing: '2025-08-31'
        };
    }

    static async getJournalEntries() {
        // Simulated API call for journal entries
        return [
            {
                id: 'JE001',
                date: '2025-08-14',
                description: 'Sales Revenue Recording',
                amount: 50000,
                type: 'revenue',
                status: 'posted'
            },
            // Add more entries...
        ];
    }

    static async getAccountBalances() {
        // Simulated API call for account balances
        return {
            assets: [
                { account: 'Cash', balance: 500000, change: '+2.3%' },
                { account: 'Accounts Receivable', balance: 300000, change: '-1.5%' },
                { account: 'Inventory', balance: 750000, change: '+0.8%' }
            ],
            liabilities: [
                { account: 'Accounts Payable', balance: -200000, change: '-3.1%' },
                { account: 'Long-term Debt', balance: -800000, change: '0.0%' }
            ]
        };
    }

    static async getRecentTransactions() {
        // Simulated API call for recent transactions
        return [
            {
                id: 'TRX001',
                date: '2025-08-14',
                description: 'Sales Revenue',
                debit: 50000,
                credit: 0,
                department: 'Sales',
                status: 'completed'
            },
            // Add more transactions...
        ];
    }

    static async getIncomeStatement() {
        // Simulated API call for income statement
        return {
            revenue: {
                sales: 1000000,
                otherIncome: 250000
            },
            expenses: {
                cogs: 400000,
                operational: 250000,
                administrative: 100000
            },
            trends: {
                revenue: '+5.2%',
                expenses: '+2.1%',
                netIncome: '+8.4%'
            }
        };
    }

    static async getBalanceSheet() {
        // Simulated API call for balance sheet
        return {
            assets: {
                current: 1500000,
                fixed: 1000000
            },
            liabilities: {
                current: 400000,
                longTerm: 600000
            },
            equity: {
                capital: 1000000,
                retained: 500000
            }
        };
    }
}

class GeneralLedgerManager {
    constructor() {
        this.initializeEventListeners();
        this.loadAllData();
    }

    initializeEventListeners() {
        // New Entry button
        document.querySelector('.card-actions .primary').addEventListener('click', () => {
            // Implement new journal entry creation
            NotificationSystem.show('New journal entry form opened', 'info');
        });

        // Filter button
        document.querySelector('.action-btn').addEventListener('click', () => {
            // Implement filtering
            NotificationSystem.show('Filters applied', 'info');
        });
    }

    async loadAllData() {
        await Promise.all([
            this.loadGLSummary(),
            this.loadPeriodOverview(),
            this.loadJournalEntries(),
            this.loadAccountBalances(),
            this.loadRecentTransactions(),
            this.loadIncomeStatement(),
            this.loadBalanceSheet()
        ]);
    }

    async loadGLSummary() {
        try {
            const data = await GeneralLedgerAPI.getSummary();
            document.getElementById('gl-summary').innerHTML = `
                <div class="metrics-grid">
                    <div class="metric">
                        <span class="metric-label">Total Assets</span>
                        <span class="metric-value">$${this.formatNumber(data.totalAssets)}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Total Liabilities</span>
                        <span class="metric-value">$${this.formatNumber(data.totalLiabilities)}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Equity</span>
                        <span class="metric-value">$${this.formatNumber(data.equity)}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Net Income</span>
                        <span class="metric-value">$${this.formatNumber(data.netIncome)}</span>
                        <span class="metric-trend ${data.trend.startsWith('+') ? 'positive' : 'negative'}">
                            ${data.trend}
                        </span>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading GL summary:', error);
            NotificationSystem.show('Failed to load GL summary', 'error');
        }
    }

    async loadPeriodOverview() {
        try {
            const data = await GeneralLedgerAPI.getPeriodOverview();
            document.getElementById('period-overview').innerHTML = `
                <div class="period-info">
                    <div class="current-period">
                        <span class="period-label">Current Period</span>
                        <span class="period-value">${data.currentPeriod}</span>
                        <span class="status-badge ${data.status}">${data.status}</span>
                    </div>
                    <div class="period-metrics">
                        <div class="metric">
                            <span class="metric-label">Entries</span>
                            <span class="metric-value">${data.entriesCount}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Last Closing</span>
                            <span class="metric-value">${this.formatDate(data.lastClosing)}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Next Closing</span>
                            <span class="metric-value">${this.formatDate(data.nextClosing)}</span>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading period overview:', error);
            NotificationSystem.show('Failed to load period overview', 'error');
        }
    }

    async loadJournalEntries() {
        try {
            const entries = await GeneralLedgerAPI.getJournalEntries();
            document.getElementById('journal-entries').innerHTML = `
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Entry #</th>
                            <th>Date</th>
                            <th>Description</th>
                            <th>Amount</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${entries.map(entry => `
                            <tr>
                                <td>${entry.id}</td>
                                <td>${this.formatDate(entry.date)}</td>
                                <td>${entry.description}</td>
                                <td>$${this.formatNumber(entry.amount)}</td>
                                <td><span class="badge ${entry.type}">${entry.type}</span></td>
                                <td><span class="status-badge ${entry.status}">${entry.status}</span></td>
                                <td>
                                    <button class="icon-btn" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="icon-btn" title="Edit Entry">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        } catch (error) {
            console.error('Error loading journal entries:', error);
            NotificationSystem.show('Failed to load journal entries', 'error');
        }
    }

    async loadAccountBalances() {
        try {
            const data = await GeneralLedgerAPI.getAccountBalances();
            document.getElementById('account-balances').innerHTML = `
                <div class="account-sections">
                    <div class="account-section">
                        <h3>Assets</h3>
                        ${this.renderAccountList(data.assets)}
                    </div>
                    <div class="account-section">
                        <h3>Liabilities</h3>
                        ${this.renderAccountList(data.liabilities)}
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading account balances:', error);
            NotificationSystem.show('Failed to load account balances', 'error');
        }
    }

    async loadRecentTransactions() {
        try {
            const transactions = await GeneralLedgerAPI.getRecentTransactions();
            document.getElementById('recent-transactions').innerHTML = `
                <div class="transaction-list">
                    ${transactions.map(tx => `
                        <div class="transaction-item">
                            <div class="transaction-header">
                                <span class="transaction-id">${tx.id}</span>
                                <span class="transaction-date">${this.formatDate(tx.date)}</span>
                            </div>
                            <div class="transaction-details">
                                <div class="transaction-description">${tx.description}</div>
                                <div class="transaction-department">${tx.department}</div>
                            </div>
                            <div class="transaction-amounts">
                                <div class="amount debit">$${this.formatNumber(tx.debit)}</div>
                                <div class="amount credit">$${this.formatNumber(tx.credit)}</div>
                            </div>
                            <span class="status-badge ${tx.status}">${tx.status}</span>
                        </div>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            console.error('Error loading recent transactions:', error);
            NotificationSystem.show('Failed to load recent transactions', 'error');
        }
    }

    async loadIncomeStatement() {
        try {
            const data = await GeneralLedgerAPI.getIncomeStatement();
            document.getElementById('income-statement').innerHTML = `
                <div class="financial-statement">
                    <div class="statement-section">
                        <h3>Revenue</h3>
                        <div class="statement-item">
                            <span class="item-label">Sales Revenue</span>
                            <span class="item-value">$${this.formatNumber(data.revenue.sales)}</span>
                        </div>
                        <div class="statement-item">
                            <span class="item-label">Other Income</span>
                            <span class="item-value">$${this.formatNumber(data.revenue.otherIncome)}</span>
                        </div>
                    </div>
                    <div class="statement-section">
                        <h3>Expenses</h3>
                        <div class="statement-item">
                            <span class="item-label">Cost of Goods Sold</span>
                            <span class="item-value">$${this.formatNumber(data.expenses.cogs)}</span>
                        </div>
                        <div class="statement-item">
                            <span class="item-label">Operational Expenses</span>
                            <span class="item-value">$${this.formatNumber(data.expenses.operational)}</span>
                        </div>
                        <div class="statement-item">
                            <span class="item-label">Administrative Expenses</span>
                            <span class="item-value">$${this.formatNumber(data.expenses.administrative)}</span>
                        </div>
                    </div>
                    <div class="statement-trends">
                        <div class="trend-item">
                            <span class="trend-label">Revenue Trend</span>
                            <span class="trend-value ${data.trends.revenue.startsWith('+') ? 'positive' : 'negative'}">
                                ${data.trends.revenue}
                            </span>
                        </div>
                        <div class="trend-item">
                            <span class="trend-label">Net Income Trend</span>
                            <span class="trend-value ${data.trends.netIncome.startsWith('+') ? 'positive' : 'negative'}">
                                ${data.trends.netIncome}
                            </span>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading income statement:', error);
            NotificationSystem.show('Failed to load income statement', 'error');
        }
    }

    async loadBalanceSheet() {
        try {
            const data = await GeneralLedgerAPI.getBalanceSheet();
            document.getElementById('balance-sheet').innerHTML = `
                <div class="financial-statement">
                    <div class="statement-section">
                        <h3>Assets</h3>
                        <div class="statement-item">
                            <span class="item-label">Current Assets</span>
                            <span class="item-value">$${this.formatNumber(data.assets.current)}</span>
                        </div>
                        <div class="statement-item">
                            <span class="item-label">Fixed Assets</span>
                            <span class="item-value">$${this.formatNumber(data.assets.fixed)}</span>
                        </div>
                    </div>
                    <div class="statement-section">
                        <h3>Liabilities & Equity</h3>
                        <div class="statement-item">
                            <span class="item-label">Current Liabilities</span>
                            <span class="item-value">$${this.formatNumber(data.liabilities.current)}</span>
                        </div>
                        <div class="statement-item">
                            <span class="item-label">Long-term Liabilities</span>
                            <span class="item-value">$${this.formatNumber(data.liabilities.longTerm)}</span>
                        </div>
                        <div class="statement-item">
                            <span class="item-label">Capital</span>
                            <span class="item-value">$${this.formatNumber(data.equity.capital)}</span>
                        </div>
                        <div class="statement-item">
                            <span class="item-label">Retained Earnings</span>
                            <span class="item-value">$${this.formatNumber(data.equity.retained)}</span>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading balance sheet:', error);
            NotificationSystem.show('Failed to load balance sheet', 'error');
        }
    }

    renderAccountList(accounts) {
        return `
            <div class="account-list">
                ${accounts.map(account => `
                    <div class="account-item">
                        <div class="account-info">
                            <span class="account-name">${account.account}</span>
                            <span class="account-balance">$${this.formatNumber(Math.abs(account.balance))}</span>
                        </div>
                        <span class="account-trend ${account.change.startsWith('+') ? 'positive' : 'negative'}">
                            ${account.change}
                        </span>
                    </div>
                `).join('')}
            </div>
        `;
    }

    formatNumber(number) {
        return new Intl.NumberFormat('en-US').format(number);
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
}
class JournalEntriesManager {
    constructor() {
        this.container = document.getElementById("journal-entries");
        this.newEntryBtn = document.querySelector(".action-btn.primary");

        this.entries = [];
        this.showLoading();
        this.initialize();

        if (this.newEntryBtn) {
            this.newEntryBtn.addEventListener("click", () => this.showAddEntryForm());
        }
    }

    showLoading() {
        if (this.container) {
            this.container.innerHTML = `<div class="loading-spinner">
                <i class="fas fa-circle-notch fa-spin"></i> Loading entries...
            </div>`;
        }
    }

    async initialize() {
        try {
            this.entries = await this.fetchJournalEntries();
            this.renderEntries();
        } catch (error) {
            console.error("Error loading journal entries:", error);
            this.container.innerHTML = `<div class="error">Failed to load journal entries.</div>`;
        }
    }

    async fetchJournalEntries() {
        // Simulated API call — replace with your actual backend fetch
        return new Promise(resolve => {
            setTimeout(() => {
                resolve([
                    { date: "2025-08-10", description: "Sale of goods", debit: 5000, credit: 0 },
                    { date: "2025-08-11", description: "Office Supplies Purchase", debit: 0, credit: 1200 }
                ]);
            }, 500);
        });
    }

    showAddEntryForm() {
        const formHtml = `
            <div class="entry-form">
                <label>Date: <input type="date" id="entry-date" required></label>
                <label>Description: <input type="text" id="entry-desc" required></label>
                <label>Debit: <input type="number" id="entry-debit" value="0"></label>
                <label>Credit: <input type="number" id="entry-credit" value="0"></label>
                <div class="form-actions">
                    <button id="save-entry" class="action-btn primary">Save</button>
                    <button id="cancel-entry" class="action-btn">Cancel</button>
                </div>
            </div>
        `;

        this.container.insertAdjacentHTML("beforebegin", formHtml);

        document.getElementById("save-entry").addEventListener("click", () => this.addEntry());
        document.getElementById("cancel-entry").addEventListener("click", () => this.cancelEntryForm());
    }

    cancelEntryForm() {
        const form = document.querySelector(".entry-form");
        if (form) form.remove();
    }

    addEntry() {
        const date = document.getElementById("entry-date").value;
        const description = document.getElementById("entry-desc").value;
        const debit = parseFloat(document.getElementById("entry-debit").value) || 0;
        const credit = parseFloat(document.getElementById("entry-credit").value) || 0;

        if (!date || !description) {
            alert("Please fill in all required fields.");
            return;
        }

        this.entries.push({ date, description, debit, credit });
        this.renderEntries();
        this.cancelEntryForm();
    }

    renderEntries() {
        if (!this.entries.length) {
            this.container.innerHTML = `<p>No journal entries found.</p>`;
            return;
        }

        this.container.innerHTML = `
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Description</th>
                        <th>Debit</th>
                        <th>Credit</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.entries.map(entry => `
                        <tr>
                            <td>${entry.date}</td>
                            <td>${entry.description}</td>
                            <td>${entry.debit ? `$${entry.debit.toLocaleString()}` : "-"}</td>
                            <td>${entry.credit ? `$${entry.credit.toLocaleString()}` : "-"}</td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
        `;
    }
}

document.addEventListener("DOMContentLoaded", () => {
    new JournalEntriesManager();
});


// Initialize GL manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.glManager = new GeneralLedgerManager();
});
