
import { db, fmt, notify } from './db.js';

export function initGL(){
  const el = document.getElementById('content');
  const coa = db.get('coa');
  const entries = db.get('journals');

  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>General Ledger</h2>
        <div class="hstack gap-1">
          <button id="btn-add-journal" class="btn btn-primary">New Journal Entry</button>
          <button id="btn-export-gl" class="btn">Export JSON</button>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Chart of Accounts</div></div>
        <div class="grid grid-3">
          ${coa.map(a=>`<div class="card"><div class="muted tiny">${a.type.toUpperCase()}</div><b>${a.code}</b> - ${a.name}</div>`).join('')}
        </div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Entries</div></div>
        <table class="table">
          <thead><tr><th>Date</th><th>Ref</th><th>Account</th><th>Debit</th><th>Credit</th><th>Dept/Proj</th><th>Memo</th></tr></thead>
          <tbody id="gl-rows"></tbody>
        </table>
      </div>
    </section>
  `;

  renderRows();

  document.getElementById('btn-add-journal').onclick = () => {
    const date = prompt('Date (YYYY-MM-DD)', fmt.date(new Date()));
    const account = prompt('Account code (e.g., 1000, 4000, 5000)');
    const debit = parseFloat(prompt('Debit amount (0 if none)','0')||'0');
    const credit = parseFloat(prompt('Credit amount (0 if none)','0')||'0');
    const memo = prompt('Memo','Manual JE');
    const ref = 'JE-'+fmt.uuid();
    const row = {date, ref, account, debit, credit, dept:'-', proj:'-', memo};
    db.set('journals', [row, ...db.get('journals')]);
    if(account==='1000'){ const meta = db.get('meta'); meta.cash += (debit-credit); db.set('meta', meta); }
    notify(`GL Journal ${ref} posted.`,'info', ref);
    renderRows();
  };

  document.getElementById('btn-export-gl').onclick = () => {
    const blob = new Blob([JSON.stringify(db.get('journals'), null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href=url; a.download='gl_entries.json'; a.click(); URL.revokeObjectURL(url);
  };

  function renderRows(){
    const body = document.getElementById('gl-rows');
    body.innerHTML = (db.get('journals')||[]).map(e=>`
      <tr>
        <td>${e.date}</td><td>${e.ref}</td><td>${e.account}</td>
        <td>${fmt.money(e.debit||0)}</td><td>${fmt.money(e.credit||0)}</td>
        <td>${e.dept||''}/${e.proj||''}</td><td>${e.memo||''}</td>
      </tr>
    `).join('');
  }
}
