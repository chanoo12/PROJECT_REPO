
import { bus, db } from './db.js';

export function initUI(){
  // notifications popover
  const btn = document.getElementById('notif-btn');
  const panel = document.getElementById('notif-panel');
  const badge = document.getElementById('notif-badge');
  const list = document.getElementById('notif-list');
  const markAll = document.getElementById('notif-markall');
  const userBtn = document.getElementById('user-menu-btn');
  const userMenu = document.getElementById('user-menu');

  function renderList(){
    const items = db.get('notifications') || [];
    const unread = items.filter(i=>!i.read).length;
    badge.textContent = unread;
    badge.classList.toggle('hidden', unread===0);
    list.innerHTML = items.map(i => `<li class="card">
      <div class="hstack gap-1"><span class="tag">${new Date(i.date).toLocaleString()}</span><span class="tag ${i.type}">${i.type}</span></div>
      <div style="margin-top:6px">${i.text}</div>
    </li>`).join('');
  }
  renderList();

  btn.addEventListener('click', ()=> panel.classList.toggle('hidden'));
  markAll.addEventListener('click', ()=>{
    const items = (db.get('notifications')||[]).map(i=>({...i, read:true}));
    db.set('notifications', items); renderList();
  });
  document.addEventListener('click', (e)=>{
    if(!panel.contains(e.target) && e.target!==btn) panel.classList.add('hidden');
    if(!userMenu.contains(e.target) && e.target!==userBtn) userMenu.classList.add('hidden');
  });
  userBtn.addEventListener('click', ()=> userMenu.classList.toggle('hidden'));

  bus.on('notif', renderList);
  bus.on('change', renderList);
}
