
import { db, fmt, notify, state } from './db.js';

export function initTax(){
  const el = document.getElementById('content');
  const vat = state().vat || 12;
  const vatPayable = (db.get('vatledger')||[]).reduce((s,v)=>s+v.vat*(v.type==='output'?1:-1),0);
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Tax Management</h2>
        <button id="btn-set-vat" class="btn btn-primary">Set VAT Rate</button>
      </div>
      <div class="grid grid-3">
        <div class="kpi"><div class="label">Current VAT Rate</div><div class="value" id="vat-rate">${vat}%</div></div>
        <div class="kpi"><div class="label">VAT Payable</div><div class="value" id="vat-payable">${fmt.money(vatPayable)}</div></div>
        <div class="kpi"><div class="label">Withholding Tax (Net)</div><div class="value" id="wht-net">${fmt.money(0)}</div></div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">VAT Ledger</div></div>
        <table class="table">
          <thead><tr><th>Date</th><th>Type</th><th>Base</th><th>VAT</th><th>Ref</th></tr></thead>
          <tbody id="vat-rows"></tbody>
        </table>
      </div>
    </section>
  `;

  document.getElementById('btn-set-vat').onclick = () => {
    const rate = parseFloat(prompt('VAT %', state().vat||12)||'12');
    db.patch('meta', {vat: rate});
    notify(`VAT rate set to ${rate}%`,'info');
    initTax();
  };

  const rows = document.getElementById('vat-rows');
  rows.innerHTML = (db.get('vatledger')||[]).map(v=>`<tr>
    <td>${v.date}</td><td>${v.type}</td><td>${fmt.money(v.base)}</td><td>${fmt.money(v.vat)}</td><td>${v.ref}</td>
  </tr>`).join('');
}
