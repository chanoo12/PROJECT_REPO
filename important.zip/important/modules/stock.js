
import { db, fmt, notify } from './db.js';

function updateInventoryValue(){
  const value = (db.get('items')||[]).reduce((s,i)=>s+i.avgCost*i.onHand,0);
  const meta = db.get('meta'); meta.inventoryValue = value; db.set('meta', meta);
}

export function initStock(){
  const el = document.getElementById('content');
  const items = db.get('items')||[];
  const qty = items.reduce((s,i)=>s+i.onHand,0);
  const value = items.reduce((s,i)=>s+i.avgCost*i.onHand,0);
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Stock Movement</h2>
        <div class="hstack gap-1">
          <button id="btn-add-item" class="btn">Add Item</button>
          <button id="btn-receipt" class="btn btn-primary">Receive Stock</button>
          <button id="btn-issue" class="btn">Issue/Sell</button>
          <button id="btn-transfer" class="btn">Transfer</button>
        </div>
      </div>
      <div class="grid grid-3">
        <div class="kpi"><div class="label">Total Items</div><div class="value" id="inv-items">${items.length}</div></div>
        <div class="kpi"><div class="label">On-hand Qty</div><div class="value" id="inv-qty">${qty}</div></div>
        <div class="kpi"><div class="label">Inventory Value</div><div class="value" id="inv-value">${fmt.money(value)}</div></div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Items</div></div>
        <table class="table"><thead><tr><th>SKU</th><th>Name</th><th>Avg Cost</th><th>On-hand</th></tr></thead>
        <tbody id="item-rows"></tbody></table>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Movements</div></div>
        <table class="table"><thead><tr><th>Date</th><th>Type</th><th>SKU</th><th>Qty</th><th>Unit Cost</th><th>Ref</th></tr></thead>
        <tbody id="mov-rows"></tbody></table>
      </div>
    </section>
  `;
  render();

  document.getElementById('btn-add-item').onclick = () => {
    const sku = 'ITEM-'+fmt.uuid();
    const name = prompt('Item name','New Item');
    const avgCost = parseFloat(prompt('Avg Cost','100')||'0');
    const onHand = parseInt(prompt('Starting Qty','0')||'0',10);
    db.set('items', [...db.get('items'), {sku, name, avgCost, onHand}]);
    notify(`Item ${name} added.`,'info', sku);
    initStock();
  };

  document.getElementById('btn-receipt').onclick = () => {
    const sku = prompt('SKU', (db.get('items')[0]||{}).sku||'ITEM-001');
    const qty = parseInt(prompt('Qty','10')||'0',10);
    const unit = parseFloat(prompt('Unit Cost','100')||'0');
    const date = fmt.date(new Date()); const ref = 'RCV-'+fmt.uuid();
    // update avg cost
    const items = db.get('items').map(i=>{
      if(i.sku===sku){
        const totalCost = i.avgCost*i.onHand + unit*qty;
        i.onHand += qty;
        i.avgCost = i.onHand>0 ? totalCost/i.onHand : unit;
      }
      return i;
    });
    db.set('items', items);
    db.set('movements', [{date, type:'RECEIPT', sku, qty, unit, ref}, ...db.get('movements')]);
    // GL: DR Inventory 1200, CR Cash 1000
    const je1 = {date, ref, account:'1200', debit:qty*unit, credit:0, memo:'Receive Stock'};
    const je2 = {date, ref, account:'1000', debit:0, credit:qty*unit, memo:'Cash Out'};
    db.set('journals', [je1, je2, ...db.get('journals')]);
    const meta = db.get('meta'); meta.cash -= qty*unit; db.set('meta', meta);
    updateInventoryValue();
    notify(`Received ${qty} of ${sku}.`,'ok', ref);
    initStock();
  };

  document.getElementById('btn-issue').onclick = () => {
    const sku = prompt('SKU', (db.get('items')[0]||{}).sku||'ITEM-001');
    const qty = parseInt(prompt('Qty','5')||'0',10);
    const date = fmt.date(new Date()); const ref = 'ISS-'+fmt.uuid();
    const items = db.get('items').map(i=>{
      if(i.sku===sku){ i.onHand -= qty; if(i.onHand<0) i.onHand=0; }
      return i;
    });
    // Compute COGS at avg cost
    const item = db.get('items').find(i=>i.sku===sku);
    const unit = item?.avgCost||0;
    db.set('items', items);
    db.set('movements', [{date, type:'ISSUE', sku, qty:-qty, unit, ref}, ...db.get('movements')]);
    // GL: DR COGS 5000, CR Inventory 1200
    const je1 = {date, ref, account:'5000', debit:qty*unit, credit:0, memo:'COGS'};
    const je2 = {date, ref, account:'1200', debit:0, credit:qty*unit, memo:'Inventory Out'};
    db.set('journals', [je1, je2, ...db.get('journals')]);
    updateInventoryValue();
    notify(`Issued ${qty} of ${sku}.`,'info', ref);
    initStock();
  };

  document.getElementById('btn-transfer').onclick = () => {
    const sku = prompt('SKU to transfer',(db.get('items')[0]||{}).sku||'');
    const qty = parseInt(prompt('Qty','1')||'0',10);
    const date = fmt.date(new Date()); const ref = 'TRF-'+fmt.uuid();
    db.set('movements', [{date, type:'TRANSFER', sku, qty:0, unit:0, ref}, ...db.get('movements')]);
    notify(`Transfer recorded for ${sku} (${qty}).`,'info', ref);
    initStock();
  };

  function render(){
    const tbody = document.getElementById('item-rows');
    tbody.innerHTML = (db.get('items')||[]).map(i=>`<tr><td>${i.sku}</td><td>${i.name}</td><td>${fmt.money(i.avgCost)}</td><td>${i.onHand}</td></tr>`).join('');
    const mbody = document.getElementById('mov-rows');
    mbody.innerHTML = (db.get('movements')||[]).map(m=>`<tr><td>${m.date}</td><td>${m.type}</td><td>${m.sku}</td><td>${m.qty}</td><td>${fmt.money(m.unit)}</td><td>${m.ref}</td></tr>`).join('');
  }
}
