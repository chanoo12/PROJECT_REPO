
import { db, fmt, notify } from './db.js';

export function initInventoryConnector(){
  const el = document.getElementById('content');
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Inventory Connector</h2>
        <div class="hstack gap-1">
          <button id="btn-sync-cogs" class="btn btn-primary">Sync COGS from Issues → GL</button>
          <button id="btn-sync-items" class="btn">Import Sample Items</button>
        </div>
      </div>
      <div class="card">
        <p class="muted">Ang COGS ay kinuha mula sa ISSUE movements (average cost) at ipo-post sa GL bilang DR COGS / CR Inventory.</p>
      </div>
    </section>
  `;

  document.getElementById('btn-sync-items').onclick = () => {
    const more = [
      {sku:'ITEM-003', name:'Widget C', avgCost:180, onHand:15},
      {sku:'ITEM-004', name:'Widget D', avgCost:90, onHand:40}
    ];
    db.set('items', [...db.get('items'), ...more]);
    notify('Inventory items imported.','info');
    window.navigate('stock-movement');
  };

  document.getElementById('btn-sync-cogs').onclick = () => {
    const issues = (db.get('movements')||[]).filter(m=>m.type==='ISSUE' && !m.synced);
    issues.forEach(m=>{
      const date = m.date, ref = 'COGS-'+m.ref;
      const amt = Math.abs(m.qty)*m.unit;
      const je1 = {date, ref, account:'5000', debit:amt, credit:0, memo:'COGS (Sync)'};
      const je2 = {date, ref, account:'1200', debit:0, credit:amt, memo:'Inventory Out (Sync)'};
      db.set('journals', [je1, je2, ...db.get('journals')]);
      m.synced = true;
    });
    db.set('movements', [...db.get('movements')]);
    notify(`COGS synced for ${issues.length} issues.`,'ok');
    window.navigate('dashboard');
  };
}
