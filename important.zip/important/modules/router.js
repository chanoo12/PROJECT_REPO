
import { bus } from './db.js';

export function mountRouter(routes){
  const content = document.getElementById('content');
  const nav = document.getElementById('nav');
  const toggle = document.getElementById('toggle-sidebar');
  const sidebar = document.getElementById('sidebar');

  function render(route){
    // set active
    nav.querySelectorAll('.navlink').forEach(a => a.classList.remove('active'));
    const link = nav.querySelector(`[data-route="${route}"]`);
    if(link) link.classList.add('active');
    // call module
    const fn = routes[route] || routes['dashboard'];
    fn();
    window.location.hash = route;
  }

  // hash routing
  const initial = (location.hash||'#dashboard').replace('#','');
  render(initial);

  nav.querySelectorAll('.navlink').forEach(a => a.addEventListener('click', (e)=>{
    e.preventDefault();
    render(a.dataset.route);
  }));

  toggle.addEventListener('click', ()=>{
    sidebar.classList.toggle('hidden');
  });

  // expose
  window.navigate = render;
}
