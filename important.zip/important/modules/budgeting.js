
import { db, fmt, notify } from './db.js';

export function initBudgeting(){
  const el = document.getElementById('content');
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Budgeting</h2>
        <button id="btn-add-budget" class="btn btn-primary">New Budget</button>
      </div>
      <div class="card">
        <table class="table">
          <thead><tr><th>Year</th><th>Dept/Project</th><th>Category</th><th>Amount</th><th>Actual</th><th>Variance</th></tr></thead>
          <tbody id="budget-rows"></tbody>
        </table>
      </div>
    </section>
  `;
  render();

  document.getElementById('btn-add-budget').onclick = () => {
    const year = parseInt(prompt('Year', new Date().getFullYear())||new Date().getFullYear(),10);
    const scope = prompt('Dept/Project','Ops');
    const category = prompt('Category','OPEX');
    const amount = parseFloat(prompt('Amount','100000')||'0');
    const row = {year, scope, category, amount, actual:0};
    db.set('budgets', [row, ...db.get('budgets')]);
    notify(`Budget for ${scope} added.`,'info');
    render();
  };

  function render(){
    const body = document.getElementById('budget-rows');
    body.innerHTML = (db.get('budgets')||[]).map(b=>{
      const variance = (b.amount||0) - (b.actual||0);
      return `<tr>
        <td>${b.year}</td><td>${b.scope}</td><td>${b.category}</td>
        <td>${fmt.money(b.amount)}</td><td>${fmt.money(b.actual||0)}</td><td>${fmt.money(variance)}</td>
      </tr>`;
    }).join('');
  }
}
