
import { db, fmt, notify } from './db.js';

export function initPayroll(){
  const el = document.getElementById('content');
  const ytd = (db.get('payruns')||[]).reduce((s,p)=>s+p.gross,0);
  const last = (db.get('payruns')[0]||{}).date || '—';
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Payroll</h2>
        <div class="hstack gap-1">
          <button id="btn-add-emp" class="btn">Add Employee</button>
          <button id="btn-run-payroll" class="btn btn-primary">Run Payroll</button>
        </div>
      </div>
      <div class="grid grid-3">
        <div class="kpi"><div class="label">Employees</div><div class="value" id="pay-emps">${(db.get('employees')||[]).length}</div></div>
        <div class="kpi"><div class="label">Last Payroll</div><div class="value" id="pay-last">${last}</div></div>
        <div class="kpi"><div class="label">Total Payroll (YTD)</div><div class="value" id="pay-ytd">${fmt.money(ytd)}</div></div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">Employees</div></div>
        <table class="table">
          <thead><tr><th>Emp #</th><th>Name</th><th>Rate</th><th>Dept</th></tr></thead>
          <tbody id="emp-rows"></tbody>
        </table>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Payroll Runs</div></div>
        <table class="table">
          <thead><tr><th>Date</th><th>Period</th><th>Gross</th><th>Net</th></tr></thead>
          <tbody id="prun-rows"></tbody>
        </table>
      </div>
    </section>
  `;
  render();

  document.getElementById('btn-add-emp').onclick = () => {
    const id = 'EMP-'+fmt.uuid();
    const name = prompt('Employee name','New Employee')||'Employee';
    const rate = parseFloat(prompt('Daily Rate','2000')||'0');
    const dept = prompt('Department','Ops');
    db.set('employees', [...db.get('employees'), {id, name, rate, dept}]);
    notify(`Employee ${name} added.`,'info', id);
    initPayroll();
  };

  document.getElementById('btn-run-payroll').onclick = () => {
    const days = parseInt(prompt('Days worked (this period)','10')||'0',10);
    const gross = (db.get('employees')||[]).reduce((s,e)=>s + e.rate*days,0);
    const tax = gross * 0.1;
    const net = gross - tax;
    const date = fmt.date(new Date());
    const run = {date, period:`${days} days`, gross, net};
    db.set('payruns', [run, ...db.get('payruns')]);
    // GL: DR Payroll Expense 5200, CR Cash 1000, CR Withholding (ignore ledger)
    const je1 = {date, ref:'PAY-'+fmt.uuid(), account:'5200', debit:gross, credit:0, memo:'Payroll Expense'};
    const je2 = {date, ref:je1.ref, account:'1000', debit:0, credit:net, memo:'Cash Out'};
    db.set('journals', [je1, je2, ...db.get('journals')]);
    // Cash down
    const meta = db.get('meta'); meta.cash -= net; db.set('meta', meta);
    notify(`Payroll run posted (${fmt.money(net)} net).`,'ok', run.date);
    initPayroll();
  };

  function render(){
    const ebody = document.getElementById('emp-rows');
    ebody.innerHTML = (db.get('employees')||[]).map(e=>`<tr>
      <td>${e.id}</td><td>${e.name}</td><td>${fmt.money(e.rate)}</td><td>${e.dept}</td>
    </tr>`).join('');
    const pbody = document.getElementById('prun-rows');
    pbody.innerHTML = (db.get('payruns')||[]).map(p=>`<tr>
      <td>${p.date}</td><td>${p.period}</td><td>${fmt.money(p.gross)}</td><td>${fmt.money(p.net)}</td>
    </tr>`).join('');
  }
}
