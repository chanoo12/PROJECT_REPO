
import { db, fmt, notify, state } from './db.js';

export function initCRM(){
  const el = document.getElementById('content');
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>CRM (Sales Data)</h2>
        <button id="btn-import-sales" class="btn btn-primary">Import Sales → AR & GL</button>
      </div>
      <div class="card">
        <p class="muted">Gamit ang button sa itaas, magge-generate tayo ng sample sales (VAT inclusive) at automatic itong magiging Invoice sa AR, may VAT Output sa Tax, at Sales entry sa GL.</p>
      </div>
    </section>
  `;

  document.getElementById('btn-import-sales').onclick = () => {
    const count = parseInt(prompt('Gilang invoices to create?','3')||'0',10);
    const rate = (state().vat||12)/100;
    const cust = (db.get('customers')[0]||{name:'Acme Co.'}).name;
    for(let k=0;k<count;k++){
      const amount = Math.round(10000 + Math.random()*40000);
      const ref = 'INV-'+fmt.uuid();
      const date = fmt.date(new Date());
      const inv = {date, customer:cust, ref, amount, status:'Open'};
      db.set('invoices', [inv, ...db.get('invoices')]);
      const base = amount / (1+rate); const vat = amount - base;
      db.set('vatledger', [{date, type:'output', base, vat, ref}, ...db.get('vatledger')]);
      const je1 = {date, ref, account:'1100', debit:amount, credit:0, memo:`Invoice ${cust}`};
      const je2 = {date, ref, account:'4000', debit:0, credit:base, memo:'Sales'};
      const je3 = {date, ref, account:'2100', debit:0, credit:vat, memo:'VAT Output'};
      db.set('journals', [je1, je2, je3, ...db.get('journals')]);
    }
    notify(`CRM: ${count} sales synced to AR/GL.`, 'ok');
    window.navigate('areceivable');
  };
}
