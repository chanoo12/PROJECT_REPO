
import { db, fmt, notify, state } from './db.js';

export function initAR(){
  const el = document.getElementById('content');
  const out = (db.get('invoices')||[]).filter(i=>i.status!=='Paid').reduce((s,i)=>s+i.amount,0);
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Accounts Receivable</h2>
        <div class="hstack gap-1">
          <button id="btn-add-customer" class="btn">Add Customer</button>
          <button id="btn-add-invoice" class="btn btn-primary">New Invoice</button>
          <button id="btn-receive-payment" class="btn">Record Payment</button>
        </div>
      </div>
      <div class="grid grid-3">
        <div class="kpi"><div class="label">AR Outstanding</div><div class="value" id="ar-out">${fmt.money(out)}</div></div>
        <div class="kpi"><div class="label">Customers</div><div class="value" id="ar-customers">${(db.get('customers')||[]).length}</div></div>
        <div class="kpi"><div class="label">Invoices</div><div class="value" id="ar-invoices">${(db.get('invoices')||[]).length}</div></div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Invoices</div></div>
        <table class="table">
          <thead><tr><th>Date</th><th>Customer</th><th>Ref</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody id="ar-rows"></tbody>
        </table>
      </div>
    </section>
  `;
  render();

  document.getElementById('btn-add-customer').onclick = () => {
    const id = 'CUST-'+fmt.uuid();
    const name = prompt('Customer name','New Customer')||'Customer';
    db.set('customers', [...db.get('customers'), {id, name}]);
    notify(`Customer ${name} added.`,'info', id);
    initAR();
  };

  document.getElementById('btn-add-invoice').onclick = () => {
    const cust = prompt('Customer name', (db.get('customers')[0]||{}).name||'Acme Co.');
    const amount = parseFloat(prompt('Invoice amount (VAT inclusive)','20000')||'0');
    const ref = 'INV-'+fmt.uuid();
    const date = fmt.date(new Date());
    const inv = {date, customer:cust, ref, amount, status:'Open'};
    db.set('invoices', [inv, ...db.get('invoices')]);
    // VAT output
    const vatRate = (state().vat||12)/100;
    const base = amount / (1+vatRate);
    const vat = amount - base;
    db.set('vatledger', [{date, type:'output', base, vat, ref}, ...db.get('vatledger')]);
    // GL: DR AR 1100, CR Sales 4000, CR VAT 2100
    const je1 = {date, ref, account:'1100', debit:amount, credit:0, memo:`Invoice ${cust}`};
    const je2 = {date, ref, account:'4000', debit:0, credit:base, memo:'Sales'};
    const je3 = {date, ref, account:'2100', debit:0, credit:vat, memo:'VAT Output'};
    db.set('journals', [je1, je2, je3, ...db.get('journals')]);
    notify(`Invoice ${ref} created (${fmt.money(amount)}).`,'info', ref);
    initAR();
  };

  document.getElementById('btn-receive-payment').onclick = () => {
    const openInv = (db.get('invoices')||[]).filter(i=>i.status!=='Paid');
    if(openInv.length===0){ alert('No open invoices.'); return; }
    const ref = prompt('Invoice ref to pay', openInv[0].ref);
    const inv = (db.get('invoices')||[]).find(i=>i.ref===ref);
    if(!inv){ alert('Invoice not found'); return; }
    inv.status = 'Paid'; db.set('invoices', [...db.get('invoices')]);
    // GL: DR Cash 1000, CR AR 1100
    const date = fmt.date(new Date());
    const je1 = {date, ref:'RCV-'+ref, account:'1000', debit:inv.amount, credit:0, memo:'Cash In'};
    const je2 = {date, ref:'RCV-'+ref, account:'1100', debit:0, credit:inv.amount, memo:'AR'};
    db.set('journals', [je1, je2, ...db.get('journals')]);
    const meta = db.get('meta'); meta.cash += inv.amount; db.set('meta', meta);
    notify(`Invoice ${ref} collected.`, 'ok', ref);
    initAR();
  };

  function render(){
    const body = document.getElementById('ar-rows');
    body.innerHTML = (db.get('invoices')||[]).map(i=>`<tr>
      <td>${i.date}</td><td>${i.customer}</td><td>${i.ref}</td><td>${fmt.money(i.amount)}</td><td>${i.status}</td>
    </tr>`).join('');
  }
}
