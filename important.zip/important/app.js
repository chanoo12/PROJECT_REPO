
import { bus, db, fmt, state } from './modules/db.js';
import { initAuth } from './modules/auth.js';
import { mountRouter } from './modules/router.js';
import { initUI } from './modules/ui.js';
import { initDashboard } from './modules/dashboard.js';
import { initGL } from './modules/gl.js';
import { initAssets } from './modules/assets.js';
import { initTax } from './modules/tax.js';
import { initAP } from './modules/ap.js';
import { initAR } from './modules/ar.js';
import { initBudgeting } from './modules/budgeting.js';
import { initPayroll } from './modules/payroll.js';
import { initStock } from './modules/stock.js';
import { initCRM } from './modules/crm.js';
import { initInventoryConnector } from './modules/inventory.js';
import { initHRConnector } from './modules/hr.js';
import { initProjects } from './modules/projects.js';

// Boot
initUI();
initAuth();
mountRouter({
  'dashboard': initDashboard,
  'general-ledger': initGL,
  'asset-management': initAssets,
  'tax-management': initTax,
  'apayables': initAP,
  'areceivable': initAR,
  'budgeting': initBudgeting,
  'payroll': initPayroll,
  'stock-movement': initStock,
  'connector-crm': initCRM,
  'connector-inventory': initInventoryConnector,
  'connector-hr': initHRConnector,
  'connector-projects': initProjects,
  'settings': () => {
    const el = document.getElementById('content');
    el.innerHTML = `
      <section class="grid gap-1">
        <div class="card">
          <div class="card-head"><div class="card-title">Settings</div></div>
          <div class="grid grid-2">
            <label class="field"><span>Company Name</span>
              <input value="${state().company}" id="company-name"/>
            </label>
            <label class="field"><span>Default VAT %</span>
              <input value="${state().vat}" id="company-vat" type="number"/>
            </label>
          </div>
          <div class="hstack gap-1 mt-2">
            <button class="btn btn-primary" id="save-settings">Save</button>
            <button class="btn" id="reset-db">Reset Demo Data</button>
          </div>
        </div>
      </section>
    `;
    document.getElementById('save-settings').onclick = () => {
      const name = document.getElementById('company-name').value;
      const vat = parseFloat(document.getElementById('company-vat').value||'0');
      db.patch('meta', {company: name, vat});
      bus.emit('notif', {type:'info', text:`Settings saved.`});
    };
    document.getElementById('reset-db').onclick = () => {
      if(confirm('Reset all demo data?')){
        localStorage.removeItem('fa-suite');
        location.reload();
      }
    };
  }
});

// Seed demo data once
if(!state().seeded){
  db.tx(() => {
    db.patch('meta', {seeded:true, company:'Demo Corp', vat:12, cash: 250000});
    // COA
    db.set('coa', [
      {code:'1000', name:'Cash', type:'asset'},
      {code:'1100', name:'Accounts Receivable', type:'asset'},
      {code:'1200', name:'Inventory', type:'asset'},
      {code:'1500', name:'Fixed Assets', type:'asset'},
      {code:'2000', name:'Accounts Payable', type:'liability'},
      {code:'2100', name:'VAT Payable', type:'liability'},
      {code:'3000', name:'Equity', type:'equity'},
      {code:'4000', name:'Sales Revenue', type:'income'},
      {code:'4100', name:'Other Income', type:'income'},
      {code:'5000', name:'COGS', type:'expense'},
      {code:'5100', name:'Operating Expense', type:'expense'},
      {code:'5200', name:'Payroll Expense', type:'expense'},
      {code:'5300', name:'Depreciation Expense', type:'expense'}
    ]);
    // Some inventory and items
    db.set('items', [
      {sku:'ITEM-001', name:'Widget A', avgCost:100, onHand:50},
      {sku:'ITEM-002', name:'Widget B', avgCost:150, onHand:20}
    ]);
    db.set('movements', []);
    // AR/AP
    db.set('customers', [{id:'CUST-001', name:'Acme Co.'}]);
    db.set('vendors', [{id:'VEND-001', name:'Supply Co.'}]);
    db.set('invoices', []);
    db.set('bills', []);
    // Payroll/HR
    db.set('employees', [{id:'EMP-001', name:'Juan Dela Cruz', rate:2500, dept:'Ops'}]);
    db.set('payruns', []);
    // Assets
    db.set('assets', [{code:'FA-001', name:'Office Laptop', cost:60000, life:36, accum:10000, start: new Date().toISOString().slice(0,10)}]);
    // GL/Tax
    db.set('journals', []);
    db.set('vatledger', []);
    // Budgets
    db.set('budgets', [{year:new Date().getFullYear(), scope:'Ops', category:'OPEX', amount:150000, actual:0}]);
  });
  bus.emit('notif',{type:'info', text:'Demo data loaded.'});
}
