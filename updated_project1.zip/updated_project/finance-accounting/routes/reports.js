const express = require('express');
const router = express.Router();

// Monthly Financials Report
router.get('/monthly-financials', async (req, res) => {
    try {
        // TODO: Replace with actual database queries
        const mockData = {
            labels: ['Jan 2025', 'Feb 2025', 'Mar 2025', 'Apr 2025', 'May 2025', 'Jun 2025'],
            revenue: [45000, 52000, 49000, 47000, 55000, 60000],
            expenses: [38000, 42000, 39000, 41000, 44000, 48000]
        };
        res.json(mockData);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Quarterly Budget Report
router.get('/quarterly-budget', async (req, res) => {
    try {
        const mockData = {
            labels: ['Q1', 'Q2', 'Q3', 'Q4'],
            budget: [150000, 160000, 165000, 170000],
            actual: [148000, 158000, 162000, 0] // Q4 not complete
        };
        res.json(mockData);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// AR Aging Report
router.get('/ar-aging', async (req, res) => {
    try {
        // [current, 1-30, 31-60, 61-90, 90+]
        const mockData = [50000, 30000, 15000, 8000, 5000];
        res.json(mockData);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// AP Aging Report
router.get('/ap-aging', async (req, res) => {
    try {
        // [current, 1-30, 31-60, 61-90, 90+]
        const mockData = [45000, 25000, 12000, 6000, 3000];
        res.json(mockData);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
