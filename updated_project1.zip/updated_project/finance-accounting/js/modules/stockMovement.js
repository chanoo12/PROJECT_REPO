// Stock Movement Module
export default class StockMovement {
    constructor(dataStore, eventBus) {
        this.dataStore = dataStore;
        this.eventBus = eventBus;
        this.charts = {};
        
        this.setupEventListeners();
        this.setupCharts();
        this.loadStockData();
        
        // Subscribe to data refresh events
        this.eventBus.subscribe('dataRefresh', () => this.loadStockData());
        
        // Subscribe to inventory and financial updates
        this.dataStore.subscribe('inventory', (event) => this.handleInventoryUpdate(event));
        this.dataStore.subscribe('stockMovements', (event) => this.handleMovementUpdate(event));
        this.eventBus.subscribe('arApUpdate', (data) => this.handleARAPUpdate(data));
        
        // Subscribe to transaction updates
        this.eventBus.subscribe('transactionUpdate', (data) => {
            if (data.type === 'purchase' || data.type === 'sale') {
                this.handleTransactionUpdate(data);
            }
        });
    }
    
    handleARAPUpdate(data) {
        // Update stock values based on pending purchases/sales
        if (data.pendingPurchases) {
            this.updatePendingStockLevels(data.pendingPurchases, 'in');
        }
        if (data.pendingSales) {
            this.updatePendingStockLevels(data.pendingSales, 'out');
        }
    }
    
    handleTransactionUpdate(data) {
        // Automatically create stock movement when purchase/sale is completed
        if (data.status === 'completed') {
            const movement = {
                date: new Date(),
                type: data.type === 'purchase' ? 'in' : 'out',
                itemId: data.itemId,
                quantity: data.quantity,
                location: data.location || 'main',
                reference: data.reference,
                notes: `Auto-generated from ${data.type} transaction ${data.id}`
            };
            
            this.createStockMovement(movement);
        }
    }
    
    updatePendingStockLevels(transactions, type) {
        const pendingByItem = transactions.reduce((acc, t) => {
            if (!acc[t.itemId]) {
                acc[t.itemId] = 0;
            }
            acc[t.itemId] += t.quantity;
            return acc;
        }, {});
        
        Object.entries(pendingByItem).forEach(([itemId, quantity]) => {
            const item = this.dataStore.read('inventory', itemId);
            if (item) {
                const projectedQuantity = type === 'in' 
                    ? item.quantity + quantity
                    : item.quantity - quantity;
                    
                // Update UI to show projected stock levels
                this.updateProjectedStockLevel(item.id, projectedQuantity);
            }
        });
    }
    
    updateProjectedStockLevel(itemId, projectedQuantity) {
        const row = document.querySelector(`tr[data-item-id="${itemId}"]`);
        if (row) {
            const projectedCell = row.querySelector('.projected-quantity');
            if (projectedCell) {
                projectedCell.textContent = projectedQuantity;
                
                // Update status based on projected quantity
                const item = this.dataStore.read('inventory', itemId);
                const status = this.getStockStatus({ ...item, quantity: projectedQuantity });
                row.querySelector('.stock-status').innerHTML = status;
            }
        }
    }

    setupEventListeners() {
        // Tab navigation
        const tabs = document.querySelectorAll('[data-bs-toggle="tab"]');
        tabs.forEach(tab => {
            tab.addEventListener('shown.bs.tab', (event) => {
                if (event.target.id === 'inventory-tab' || event.target.getAttribute('data-bs-target') === '#inventory-tab-content') {
                    this.loadStockData();
                }
            });
        });

        // New Item Form
        const newItemForm = document.getElementById('new-item-form');
        newItemForm?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleNewItem(new FormData(newItemForm));
        });

        // Record Movement Form
        const movementForm = document.getElementById('record-movement-form');
        movementForm?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleNewMovement(new FormData(movementForm));
        });

        // Action buttons
        document.getElementById('import-items-btn')?.addEventListener('click', () => this.handleImport());
        document.getElementById('export-inventory-btn')?.addEventListener('click', () => this.handleExport());
        document.getElementById('filter-items-btn')?.addEventListener('click', () => this.handleFilter());
    }

    setupCharts() {
        // Initialize stock category chart
        const categoryCtx = document.getElementById('stock-category-chart')?.getContext('2d');
        if (categoryCtx) {
            this.charts.category = new Chart(categoryCtx, {
                type: 'pie',
                data: {
                    labels: [],
                    datasets: [{
                        data: [],
                        backgroundColor: ['#007bff', '#28a745', '#ffc107', '#dc3545', '#17a2b8']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }

        // Initialize stock movement trend chart
        const trendCtx = document.getElementById('stock-movement-chart')?.getContext('2d');
        if (trendCtx) {
            this.charts.trend = new Chart(trendCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Stock Value',
                        data: [],
                        borderColor: '#007bff',
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    }
    }

    loadStockData() {   
        const inventory = this.dataStore.read('inventory');
        const movements = this.dataStore.read('stockMovements');

        // Calculate summary values
        const totalValue = inventory.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0);
        const totalItems = inventory.reduce((sum, item) => sum + item.quantity, 0);
        const lowStockCount = this.dataStore.getLowStockItems(50).length;
        const turnover = this.calculateStockTurnover(inventory, movements);
        
        // Update summary cards
        document.getElementById('total-stock-value').textContent = this.formatCurrency(totalValue);
        document.getElementById('items-count').textContent = inventory.length;
        document.getElementById('low-stock-count').textContent = lowStockCount;
        document.getElementById('stock-turnover').textContent = turnover.toFixed(2);

        // Update tables and charts
        this.updateInventoryStatus(inventory);
        this.updateStockMovements(movements);
        this.updateCharts(inventory, movements);

        // Notify dashboard if we're updating data
        this.eventBus.publish('stockUpdate', {
            totalValue,
            totalItems,
            lowStockCount,
            turnover
        });
    }

    handleNewItem(formData) {
        const newItem = {
            code: formData.get('itemCode'),
            description: formData.get('description'),
            category: formData.get('category'),
            unit: formData.get('unit'),
            quantity: Number(formData.get('initialStock')),
            unitCost: Number(formData.get('costPerUnit')),
            minimumStock: Number(formData.get('minimumStock'))
        };

        this.dataStore.create('inventory', newItem);
        this.eventBus.publish('notification', { 
            type: 'success', 
            message: 'New item added successfully' 
        });

        // Close modal and reset form
        const modal = bootstrap.Modal.getInstance(document.getElementById('newItemModal'));
        modal.hide();
        document.getElementById('new-item-form').reset();
    }

    handleNewMovement(formData) {
        const movement = {
            date: new Date(),
            type: formData.get('movementType'),
            itemId: formData.get('item'),
            quantity: Number(formData.get('quantity')),
            location: formData.get('location'),
            reference: formData.get('reference'),
            notes: formData.get('notes')
        };

        // Update inventory quantity
        const item = this.dataStore.read('inventory', movement.itemId);
        if (item) {
            const newQuantity = movement.type === 'in' 
                ? item.quantity + movement.quantity
                : item.quantity - movement.quantity;

            if (newQuantity < 0) {
                this.eventBus.publish('error', { 
                    message: 'Insufficient stock for this movement' 
                });
                return;
            }

            this.dataStore.update('inventory', item.id, { quantity: newQuantity });
            this.dataStore.create('stockMovements', movement);

            this.eventBus.publish('notification', { 
                type: 'success', 
                message: 'Stock movement recorded successfully' 
            });

            // Close modal and reset form
            const modal = bootstrap.Modal.getInstance(document.getElementById('recordMovementModal'));
            modal.hide();
            document.getElementById('record-movement-form').reset();
        }
    }

    updateInventoryTable(inventory) {
        const tbody = document.getElementById('inventory-table');
        if (!tbody) return;

        tbody.innerHTML = inventory.map(item => {
            const totalValue = item.quantity * item.unitCost;
            const status = this.getStockStatus(item);

            return `
                <tr>
                    <td>${item.code}</td>
                    <td>${item.description}</td>
                    <td>${item.category}</td>
                    <td>${item.unit}</td>
                    <td>${item.quantity}</td>
                    <td>${this.formatCurrency(item.unitCost)}</td>
                    <td>${this.formatCurrency(totalValue)}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary me-1" onclick="app.modules.stockMovement.editItem('${item.id}')">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="app.modules.stockMovement.deleteItem('${item.id}')">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    updateMovementsTable(movements) {
        const tbody = document.getElementById('movements-table');
        if (!tbody) return;

        tbody.innerHTML = movements.map(move => {
            const item = this.dataStore.read('inventory', move.itemId);
            return `
                <tr>
                    <td>${new Date(move.date).toLocaleDateString()}</td>
                    <td>${move.reference}</td>
                    <td>${item ? item.code : 'Unknown'}</td>
                    <td>${item ? item.description : 'Unknown'}</td>
                    <td>${move.type}</td>
                    <td>${move.quantity}</td>
                    <td>${move.location}</td>
                    <td><span class="badge bg-success">Completed</span></td>
                </tr>
            `;
        }).join('');
    }

    updateCharts(inventory, movements) {
        // Update category chart
        if (this.charts.category) {
            const categoryData = this.calculateCategoryData(inventory);
            this.charts.category.data.labels = Object.keys(categoryData);
            this.charts.category.data.datasets[0].data = Object.values(categoryData);
            this.charts.category.update();
        }

        // Update trend chart
        if (this.charts.trend) {
            const trendData = this.calculateTrendData(movements);
            this.charts.trend.data.labels = trendData.labels;
            this.charts.trend.data.datasets[0].data = trendData.values;
            this.charts.trend.update();
        }
    }

    calculateCategoryData(inventory) {
        const categories = {};
        inventory.forEach(item => {
            if (!categories[item.category]) {
                categories[item.category] = 0;
            }
            categories[item.category] += item.quantity * item.unitCost;
        });
        return categories;
    }

    calculateTrendData(movements) {
        const dates = new Set();
        const valuesByDate = new Map();

        movements.forEach(move => {
            const date = new Date(move.date).toLocaleDateString();
            dates.add(date);
            
            const currentValue = valuesByDate.get(date) || 0;
            const item = this.dataStore.read('inventory', move.itemId);
            const value = move.quantity * (item?.unitCost || 0);
            
            valuesByDate.set(date, currentValue + (move.type === 'in' ? value : -value));
        });

        return {
            labels: Array.from(dates),
            values: Array.from(dates).map(date => valuesByDate.get(date) || 0)
        };
    }

    calculateStockTurnover(inventory, movements) {
        const totalValue = inventory.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0);
        const annualSalesValue = movements
            .filter(m => m.type === 'out')
            .reduce((sum, m) => {
                const item = this.dataStore.read('inventory', m.itemId);
                return sum + (m.quantity * (item?.unitCost || 0));
            }, 0) * (365 / 30); // Extrapolate to annual

        return totalValue > 0 ? annualSalesValue / totalValue : 0;
    }

    getStockStatus(item) {
        if (item.quantity <= item.minimumStock / 2) {
            return '<span class="badge bg-danger">Critical</span>';
        } else if (item.quantity <= item.minimumStock) {
            return '<span class="badge bg-warning">Low</span>';
        }
        return '<span class="badge bg-success">Adequate</span>';
    }

    handleInventoryUpdate(event) {
        this.loadStockData();
    }

    handleMovementUpdate(event) {
        this.loadStockData();
    }

    handleFilter() {
        // TODO: Implement filtering UI
    }

    handleImport() {
        // TODO: Implement import functionality
    }

    handleExport() {
        // TODO: Implement export functionality
    }

    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }
}
