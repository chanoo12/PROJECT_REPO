import { apiService } from '../utils/apiService.js';
import { eventBus } from '../utils/eventBus.js';
import { formatters } from '../utils/validation.js';
import { stateManager } from '../utils/stateManager.js';

class GeneralLedger {
    constructor() {
        this.transactions = [];
        this.currentPage = 1;
        this.itemsPerPage = 10;
        this.api = apiService;
        this.eventBus = eventBus;
        this.state = stateManager;

        // Initialize state with mock data
        this.state.setState({
            transactions: [],
            summary: {
                totalAssets: 0,
                totalLiabilities: 0,
                totalEquity: 0,
                netPosition: 0
            }
        }, 'gl');
        
        this.initializeEventListeners();
        this.loadInitialData();

        // Subscribe to events from other modules
        this.eventBus.subscribe('newTransaction', (transaction) => this.handleNewTransaction(transaction));
        this.eventBus.subscribe('dataRefresh', () => this.loadInitialData());
    }

    initializeEventListeners() {
        const transactionForm = document.getElementById('transaction-form');
        if (transactionForm) {
            transactionForm.addEventListener('submit', (e) => this.handleTransactionSubmit(e));
        }

        const btnFilter = document.getElementById('btn-filter');
        if (btnFilter) {
            btnFilter.addEventListener('click', () => this.showFilterDialog());
        }

        const btnExport = document.getElementById('btn-export');
        if (btnExport) {
            btnExport.addEventListener('click', () => this.exportTransactions());
        }
    }

    async loadInitialData() {
        try {
            // Load mock data
            const glData = await this.fetchGLData();
            this.updateGLSummary(glData.summary);
            this.transactions = glData.transactions;
            this.renderTransactionLog();
            this.renderSourceDocumentsChart();
            this.renderPendingApprovals(glData.pendingApprovals);
        } catch (error) {
            console.error('Error loading GL data:', error);
            // Show error notification
            EventBus.publish('notification', {
                type: 'error',
                message: 'Failed to load General Ledger data'
            });
        }
    }

    async fetchGLData() {
        try {
            // Get journal entries from mock data
            const journalEntries = db.getJournalEntries().map(entry => {
                return entry.entries.map(e => ({
                    date: entry.date,
                    reference: entry.id,
                    account: e.account,
                    description: entry.description,
                    debit: e.debit || 0,
                    credit: e.credit || 0,
                    status: entry.status,
                    createdBy: entry.createdBy
                }));
            }).flat();

            // Get AR/AP transactions
            const receivables = db.mockData.GeneralLedger.receivables.map(r => ({
                date: r.date,
                reference: r.id,
                account: '1200', // Accounts Receivable
                description: `Invoice for ${r.customer}`,
                debit: r.amount,
                credit: 0,
                status: r.status,
                balance: r.balance
            }));

            const payables = db.mockData.GeneralLedger.payables.map(p => ({
                date: p.date,
                reference: p.id,
                account: '2100', // Accounts Payable
                description: `Bill from ${p.vendor}`,
                debit: 0,
                credit: p.amount,
                status: p.status,
                balance: p.balance
            }));

            // Combine all transactions and sort by date
            const transactions = [...journalEntries, ...receivables, ...payables]
                .sort((a, b) => new Date(b.date) - new Date(a.date));

            // Calculate the current balance for each account
            const accounts = db.getChartOfAccounts();
            const summary = {
                totalAssets: accounts.filter(a => a.type === 'Asset').reduce((sum, a) => sum + a.balance, 0),
                totalLiabilities: accounts.filter(a => a.type === 'Liability').reduce((sum, a) => sum + a.balance, 0),
                totalEquity: accounts.filter(a => a.type === 'Equity').reduce((sum, a) => sum + a.balance, 0)
            };
            summary.netPosition = summary.totalAssets - summary.totalLiabilities;

            // Get pending approvals
            const pendingApprovals = [...receivables, ...payables]
                .filter(t => t.status === 'Pending')
                .map(t => ({
                    id: t.reference,
                    type: t.account === '1200' ? 'Invoice' : 'Bill',
                    amount: t.debit || t.credit,
                    date: t.date,
                    submittedBy: 'System'
                }));

            return {
                summary,
                transactions,
                pendingApprovals
            };
        } catch (error) {
            console.error('Error fetching GL data:', error);
            throw error;
        }
    }

    calculateSummary(transactions) {
        const summary = transactions.reduce((acc, transaction) => {
            const amount = (transaction.debit || 0) - (transaction.credit || 0);
            
            switch (transaction.accountType) {
                case 'asset':
                    acc.totalAssets += amount;
                    break;
                case 'liability':
                    acc.totalLiabilities += amount;
                    break;
                case 'equity':
                    acc.totalEquity += amount;
                    break;
            }
            
            return acc;
        }, {
            totalAssets: 0,
            totalLiabilities: 0,
            totalEquity: 0
        });

        summary.netPosition = summary.totalAssets - summary.totalLiabilities;
        return summary;
    }

    updateGLSummary(summary) {
        document.getElementById('gl-total-assets').textContent = this.formatCurrency(summary.totalAssets);
        document.getElementById('gl-total-liabilities').textContent = this.formatCurrency(summary.totalLiabilities);
        document.getElementById('gl-total-equity').textContent = this.formatCurrency(summary.totalEquity);
        document.getElementById('gl-net-position').textContent = this.formatCurrency(summary.netPosition);
    }

    renderTransactionLog() {
        const tbody = document.getElementById('gl-transactions');
        const startIndex = (this.currentPage - 1) * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        const pageTransactions = this.transactions.slice(startIndex, endIndex);

        tbody.innerHTML = pageTransactions.map(transaction => `
            <tr>
                <td>${transaction.date}</td>
                <td>${transaction.reference}</td>
                <td>${transaction.account}</td>
                <td>${transaction.description}</td>
                <td>${this.formatCurrency(transaction.debit)}</td>
                <td>${this.formatCurrency(transaction.credit)}</td>
                <td>${this.formatCurrency(transaction.balance)}</td>
                <td><span class="badge bg-success">${transaction.status}</span></td>
            </tr>
        `).join('');

        this.renderPagination();
    }

    renderPagination() {
        const totalPages = Math.ceil(this.transactions.length / this.itemsPerPage);
        const pagination = document.getElementById('transaction-pagination');
        
        let paginationHtml = '';
        for (let i = 1; i <= totalPages; i++) {
            paginationHtml += `
                <li class="page-item ${i === this.currentPage ? 'active' : ''}">
                    <a class="page-link" href="#" data-page="${i}">${i}</a>
                </li>
            `;
        }
        
        pagination.innerHTML = paginationHtml;
        
        pagination.addEventListener('click', (e) => {
            e.preventDefault();
            if (e.target.tagName === 'A') {
                this.currentPage = parseInt(e.target.dataset.page);
                this.renderTransactionLog();
            }
        });
    }

    async handleTransactionSubmit(e) {
        e.preventDefault();
        
        const formData = {
            date: document.getElementById('transaction-date').value,
            account: document.getElementById('transaction-account').value,
            type: document.getElementById('transaction-type').value,
            amount: parseFloat(document.getElementById('transaction-amount').value),
            description: document.getElementById('transaction-description').value
        };

        try {
            // Create new journal entry
            const newEntry = {
                id: `JE${Date.now()}`,
                date: formData.date,
                description: formData.description,
                entries: [
                    {
                        account: formData.account,
                        debit: formData.type === 'debit' ? formData.amount : 0,
                        credit: formData.type === 'credit' ? formData.amount : 0
                    }
                ],
                status: 'Posted',
                createdBy: 'Current User'
            };

            // Add to mock data
            db.mockData.GeneralLedger.journal_entries.push(newEntry);

            // Create transaction object for display
            const newTransaction = {
                date: formData.date,
                reference: newEntry.id,
                account: formData.account,
                description: formData.description,
                debit: formData.type === 'debit' ? formData.amount : 0,
                credit: formData.type === 'credit' ? formData.amount : 0,
                status: 'Posted',
                balance: this.calculateNewBalance(formData)
            };
            
            // Update local state
            const currentTransactions = this.state.getState('gl.transactions') || [];
            this.state.setState([...currentTransactions, newTransaction], 'gl.transactions');
            
            // Reset form
            e.target.reset();

            // Notify other modules
            this.eventBus.publish('glUpdate', newTransaction);

            // Show success notification
            this.eventBus.publish('notification', {
                type: 'success',
                message: 'Transaction posted successfully'
            });

            // Refresh the transaction log
            await this.loadInitialData();

        } catch (error) {
            console.error('Error posting transaction:', error);
            this.eventBus.publish('notification', {
                type: 'error',
                message: 'Failed to post transaction'
            });
        }
    }

    handleNewTransaction(transaction) {
        // Validate transaction
        if (!transaction.date || !transaction.description || 
            (!transaction.debit && !transaction.credit)) {
            console.error('Invalid transaction format');
            return;
        }

        // Update local state
        this.state.commit('gl/addTransaction', transaction);
        
        // Refresh the view
        this.loadInitialData();
    }

    calculateNewBalance(formData) {
        const lastTransaction = this.transactions[0];
        const lastBalance = lastTransaction ? lastTransaction.balance : 0;
        return formData.type === 'debit' 
            ? lastBalance + formData.amount 
            : lastBalance - formData.amount;
    }

    renderSourceDocumentsChart() {
        const ctx = document.getElementById('source-documents-chart');
        if (!ctx) return;

        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Invoices', 'Bills', 'Journal Entries', 'Bank Statements'],
                datasets: [{
                    data: [30, 25, 20, 25],
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.8)',
                        'rgba(255, 99, 132, 0.8)',
                        'rgba(255, 206, 86, 0.8)',
                        'rgba(75, 192, 192, 0.8)'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    renderPendingApprovals(approvals) {
        const container = document.getElementById('pending-approvals');
        if (!container) return;

        container.innerHTML = approvals.map(approval => `
            <div class="list-group-item list-group-item-action">
                <div class="d-flex w-100 justify-content-between">
                    <h6 class="mb-1">${approval.type} #${approval.id}</h6>
                    <small>${approval.date}</small>
                </div>
                <p class="mb-1">Amount: ${this.formatCurrency(approval.amount)}</p>
                <small>Submitted by: ${approval.submittedBy}</small>
            </div>
        `).join('');
    }

    showFilterDialog() {
        // Implement filter dialog logic
        console.log('Filter dialog not implemented yet');
    }

    exportTransactions() {
        // Implement export logic
        console.log('Export functionality not implemented yet');
    }

    formatCurrency(amount) {
        return formatters.currency(amount);
    }

    // Export functionality
    async exportTransactions() {
        try {
            const transactions = await this.api.read('gl/transactions');
            const csv = this.convertToCSV(transactions);
            this.downloadCSV(csv, 'gl-transactions.csv');
            
            this.eventBus.publish('notification', {
                type: 'success',
                message: 'Transactions exported successfully'
            });
        } catch (error) {
            console.error('Error exporting transactions:', error);
            this.eventBus.publish('notification', {
                type: 'error',
                message: 'Failed to export transactions'
            });
        }
    }

    convertToCSV(data) {
        const headers = ['Date', 'Reference', 'Account', 'Description', 'Debit', 'Credit', 'Status'];
        const rows = data.map(entry => [
            entry.date,
            entry.reference,
            entry.account,
            entry.description,
            entry.debit || '',
            entry.credit || '',
            entry.status
        ]);

        return [headers, ...rows]
            .map(row => row.map(String)
            .map(cell => `"${cell.replace(/"/g, '""')}"`)
            .join(','))
            .join('\n');
    }

    downloadCSV(csv, filename) {
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

export default GeneralLedger;
