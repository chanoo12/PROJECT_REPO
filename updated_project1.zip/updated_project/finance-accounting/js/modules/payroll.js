// Payroll Module
import { apiService } from '../utils/apiService.js';
import { eventBus } from '../utils/eventBus.js';
import { formatters } from '../utils/validation.js';
import { stateManager } from '../utils/stateManager.js';

export default class Payroll {
    constructor() {
        this.api = apiService;
        this.eventBus = eventBus;
        this.state = stateManager;
        this.charts = {};
        
        // Initialize tax rates - in real app, these would come from config/API
        this.taxRates = {
            incomeTax: 0.2,
            socialSecurity: 0.062,
            medicare: 0.0145
        };
        
        this.setupPayrollSection();
        this.loadPayrollData();
        
        // Subscribe to data refresh events
        this.eventBus.subscribe('dataRefresh', () => this.loadPayrollData());
    }

    setupPayrollSection() {
        const payrollSection = document.createElement('div');
        payrollSection.id = 'payroll';
        payrollSection.className = 'section';
        payrollSection.innerHTML = `
            <h2>Payroll Management</h2>
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Payroll Summary</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <p>Total Payroll: <span id="total-payroll">$0</span></p>
                                    <p>Basic Pay: <span id="total-basic">$0</span></p>
                                </div>
                                <div class="col-md-6">
                                    <p>Allowances: <span id="total-allowances">$0</span></p>
                                    <p>Deductions: <span id="total-deductions">$0</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Payroll Distribution</h5>
                            <canvas id="payroll-distribution-chart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Employee Payroll Details</h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Employee ID</th>
                                            <th>Basic Pay</th>
                                            <th>Allowances</th>
                                            <th>OT Hours</th>
                                            <th>OT Amount</th>
                                            <th>Deductions</th>
                                            <th>Net Pay</th>
                                        </tr>
                                    </thead>
                                    <tbody id="payroll-details">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Payroll Taxes</h5>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Tax Type</th>
                                            <th>Rate</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody id="payroll-taxes">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Overtime Trend</h5>
                            <canvas id="overtime-trend-chart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.querySelector('.container-fluid').appendChild(payrollSection);
    }

    async loadPayrollData() {
        try {
            // Fetch all required data in parallel
            const [salaryData, otData] = await Promise.all([
                this.api.read('payroll/salary'),
                this.api.read('payroll/overtime')
            ]);

            // Calculate totals
            const totals = {
                basic: salaryData.reduce((sum, emp) => sum + emp.basicPay, 0),
                allowances: salaryData.reduce((sum, emp) => sum + emp.allowances, 0),
                deductions: salaryData.reduce((sum, emp) => sum + emp.deductions, 0),
                overtime: otData.reduce((sum, ot) => sum + (ot.hours * ot.rate), 0)
            };

            totals.total = totals.basic + totals.allowances + totals.overtime - totals.deductions;

            // Update state
            this.state.commit('payroll/totals', totals);
            this.state.commit('payroll/employees', salaryData);
            this.state.commit('payroll/overtime', otData);

            // Update UI elements
            document.getElementById('total-payroll')?.textContent = formatters.currency(totals.total);
            document.getElementById('total-basic')?.textContent = formatters.currency(totals.basic);
            document.getElementById('total-allowances')?.textContent = formatters.currency(totals.allowances);
            document.getElementById('total-deductions')?.textContent = formatters.currency(totals.deductions);

            // Update components
            await Promise.all([
                this.updatePayrollDetails(salaryData, otData),
                this.updatePayrollDistributionChart(totals),
                this.updateOvertimeTrendChart(),
                this.updatePayrollTaxes(totals.total)
            ]);

            // Notify other modules
            this.eventBus.publish('payrollUpdate', {
                timestamp: new Date(),
                totals,
                employeeCount: salaryData.length
            });

        } catch (error) {
            console.error('Error loading payroll data:', error);
            this.eventBus.publish('error', {
                message: 'Failed to load payroll data',
                details: error.message
            });
        }
    }

    updatePayrollDetails(salaryData, otData) {
        const tbody = document.getElementById('payroll-details');
        if (!tbody) return;

        tbody.innerHTML = salaryData.map(emp => {
            const ot = otData.find(ot => ot.employeeId === emp.employeeId) || { hours: 0, rate: 0 };
            const otAmount = ot.hours * ot.rate;
            const netPay = emp.basicPay + emp.allowances + otAmount - emp.deductions;

            return `
                <tr>
                    <td>${emp.employeeId}</td>
                    <td>${formatters.currency(emp.basicPay)}</td>
                    <td>${formatters.currency(emp.allowances)}</td>
                    <td>${formatters.number(ot.hours, 1)}</td>
                    <td>${formatters.currency(otAmount)}</td>
                    <td>${formatters.currency(emp.deductions)}</td>
                    <td>${formatters.currency(netPay)}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary me-1" onclick="app.modules.payroll.editEmployee('${emp.employeeId}')">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="app.modules.payroll.deleteEmployee('${emp.employeeId}')">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    async updatePayrollDistributionChart(totals) {
        const ctx = document.getElementById('payroll-distribution-chart')?.getContext('2d');
        if (!ctx) return;

        const chart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Basic Pay', 'Allowances', 'Overtime', 'Deductions'],
                datasets: [{
                    data: [totals.basic, totals.allowances, totals.overtime, totals.deductions],
                    backgroundColor: ['#007bff', '#28a745', '#ffc107', '#dc3545']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const value = context.raw;
                                const total = totals.total + totals.deductions; // Add back deductions for total
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${formatters.currency(value)} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });

        this.charts.distribution = chart;
    }

    async updateOvertimeTrendChart() {
        try {
            const overtimeTrend = await this.api.read('payroll/overtime/trend');
            const ctx = document.getElementById('overtime-trend-chart')?.getContext('2d');
            if (!ctx) return;

            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: overtimeTrend.months,
                    datasets: [{
                        label: 'Overtime Hours',
                        data: overtimeTrend.hours,
                        borderColor: '#ffc107',
                        fill: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Hours'
                            }
                        }
                    }
                }
            });

            this.charts.overtime = chart;
            
            // Update state with trend data
            this.state.commit('payroll/overtimeTrend', overtimeTrend);

        } catch (error) {
            console.error('Error updating overtime trend:', error);
            this.eventBus.publish('error', {
                message: 'Failed to update overtime trend',
                details: error.message
            });
        }
    }

    updatePayrollTaxes(totalPayroll) {
        const tbody = document.getElementById('payroll-taxes');
        if (!tbody) return;

        const taxes = [
            { type: 'Income Tax', rate: this.taxRates.incomeTax, amount: totalPayroll * this.taxRates.incomeTax },
            { type: 'Social Security', rate: this.taxRates.socialSecurity, amount: totalPayroll * this.taxRates.socialSecurity },
            { type: 'Medicare', rate: this.taxRates.medicare, amount: totalPayroll * this.taxRates.medicare }
        ];

        tbody.innerHTML = taxes.map(tax => `
            <tr>
                <td>${tax.type}</td>
                <td>${formatters.percentage(tax.rate)}</td>
                <td>${formatters.currency(tax.amount)}</td>
            </tr>
        `).join('');

        // Update state with tax calculations
        this.state.commit('payroll/taxes', taxes);
    }
}
