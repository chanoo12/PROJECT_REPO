// Budgeting Module
import { apiService } from '../utils/apiService.js';
import { eventBus } from '../utils/eventBus.js';
import { formatters } from '../utils/validation.js';
import { stateManager } from '../utils/stateManager.js';

export default class Budgeting {
    constructor() {
        this.api = apiService;
        this.eventBus = eventBus;
        this.state = stateManager;
        
        this.setupBudgetSection();
        this.loadBudgetData();
        
        // Subscribe to GL updates
        this.eventBus.subscribe('glUpdate', () => this.updateActuals());
        this.eventBus.subscribe('dataRefresh', () => this.loadBudgetData());
    }

    setupBudgetSection() {
        const budgetSection = document.createElement('div');
        budgetSection.id = 'budget';
        budgetSection.className = 'section';
        budgetSection.innerHTML = `
            <h2>Budgeting</h2>
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Budget Overview</h5>
                            <canvas id="budget-overview-chart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Department Budgets</h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Department</th>
                                            <th>Allocated</th>
                                            <th>Spent</th>
                                            <th>Remaining</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody id="department-budgets">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Budget vs Actual Breakdown</h5>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Budget</th>
                                            <th>Actual</th>
                                            <th>Variance</th>
                                            <th>Variance %</th>
                                        </tr>
                                    </thead>
                                    <tbody id="budget-breakdown">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.querySelector('.container-fluid').appendChild(budgetSection);
    }

    loadBudgetData() {
        this.setupBudgetOverviewChart();
        this.updateDepartmentBudgets();
        this.updateBudgetBreakdown();
    }

    async setupBudgetOverviewChart() {
        try {
            const overview = await this.api.read('budgets/overview');
            const ctx = document.getElementById('budget-overview-chart')?.getContext('2d');
            
            if (!ctx) return;

            const chart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Spent', 'Remaining'],
                    datasets: [{
                        data: [overview.spent, overview.remaining],
                        backgroundColor: ['#dc3545', '#28a745']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: (context) => {
                                    const value = context.raw;
                                    const total = overview.spent + overview.remaining;
                                    const percentage = ((value / total) * 100).toFixed(1);
                                    return `${formatters.currency(value)} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });

            // Store chart reference for updates
            this.charts = this.charts || {};
            this.charts.overview = chart;

            // Update state with overview data
            this.state.commit('budget/overview', overview);

        } catch (error) {
            console.error('Error setting up budget overview chart:', error);
            this.eventBus.publish('error', { 
                message: 'Failed to setup budget overview chart',
                details: error.message
            });
        }
    }

    async updateDepartmentBudgets() {
        try {
            const budgetData = await this.api.read('budgets/departments');
            const tbody = document.getElementById('department-budgets');

            if (!tbody) return;

            tbody.innerHTML = budgetData.map(budget => {
                const percentSpent = (budget.spent / budget.allocated) * 100;
                let status;
                if (percentSpent > 90) status = '<span class="badge bg-danger">Critical</span>';
                else if (percentSpent > 75) status = '<span class="badge bg-warning">Warning</span>';
                else status = '<span class="badge bg-success">Good</span>';

                return `
                    <tr>
                        <td>${budget.department}</td>
                        <td>${formatters.currency(budget.allocated)}</td>
                        <td>${formatters.currency(budget.spent)}</td>
                        <td>${formatters.currency(budget.allocated - budget.spent)}</td>
                        <td>${status}</td>
                    </tr>
                `;
            }).join('');

            // Update state with department budget data
            this.state.commit('budget/departments', budgetData);

        } catch (error) {
            console.error('Error updating department budgets:', error);
            this.eventBus.publish('error', { 
                message: 'Failed to update department budgets',
                details: error.message
            });
        }
    }

    async updateBudgetBreakdown() {
        try {
            const [budgets, actuals] = await Promise.all([
                this.api.read('budgets/categories'),
                this.api.read('actuals/categories')
            ]);

            const tbody = document.getElementById('budget-breakdown');
            if (!tbody) return;

            const breakdown = budgets.map(budget => {
                const actual = actuals.find(a => a.category === budget.category)?.amount || 0;
                const variance = actual - budget.amount;
                const variancePercent = (variance / budget.amount) * 100;
                const varianceClass = variance >= 0 ? 'text-success' : 'text-danger';

                return `
                    <tr>
                        <td>${budget.category}</td>
                        <td>${formatters.currency(budget.amount)}</td>
                        <td>${formatters.currency(actual)}</td>
                        <td class="${varianceClass}">${formatters.currency(variance)}</td>
                        <td class="${varianceClass}">${formatters.number(variancePercent, 1)}%</td>
                    </tr>
                `;
            }).join('');

            tbody.innerHTML = breakdown;

            // Update state with budget breakdown data
            this.state.commit('budget/breakdown', {
                budgets,
                actuals,
                lastUpdated: new Date()
            });

        } catch (error) {
            console.error('Error updating budget breakdown:', error);
            this.eventBus.publish('error', { 
                message: 'Failed to update budget breakdown',
                details: error.message
            });
        }
    }

    async updateActuals() {
        try {
            await this.loadBudgetData();
            this.eventBus.publish('budgetUpdate', {
                timestamp: new Date(),
                status: 'success'
            });
        } catch (error) {
            console.error('Error updating actuals:', error);
            this.eventBus.publish('error', { 
                message: 'Failed to update budget actuals',
                details: error.message
            });
        }
    }
}
