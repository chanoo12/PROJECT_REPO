// Dashboard Module
import { apiService } from '../utils/apiService.js';
import { eventBus } from '../utils/eventBus.js';
import { formatters } from '../utils/validation.js';

export default class Dashboard {
    constructor(api, eventBus) {
        this.api = api;
        this.eventBus = eventBus;
        this.charts = {};
        
        this.setupEventListeners();
        this.setupCharts();
        this.loadDashboardData();
    }

    setupEventListeners() {
        // Listen for data updates from other modules
        this.eventBus.subscribe('dataRefresh', () => this.loadDashboardData());
        this.eventBus.subscribe('stockUpdate', (data) => {
            this.updateStockSummary(data);
            this.updateFinancialKPIs(data);
        });
        this.eventBus.subscribe('financeUpdate', (data) => {
            this.updateFinancialKPIs(data);
            this.updateCashflowProjections(data);
        });
        this.eventBus.subscribe('arApUpdate', (data) => {
            this.updateARAPSummary(data);
            this.updateCashflowProjections(data);
        });
        this.eventBus.subscribe('transactionUpdate', (data) => {
            this.handleTransactionUpdate(data);
        });
    }
    
    handleTransactionUpdate(data) {
        // Update relevant KPIs and projections when transactions change
        Promise.all([
            this.api.getAccountsReceivable(),
            this.api.getAccountsPayable(),
            this.api.getInventoryValue()
        ]).then(([arTotal, apTotal, inventoryValue]) => {
            this.updateFinancialKPIs({
                arTotal,
                apTotal,
                inventoryValue
            });
            
            this.updateCashflowProjections({
                arTotal,
                apTotal,
                pendingTransactions: [data]
            });
        });
    }
    
    updateCashflowProjections(data) {
        const { arTotal, apTotal, pendingSales, pendingPurchases } = data;
        
        // Update cash flow projection chart
        if (this.charts.cashflow) {
            const projections = this.calculateCashflowProjections({
                arTotal,
                apTotal,
                pendingSales,
                pendingPurchases
            });
            
            this.charts.cashflow.data.labels = projections.labels;
            this.charts.cashflow.data.datasets[0].data = projections.inflow;
            this.charts.cashflow.data.datasets[1].data = projections.outflow;
            this.charts.cashflow.data.datasets[2].data = projections.netflow;
            this.charts.cashflow.update();
        }
    }
    
    calculateCashflowProjections(data) {
        const today = new Date();
        const projectionDays = 30;
        const labels = [];
        const inflow = new Array(projectionDays).fill(0);
        const outflow = new Array(projectionDays).fill(0);
        const netflow = new Array(projectionDays).fill(0);
        
        // Generate date labels
        for (let i = 0; i < projectionDays; i++) {
            const date = new Date(today);
            date.setDate(date.getDate() + i);
            labels.push(date.toLocaleDateString());
        }
        
        // Add pending sales to inflow
        data.pendingSales?.forEach(sale => {
            const dueDate = new Date(sale.dueDate);
            const dayIndex = Math.floor((dueDate - today) / (1000 * 60 * 60 * 24));
            if (dayIndex >= 0 && dayIndex < projectionDays) {
                inflow[dayIndex] += sale.amount;
            }
        });
        
        // Add pending purchases to outflow
        data.pendingPurchases?.forEach(purchase => {
            const dueDate = new Date(purchase.dueDate);
            const dayIndex = Math.floor((dueDate - today) / (1000 * 60 * 60 * 24));
            if (dayIndex >= 0 && dayIndex < projectionDays) {
                outflow[dayIndex] += purchase.amount;
            }
        });
        
        // Calculate net flow
        for (let i = 0; i < projectionDays; i++) {
            netflow[i] = inflow[i] - outflow[i];
        }
        
        return { labels, inflow, outflow, netflow };
    }

    async loadDashboardData() {
        try {
            console.log('Loading dashboard data...');
            
            // Get all data in parallel
            const [
                monthlyFinancials,
                quarterlyBudget,
                arAging,
                apAging,
                inventoryValue,
                arTotal,
                apTotal,
                payrollTotal
            ] = await Promise.all([
                this.api.getMonthlyFinancials(),
                this.api.getQuarterlyBudget(),
                this.api.getARAgingData(),
                this.api.getAPAgingData(),
                this.api.getInventoryValue(),
                this.api.getAccountsReceivable(),
                this.api.getAccountsPayable(),
                this.calculatePayrollTotal()
            ]);

            console.log('Dashboard data loaded:', {
                monthlyFinancials,
                quarterlyBudget,
                arAging,
                apAging
            });

            // Update all widgets with the new data
            this.updateAllDashboardWidgets({
                monthlyFinancials,
                quarterlyBudget,
                arAging,
                apAging,
                inventoryValue,
                arTotal,
                apTotal,
                payrollTotal
            });

        } catch (error) {
            console.error('Error loading dashboard data:', error);
            this.eventBus.publish('error', { 
                message: 'Failed to load dashboard data',
                details: error.message 
            });
        }
    }

    setupCharts() {
        // Revenue vs Expenses Chart
        const revenueCtx = document.getElementById('revenue-expenses-chart')?.getContext('2d');
        if (revenueCtx) {
            this.charts.revenueExpenses = new Chart(revenueCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [
                        {
                            label: 'Revenue',
                            data: [],
                            borderColor: '#28a745',
                            fill: false
                        },
                        {
                            label: 'Expenses',
                            data: [],
                            borderColor: '#dc3545',
                            fill: false
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // Budget vs Actual Chart
        const budgetCtx = document.getElementById('budget-actual-chart')?.getContext('2d');
        if (budgetCtx) {
            this.charts.budgetActual = new Chart(budgetCtx, {
                type: 'bar',
                data: {
                    labels: [],
                    datasets: [
                        {
                            label: 'Budget',
                            data: [],
                            backgroundColor: '#007bff'
                        },
                        {
                            label: 'Actual',
                            data: [],
                            backgroundColor: '#17a2b8'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // AR Aging Chart
        const arCtx = document.getElementById('ar-aging-chart')?.getContext('2d');
        if (arCtx) {
            this.charts.arAging = new Chart(arCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Current', '1-30 Days', '31-60 Days', '61-90 Days', '90+ Days'],
                    datasets: [{
                        data: [],
                        backgroundColor: [
                            '#28a745',
                            '#ffc107',
                            '#fd7e14',
                            '#dc3545',
                            '#6c757d'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }

        // AP Aging Chart
        const apCtx = document.getElementById('ap-aging-chart')?.getContext('2d');
        if (apCtx) {
            this.charts.apAging = new Chart(apCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Current', '1-30 Days', '31-60 Days', '61-90 Days', '90+ Days'],
                    datasets: [{
                        data: [],
                        backgroundColor: [
                            '#28a745',
                            '#ffc107',
                            '#fd7e14',
                            '#dc3545',
                            '#6c757d'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    }

    updateAllDashboardWidgets(data) {
        this.updateFinancialKPIs(data);
        this.updateARAPSummary(data);
        this.updateStockSummary(data);
        this.updateCharts(data);
    }

    updateFinancialKPIs(data) {
        // Calculate monthly totals
        let revenue = 0;
        let expenses = 0;

        if (data.monthlyFinancials) {
            revenue = data.monthlyFinancials.revenue.reduce((sum, val) => sum + val, 0);
            expenses = data.monthlyFinancials.expenses.reduce((sum, val) => sum + val, 0);
        }

        // Update Revenue
        const elem = document.getElementById('total-revenue');
        if (elem) elem.textContent = formatters.currency(revenue);

        // Update Stock Value
        const stockElem = document.getElementById('stock-value');
        if (stockElem) stockElem.textContent = formatters.currency(data.inventoryValue || 0);

        // Update Payroll
        const payrollElem = document.getElementById('payroll-total');
        if (payrollElem) payrollElem.textContent = formatters.currency(data.payrollTotal || 0);

        // Update Net Income
        const netIncomeElem = document.getElementById('net-income');
        if (netIncomeElem) {
            const netIncome = revenue - expenses;
            netIncomeElem.textContent = formatters.currency(netIncome);
        }

        // Notify other modules of the update
        this.eventBus.publish('financeUpdate', {
            revenue,
            expenses,
            netIncome: revenue - expenses,
            ...data
        });
    }

    updateARAPSummary(data) {
        // Update AR
        const arElem = document.getElementById('ar-outstanding');
        if (arElem) arElem.textContent = formatters.currency(data.arTotal || 0);

        const arOverdueElem = document.getElementById('ar-overdue');
        if (arOverdueElem) arOverdueElem.textContent = formatters.currency(data.arOverdue || 0);

        // Update AP
        const apElem = document.getElementById('ap-outstanding');
        if (apElem) apElem.textContent = formatters.currency(data.apTotal || 0);

        const apDueSoonElem = document.getElementById('ap-due-soon');
        if (apDueSoonElem) apDueSoonElem.textContent = formatters.currency(data.apDueSoon || 0);
    }

    updateStockSummary(data) {
        const stockTable = document.getElementById('stock-summary');
        if (!stockTable || !data.stockCategories) return;

        stockTable.innerHTML = data.stockCategories.map(category => `
            <tr>
                <td>${category.name}</td>
                <td>${category.quantity}</td>
                <td>${formatters.currency(category.value)}</td>
                <td>
                    <span class="badge bg-${this.getStockStatusClass(category.status)}">
                        ${category.status}
                    </span>
                </td>
            </tr>
        `).join('');
    }

    updateCharts(data) {
        console.log('Updating charts with data:', data);

        // Update Revenue vs Expenses Chart
        if (this.charts.revenueExpenses && data.monthlyFinancials) {
            const { labels, revenue, expenses } = data.monthlyFinancials;
            console.log('Monthly financials:', { labels, revenue, expenses });
            
            this.charts.revenueExpenses.data.labels = labels;
            this.charts.revenueExpenses.data.datasets[0].data = revenue;
            this.charts.revenueExpenses.data.datasets[1].data = expenses;
            this.charts.revenueExpenses.update();
        }

        // Update Budget vs Actual Chart
        if (this.charts.budgetActual && data.quarterlyBudget) {
            const { labels, budget, actual } = data.quarterlyBudget;
            console.log('Quarterly budget:', { labels, budget, actual });
            
            this.charts.budgetActual.data.labels = labels;
            this.charts.budgetActual.data.datasets[0].data = budget;
            this.charts.budgetActual.data.datasets[1].data = actual;
            this.charts.budgetActual.update();
        }

        // Update AR Aging Chart
        if (this.charts.arAging && data.arAging) {
            console.log('AR aging data:', data.arAging);
            this.charts.arAging.data.datasets[0].data = data.arAging;
            this.charts.arAging.update();
        }

        // Update AP Aging Chart
        if (this.charts.apAging && data.apAging) {
            console.log('AP aging data:', data.apAging);
            this.charts.apAging.data.datasets[0].data = data.apAging;
            this.charts.apAging.update();
        }
    }

    async calculatePayrollTotal() {
        const currentDate = new Date();
        const employees = await this.api.read('employees');
        return employees.reduce((total, emp) => total + (emp.salary || 0) + (emp.benefits || 0), 0);
    }

    getStockStatusClass(status) {
        switch (status.toLowerCase()) {
            case 'critical': return 'danger';
            case 'low': return 'warning';
            case 'adequate': return 'success';
            default: return 'secondary';
        }
    }
}
