// AR/AP Module
import { apiService } from '../utils/apiService.js';
import { eventBus } from '../utils/eventBus.js';
import { formatters, validators } from '../utils/validation.js';

export default class ArAp {
    constructor(api, eventBus) {
        this.api = api;
        this.eventBus = eventBus;
        this.charts = {};
        
        this.setupEventListeners();
        this.setupCharts();
        this.loadArApData();
        
        // Subscribe to stock updates
        this.eventBus.subscribe('stockUpdate', this.handleStockUpdate.bind(this));
        this.eventBus.subscribe('stockChanged', this.handleStockChange.bind(this));
    }
    
    handleStockUpdate(data) {
        // Update purchase/sale options based on stock levels
        this.updateItemOptions(data);
        
        // Update any pending transactions that might be affected by stock changes
        this.updatePendingTransactions();
    }
    
    handleStockChange(data) {
        // Handle specific stock changes
        const { itemId, oldQuantity, newQuantity, movement } = data;
        
        // Update related transactions
        this.updateRelatedTransactions(itemId, movement);
    }
    
    async updateItemOptions(stockData) {
        const itemSelects = document.querySelectorAll('.item-select');
        if (!itemSelects.length) return;
        
        const inventory = await this.api.read('inventory');
        
        itemSelects.forEach(select => {
            // Store current value
            const currentValue = select.value;
            
            // Clear options
            select.innerHTML = '<option value="">Select Item</option>';
            
            // Add options based on inventory
            inventory.forEach(item => {
                const option = document.createElement('option');
                option.value = item.id;
                option.textContent = `${item.code} - ${item.description} (${item.quantity} available)`;
                option.disabled = item.quantity <= 0 && select.dataset.type === 'sale';
                select.appendChild(option);
            });
            
            // Restore selected value if still valid
            if (currentValue) {
                select.value = currentValue;
            }
        });
    }
    
    async updatePendingTransactions() {
        const transactions = await this.api.read('transactions');
        const inventory = await this.api.read('inventory');
        
        // Get pending sales that might be affected by stock changes
        const pendingSales = transactions.filter(t => 
            t.type === 'sale' && 
            t.status === 'pending'
        );
        
        // Check each pending sale against current stock levels
        pendingSales.forEach(sale => {
            const item = inventory.find(i => i.id === sale.itemId);
            if (item && item.quantity < sale.quantity) {
                // Mark transaction as at risk
                this.markTransactionAtRisk(sale.id, 'Insufficient stock');
            } else {
                // Clear at-risk status if stock is now sufficient
                this.clearTransactionRisk(sale.id);
            }
        });
        
        // Notify other modules of pending transactions
        this.eventBus.publish('arApUpdate', {
            pendingSales,
            pendingPurchases: transactions.filter(t => 
                t.type === 'purchase' && 
                t.status === 'pending'
            )
        });
    }
    
    async updateRelatedTransactions(itemId, movement) {
        const transactions = await this.api.read('transactions');
        
        // Find transactions related to this item
        const relatedTransactions = transactions.filter(t => 
            t.itemId === itemId && 
            t.status === 'pending'
        );
        
        // Update transaction statuses based on the movement
        for (const transaction of relatedTransactions) {
            if (movement.type === 'in' && transaction.type === 'sale') {
                // Check if we can now fulfill the sale
                const item = await this.api.read('inventory', itemId);
                if (item && item.quantity >= transaction.quantity) {
                    await this.updateTransactionStatus(transaction.id, 'ready');
                }
            }
        }
    }

    setupEventListeners() {
        // Listen for data updates
        this.eventBus.subscribe('dataRefresh', () => this.loadArApData());
        
        // Form submissions
        document.getElementById('new-invoice-form')?.addEventListener('submit', this.handleNewInvoice.bind(this));
        document.getElementById('new-payment-form')?.addEventListener('submit', this.handleNewPayment.bind(this));
        
        // Action buttons
        document.getElementById('export-ar-btn')?.addEventListener('click', () => this.exportData('ar'));
        document.getElementById('export-ap-btn')?.addEventListener('click', () => this.exportData('ap'));
    }

    setupCharts() {
        // AR Aging Chart
        const arCtx = document.getElementById('ar-aging-chart')?.getContext('2d');
        if (arCtx) {
            this.charts.arAging = new Chart(arCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Current', '1-30 Days', '31-60 Days', '61-90 Days', '90+ Days'],
                    datasets: [{
                        data: [],
                        backgroundColor: ['#28a745', '#ffc107', '#fd7e14', '#dc3545', '#6c757d']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }

        // AP Aging Chart
        const apCtx = document.getElementById('ap-aging-chart')?.getContext('2d');
        if (apCtx) {
            this.charts.apAging = new Chart(apCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Current', '1-30 Days', '31-60 Days', '61-90 Days', '90+ Days'],
                    datasets: [{
                        data: [],
                        backgroundColor: ['#28a745', '#ffc107', '#fd7e14', '#dc3545', '#6c757d']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    }

    async loadArApData() {
        try {
            const transactions = await this.api.read('transactions');
            const [arData, apData] = this.processTransactions(transactions);
            
            this.updateArTable(arData);
            this.updateApTable(apData);
            this.updateCharts(arData, apData);
            this.updateSummary(arData, apData);

            // Notify dashboard
            this.eventBus.publish('arApUpdate', {
                arTotal: this.calculateTotal(arData),
                arOverdue: this.calculateOverdue(arData),
                apTotal: this.calculateTotal(apData),
                apDueSoon: this.calculateDueSoon(apData)
            });

        } catch (error) {
            console.error('Error loading AR/AP data:', error);
            this.eventBus.publish('error', { message: 'Failed to load AR/AP data' });
        }
    }

    processTransactions(transactions) {
        const arData = transactions.filter(t => t.type === 'receivable');
        const apData = transactions.filter(t => t.type === 'payable');
        return [arData, apData];
    }

    updateArTable(data) {
        const tbody = document.getElementById('ar-table');
        if (!tbody) return;

        tbody.innerHTML = data.map(invoice => `
            <tr>
                <td>${invoice.date}</td>
                <td>${invoice.number}</td>
                <td>${invoice.customer}</td>
                <td>${formatters.currency(invoice.amount)}</td>
                <td>${formatters.date(invoice.dueDate)}</td>
                <td>${this.getDaysOverdue(invoice.dueDate)}</td>
                <td>
                    <span class="badge bg-${this.getStatusClass(invoice.status)}">
                        ${invoice.status}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="app.modules.arAp.recordPayment('${invoice.id}')">
                        <i class="bi bi-cash"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-secondary" onclick="app.modules.arAp.viewDetails('${invoice.id}')">
                        <i class="bi bi-eye"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    updateApTable(data) {
        const tbody = document.getElementById('ap-table');
        if (!tbody) return;

        tbody.innerHTML = data.map(bill => `
            <tr>
                <td>${bill.date}</td>
                <td>${bill.number}</td>
                <td>${bill.vendor}</td>
                <td>${formatters.currency(bill.amount)}</td>
                <td>${formatters.date(bill.dueDate)}</td>
                <td>${this.getDaysOverdue(bill.dueDate)}</td>
                <td>
                    <span class="badge bg-${this.getStatusClass(bill.status)}">
                        ${bill.status}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="app.modules.arAp.payBill('${bill.id}')">
                        <i class="bi bi-cash"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-secondary" onclick="app.modules.arAp.viewDetails('${bill.id}')">
                        <i class="bi bi-eye"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    updateCharts(arData, apData) {
        if (this.charts.arAging) {
            const arAging = this.calculateAging(arData);
            this.charts.arAging.data.datasets[0].data = Object.values(arAging);
            this.charts.arAging.update();
        }

        if (this.charts.apAging) {
            const apAging = this.calculateAging(apData);
            this.charts.apAging.data.datasets[0].data = Object.values(apAging);
            this.charts.apAging.update();
        }
    }

    updateSummary(arData, apData) {
        // Update AR Summary
        const arTotal = document.getElementById('ar-total');
        if (arTotal) arTotal.textContent = formatters.currency(this.calculateTotal(arData));

        const arOverdue = document.getElementById('ar-overdue');
        if (arOverdue) arOverdue.textContent = formatters.currency(this.calculateOverdue(arData));

        // Update AP Summary
        const apTotal = document.getElementById('ap-total');
        if (apTotal) apTotal.textContent = formatters.currency(this.calculateTotal(apData));

        const apDue = document.getElementById('ap-due');
        if (apDue) apDue.textContent = formatters.currency(this.calculateDueSoon(apData));
    }

    async handleNewInvoice(event) {
        event.preventDefault();
        const form = event.target;
        const data = new FormData(form);

        const newInvoice = {
            date: data.get('date'),
            customer: data.get('customer'),
            amount: Number(data.get('amount')),
            dueDate: data.get('dueDate'),
            type: 'receivable',
            status: 'pending',
            itemId: data.get('itemId'),
            quantity: Number(data.get('quantity')),
            unitPrice: Number(data.get('unitPrice'))
        };

        try {
            // Validate stock availability for sales
            if (newInvoice.itemId && newInvoice.quantity) {
                const item = await this.api.read('inventory', newInvoice.itemId);
                if (!item || item.quantity < newInvoice.quantity) {
                    throw new Error('Insufficient stock available');
                }
            }

            // Create transaction
            const transaction = await this.api.create('transactions', newInvoice);

            // If this is a sale, create a pending stock movement
            if (newInvoice.itemId && newInvoice.quantity) {
                this.eventBus.publish('transactionUpdate', {
                    ...transaction,
                    type: 'sale'
                });
            }

            this.eventBus.publish('notification', {
                type: 'success',
                message: 'Invoice created successfully'
            });
            
            form.reset();
            this.loadArApData();
            
        } catch (error) {
            this.eventBus.publish('error', {
                message: error.message || 'Failed to create invoice'
            });
        }
    }
    
    async handleNewPayment(event) {
        event.preventDefault();
        const form = event.target;
        const data = new FormData(form);

        const paymentData = {
            transactionId: data.get('transactionId'),
            amount: Number(data.get('amount')),
            date: data.get('date'),
            method: data.get('method'),
            reference: data.get('reference')
        };

        try {
            // Get original transaction
            const transaction = await this.api.read('transactions', paymentData.transactionId);
            if (!transaction) {
                throw new Error('Transaction not found');
            }

            // Update transaction status
            const updatedTransaction = await this.api.update('transactions', transaction.id, {
                status: paymentData.amount >= transaction.amount ? 'paid' : 'partial',
                paidAmount: (transaction.paidAmount || 0) + paymentData.amount,
                lastPaymentDate: paymentData.date
            });

            // If this was a sale and it's now paid, trigger stock movement
            if (updatedTransaction.status === 'paid' && 
                updatedTransaction.itemId &&
                updatedTransaction.quantity) {
                
                this.eventBus.publish('transactionUpdate', {
                    ...updatedTransaction,
                    type: 'sale',
                    status: 'completed'
                });
            }

            this.eventBus.publish('notification', {
                type: 'success',
                message: 'Payment recorded successfully'
            });
            
            form.reset();
            this.loadArApData();
            
        } catch (error) {
            this.eventBus.publish('error', {
                message: error.message || 'Failed to record payment'
            });
        }
    }
    
    async markTransactionAtRisk(transactionId, reason) {
        try {
            await this.api.update('transactions', transactionId, {
                riskStatus: 'at-risk',
                riskReason: reason
            });

            // Update UI
            const row = document.querySelector(`tr[data-transaction-id="${transactionId}"]`);
            if (row) {
                const statusCell = row.querySelector('.transaction-status');
                if (statusCell) {
                    statusCell.innerHTML = `
                        <span class="badge bg-danger">At Risk</span>
                        <small class="text-danger d-block">${reason}</small>
                    `;
                }
            }
        } catch (error) {
            console.error('Error marking transaction at risk:', error);
        }
    }
    
    async clearTransactionRisk(transactionId) {
        try {
            const transaction = await this.api.read('transactions', transactionId);
            if (transaction) {
                await this.api.update('transactions', transactionId, {
                    riskStatus: null,
                    riskReason: null
                });

                // Update UI
                const row = document.querySelector(`tr[data-transaction-id="${transactionId}"]`);
                if (row) {
                    const statusCell = row.querySelector('.transaction-status');
                    if (statusCell) {
                        statusCell.innerHTML = `
                            <span class="badge bg-${this.getStatusClass(transaction.status)}">
                                ${transaction.status}
                            </span>
                        `;
                    }
                }
            }
        } catch (error) {
            console.error('Error clearing transaction risk:', error);
        }
    }
    
    async updateTransactionStatus(transactionId, newStatus) {
        try {
            await this.api.update('transactions', transactionId, { status: newStatus });
            this.loadArApData();
        } catch (error) {
            console.error('Error updating transaction status:', error);
        }
    }

    calculateAging(data) {
        const aging = {
            current: 0,
            '30': 0,
            '60': 0,
            '90': 0,
            'older': 0
        };

        data.forEach(item => {
            const days = this.getDaysOverdue(item.dueDate);
            if (days <= 0) aging.current += item.amount;
            else if (days <= 30) aging['30'] += item.amount;
            else if (days <= 60) aging['60'] += item.amount;
            else if (days <= 90) aging['90'] += item.amount;
            else aging.older += item.amount;
        });

        return aging;
    }

    calculateTotal(data) {
        return data.reduce((sum, item) => sum + item.amount, 0);
    }

    calculateOverdue(data) {
        return data
            .filter(item => this.getDaysOverdue(item.dueDate) > 0)
            .reduce((sum, item) => sum + item.amount, 0);
    }

    calculateDueSoon(data) {
        return data
            .filter(item => {
                const days = this.getDaysOverdue(item.dueDate);
                return days >= -7 && days <= 0;
            })
            .reduce((sum, item) => sum + item.amount, 0);
    }

    getDaysOverdue(dueDate) {
        const due = new Date(dueDate);
        const today = new Date();
        return Math.floor((today - due) / (1000 * 60 * 60 * 24));
    }

    getStatusClass(status) {
        switch (status.toLowerCase()) {
            case 'paid': return 'success';
            case 'overdue': return 'danger';
            case 'pending': return 'warning';
            default: return 'secondary';
        }
    }

    async exportData(type) {
        const transactions = await this.api.read('transactions');
        const data = transactions.filter(t => 
            t.type === (type === 'ar' ? 'receivable' : 'payable')
        );

        const csv = this.convertToCSV(data);
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `${type}-export.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    convertToCSV(data) {
        const headers = ['Date', 'Number', 'Customer/Vendor', 'Amount', 'Due Date', 'Status'];
        const rows = data.map(item => [
            item.date,
            item.number,
            item.customer || item.vendor,
            item.amount,
            item.dueDate,
            item.status
        ]);
        return [headers, ...rows]
            .map(row => row.map(String).map(cell => `"${cell}"`).join(','))
            .join('\n');
    }
}
