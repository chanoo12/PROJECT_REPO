// AR/AP Module
import { apiService } from '../utils/apiService.js';
import { eventBus } from '../utils/eventBus.js';
import { formatters, validators } from '../utils/validation.js';

export default class ArAp {
    constructor(api, eventBus) {
        this.api = api;
        this.eventBus = eventBus;
        this.charts = {};
        
        this.setupEventListeners();
        this.setupCharts();
        this.loadArApData();
    }

    setupEventListeners() {
        // Listen for data updates
        this.eventBus.subscribe('dataRefresh', () => this.loadArApData());
        
        // Form submissions
        document.getElementById('new-invoice-form')?.addEventListener('submit', this.handleNewInvoice.bind(this));
        document.getElementById('new-payment-form')?.addEventListener('submit', this.handleNewPayment.bind(this));
        
        // Action buttons
        document.getElementById('export-ar-btn')?.addEventListener('click', () => this.exportData('ar'));
        document.getElementById('export-ap-btn')?.addEventListener('click', () => this.exportData('ap'));
    }

    setupCharts() {
        // AR Aging Chart
        const arCtx = document.getElementById('ar-aging-chart')?.getContext('2d');
        if (arCtx) {
            this.charts.arAging = new Chart(arCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Current', '1-30 Days', '31-60 Days', '61-90 Days', '90+ Days'],
                    datasets: [{
                        data: [],
                        backgroundColor: ['#28a745', '#ffc107', '#fd7e14', '#dc3545', '#6c757d']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }

        // AP Aging Chart
        const apCtx = document.getElementById('ap-aging-chart')?.getContext('2d');
        if (apCtx) {
            this.charts.apAging = new Chart(apCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Current', '1-30 Days', '31-60 Days', '61-90 Days', '90+ Days'],
                    datasets: [{
                        data: [],
                        backgroundColor: ['#28a745', '#ffc107', '#fd7e14', '#dc3545', '#6c757d']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    }

    async loadArApData() {
        try {
            const transactions = await this.api.read('transactions');
            const [arData, apData] = this.processTransactions(transactions);
            
            this.updateArTable(arData);
            this.updateApTable(apData);
            this.updateCharts(arData, apData);
            this.updateSummary(arData, apData);

            // Notify dashboard
            this.eventBus.publish('arApUpdate', {
                arTotal: this.calculateTotal(arData),
                arOverdue: this.calculateOverdue(arData),
                apTotal: this.calculateTotal(apData),
                apDueSoon: this.calculateDueSoon(apData)
            });

        } catch (error) {
            console.error('Error loading AR/AP data:', error);
            this.eventBus.publish('error', { message: 'Failed to load AR/AP data' });
        }
    }

    processTransactions(transactions) {
        const arData = transactions.filter(t => t.type === 'receivable');
        const apData = transactions.filter(t => t.type === 'payable');
        return [arData, apData];
    }

    updateArTable(data) {
        const tbody = document.getElementById('ar-table');
        if (!tbody) return;

        tbody.innerHTML = data.map(invoice => `
            <tr>
                <td>${invoice.date}</td>
                <td>${invoice.number}</td>
                <td>${invoice.customer}</td>
                <td>${formatters.currency(invoice.amount)}</td>
                <td>${formatters.date(invoice.dueDate)}</td>
                <td>${this.getDaysOverdue(invoice.dueDate)}</td>
                <td>
                    <span class="badge bg-${this.getStatusClass(invoice.status)}">
                        ${invoice.status}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="app.modules.arAp.recordPayment('${invoice.id}')">
                        <i class="bi bi-cash"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-secondary" onclick="app.modules.arAp.viewDetails('${invoice.id}')">
                        <i class="bi bi-eye"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    updateApTable(data) {
        const tbody = document.getElementById('ap-table');
        if (!tbody) return;

        tbody.innerHTML = data.map(bill => `
            <tr>
                <td>${bill.date}</td>
                <td>${bill.number}</td>
                <td>${bill.vendor}</td>
                <td>${formatters.currency(bill.amount)}</td>
                <td>${formatters.date(bill.dueDate)}</td>
                <td>${this.getDaysOverdue(bill.dueDate)}</td>
                <td>
                    <span class="badge bg-${this.getStatusClass(bill.status)}">
                        ${bill.status}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="app.modules.arAp.payBill('${bill.id}')">
                        <i class="bi bi-cash"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-secondary" onclick="app.modules.arAp.viewDetails('${bill.id}')">
                        <i class="bi bi-eye"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    updateCharts(arData, apData) {
        if (this.charts.arAging) {
            const arAging = this.calculateAging(arData);
            this.charts.arAging.data.datasets[0].data = Object.values(arAging);
            this.charts.arAging.update();
        }

        if (this.charts.apAging) {
            const apAging = this.calculateAging(apData);
            this.charts.apAging.data.datasets[0].data = Object.values(apAging);
            this.charts.apAging.update();
        }
    }

    updateSummary(arData, apData) {
        // Update AR Summary
        const arTotal = document.getElementById('ar-total');
        if (arTotal) arTotal.textContent = formatters.currency(this.calculateTotal(arData));

        const arOverdue = document.getElementById('ar-overdue');
        if (arOverdue) arOverdue.textContent = formatters.currency(this.calculateOverdue(arData));

        // Update AP Summary
        const apTotal = document.getElementById('ap-total');
        if (apTotal) apTotal.textContent = formatters.currency(this.calculateTotal(apData));

        const apDue = document.getElementById('ap-due');
        if (apDue) apDue.textContent = formatters.currency(this.calculateDueSoon(apData));
    }

    async handleNewInvoice(event) {
        event.preventDefault();
        const form = event.target;
        const data = new FormData(form);

        const newInvoice = {
            date: data.get('date'),
            customer: data.get('customer'),
            amount: Number(data.get('amount')),
            dueDate: data.get('dueDate'),
            type: 'receivable',
            status: 'pending'
        };

        try {
            await this.api.create('transactions', newInvoice);
            this.eventBus.publish('notification', {
                type: 'success',
                message: 'Invoice created successfully'
            });
            form.reset();
            this.loadArApData();
        } catch (error) {
            this.eventBus.publish('error', {
                message: 'Failed to create invoice'
            });
        }
    }

    calculateAging(data) {
        const aging = {
            current: 0,
            '30': 0,
            '60': 0,
            '90': 0,
            'older': 0
        };

        data.forEach(item => {
            const days = this.getDaysOverdue(item.dueDate);
            if (days <= 0) aging.current += item.amount;
            else if (days <= 30) aging['30'] += item.amount;
            else if (days <= 60) aging['60'] += item.amount;
            else if (days <= 90) aging['90'] += item.amount;
            else aging.older += item.amount;
        });

        return aging;
    }

    calculateTotal(data) {
        return data.reduce((sum, item) => sum + item.amount, 0);
    }

    calculateOverdue(data) {
        return data
            .filter(item => this.getDaysOverdue(item.dueDate) > 0)
            .reduce((sum, item) => sum + item.amount, 0);
    }

    calculateDueSoon(data) {
        return data
            .filter(item => {
                const days = this.getDaysOverdue(item.dueDate);
                return days >= -7 && days <= 0;
            })
            .reduce((sum, item) => sum + item.amount, 0);
    }

    getDaysOverdue(dueDate) {
        const due = new Date(dueDate);
        const today = new Date();
        return Math.floor((today - due) / (1000 * 60 * 60 * 24));
    }

    getStatusClass(status) {
        switch (status.toLowerCase()) {
            case 'paid': return 'success';
            case 'overdue': return 'danger';
            case 'pending': return 'warning';
            default: return 'secondary';
        }
    }

    async exportData(type) {
        const transactions = await this.api.read('transactions');
        const data = transactions.filter(t => 
            t.type === (type === 'ar' ? 'receivable' : 'payable')
        );

        const csv = this.convertToCSV(data);
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `${type}-export.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    convertToCSV(data) {
        const headers = ['Date', 'Number', 'Customer/Vendor', 'Amount', 'Due Date', 'Status'];
        const rows = data.map(item => [
            item.date,
            item.number,
            item.customer || item.vendor,
            item.amount,
            item.dueDate,
            item.status
        ]);
        return [headers, ...rows]
            .map(row => row.map(String).map(cell => `"${cell}"`).join(','))
            .join('\n');
    }
}
