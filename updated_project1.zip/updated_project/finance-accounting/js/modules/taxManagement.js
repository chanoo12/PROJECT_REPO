// Tax Management Module
import { apiService } from '../utils/apiService.js';
import { eventBus } from '../utils/eventBus.js';
import { formatters } from '../utils/validation.js';
import { stateManager } from '../utils/stateManager.js';

export default class TaxManagement {
    constructor() {
        this.api = apiService;
        this.eventBus = eventBus;
        this.state = stateManager;

        // Initialize tax rates - in real app, these would come from config/API
        this.taxRates = {
            sales: 0.1,      // 10% sales tax
            income: 0.25,    // 25% income tax
            payroll: 0.15    // 15% payroll tax
        };
        
        // Initialize profit margin for income tax calculation
        this.profitMargin = 0.2; // 20% profit margin
        
        this.setupTaxSection();
        this.loadTaxData();
        
        // Subscribe to GL updates
        this.eventBus.subscribe('glUpdate', () => this.recalculateTaxes());
        this.eventBus.subscribe('dataRefresh', () => this.loadTaxData());
    }

    setupTaxSection() {
        const taxSection = document.createElement('div');
        taxSection.id = 'tax';
        taxSection.className = 'section';
        taxSection.innerHTML = `
            <h2>Tax Management</h2>
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Tax Summary</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <p>Sales Tax Payable: <span id="sales-tax-payable">$0</span></p>
                                    <p>Income Tax Provision: <span id="income-tax-provision">$0</span></p>
                                </div>
                                <div class="col-md-6">
                                    <p>Payroll Tax: <span id="payroll-tax">$0</span></p>
                                    <p>Total Tax Liability: <span id="total-tax-liability">$0</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Tax Calendar</h5>
                            <div id="tax-calendar" class="list-group">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Tax Computation</h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Taxable Amount</th>
                                            <th>Tax Rate</th>
                                            <th>Tax Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tax-computation">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.querySelector('.container-fluid').appendChild(taxSection);
    }

    loadTaxData() {
        this.recalculateTaxes();
        this.updateTaxCalendar();
    }

    async recalculateTaxes() {
        try {
            // Fetch all required data in parallel
            const [salesData, payrollData] = await Promise.all([
                this.api.read('sales/total'),
                this.api.read('payroll/total')
            ]);

            const totalSales = salesData.total;
            const salesTax = totalSales * this.taxRates.sales;

            // Calculate Income Tax
            const netIncome = totalSales * this.profitMargin;
            const incomeTax = netIncome * this.taxRates.income;

            // Calculate Payroll Tax
            const payrollTotal = payrollData.total;
            const payrollTax = payrollTotal * this.taxRates.payroll;

            // Update state
            this.state.commit('tax/update', {
                salesTax,
                incomeTax,
                payrollTax,
                totalTax: salesTax + incomeTax + payrollTax
            });

            // Update tax computation table
            document.getElementById('tax-computation').innerHTML = `
                <tr>
                    <td>Sales Tax</td>
                    <td>${formatters.currency(totalSales)}</td>
                    <td>${(this.taxRates.sales * 100)}%</td>
                    <td>${formatters.currency(salesTax)}</td>
                </tr>
                <tr>
                    <td>Income Tax</td>
                    <td>${formatters.currency(netIncome)}</td>
                    <td>${(this.taxRates.income * 100)}%</td>
                    <td>${formatters.currency(incomeTax)}</td>
                </tr>
                <tr>
                    <td>Payroll Tax</td>
                    <td>${formatters.currency(payrollTotal)}</td>
                    <td>${(this.taxRates.payroll * 100)}%</td>
                    <td>${formatters.currency(payrollTax)}</td>
                </tr>
            `;

            // Update summary values
            document.getElementById('sales-tax-payable').textContent = formatters.currency(salesTax);
            document.getElementById('income-tax-provision').textContent = formatters.currency(incomeTax);
            document.getElementById('payroll-tax').textContent = formatters.currency(payrollTax);
            document.getElementById('total-tax-liability').textContent = 
                formatters.currency(salesTax + incomeTax + payrollTax);

            // Notify other modules of tax update
            this.eventBus.publish('taxUpdate', {
                salesTax,
                incomeTax,
                payrollTax,
                totalTax: salesTax + incomeTax + payrollTax
            });

        } catch (error) {
            console.error('Error calculating taxes:', error);
            this.eventBus.publish('error', { 
                message: 'Failed to calculate taxes',
                details: error.message
            });
        }
    }

    async updateTaxCalendar() {
        try {
            // Get tax deadlines from API
            const deadlines = await this.api.read('tax/deadlines');
            const calendar = document.getElementById('tax-calendar');
            
            if (!calendar) return;

            calendar.innerHTML = deadlines.map(deadline => `
                <div class="list-group-item">
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1">${deadline.description}</h6>
                        <small>${formatters.date(deadline.date)}</small>
                    </div>
                    <small class="text-${deadline.status === 'pending' ? 'warning' : 'success'}">
                        ${deadline.status === 'pending' ? 'Pending' : 'Filed'}
                    </small>
                </div>
            `).join('');

            // Update state with calendar data
            this.state.commit('tax/deadlines', deadlines);

        } catch (error) {
            console.error('Error updating tax calendar:', error);
            this.eventBus.publish('error', { 
                message: 'Failed to update tax calendar',
                details: error.message
            });
        }
    }
}

}
