// Dashboard Module
import { apiService } from '../utils/apiService.js';
import { eventBus } from '../utils/eventBus.js';
import { formatters } from '../utils/validation.js';

export default class Dashboard {
    constructor(api, eventBus) {
        this.api = api;
        this.eventBus = eventBus;
        this.charts = {};
        
        this.setupEventListeners();
        this.setupCharts();
        this.loadDashboardData();
    }

    setupEventListeners() {
        // Listen for data updates from other modules
        this.eventBus.subscribe('dataRefresh', () => this.loadDashboardData());
        this.eventBus.subscribe('stockUpdate', (data) => this.updateStockSummary(data));
        this.eventBus.subscribe('financeUpdate', (data) => this.updateFinancialKPIs(data));
        this.eventBus.subscribe('arApUpdate', (data) => this.updateARAPSummary(data));
    }

    async loadDashboardData() {
        try {
            const [
                financialData,
                inventoryValue,
                arTotal,
                apTotal,
                payrollTotal
            ] = await Promise.all([
                this.api.read('transactions'),
                this.api.getInventoryValue(),
                this.api.getAccountsReceivable(),
                this.api.getAccountsPayable(),
                this.calculatePayrollTotal()
            ]);

            this.updateAllDashboardWidgets({
                financialData,
                inventoryValue,
                arTotal,
                apTotal,
                payrollTotal
            });

        } catch (error) {
            console.error('Error loading dashboard data:', error);
            this.eventBus.publish('error', { message: 'Failed to load dashboard data' });
        }
    }

    setupCharts() {
        // Revenue vs Expenses Chart
        const revenueCtx = document.getElementById('revenue-expenses-chart')?.getContext('2d');
        if (revenueCtx) {
            this.charts.revenueExpenses = new Chart(revenueCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [
                        {
                            label: 'Revenue',
                            data: [],
                            borderColor: '#28a745',
                            fill: false
                        },
                        {
                            label: 'Expenses',
                            data: [],
                            borderColor: '#dc3545',
                            fill: false
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // Budget vs Actual Chart
        const budgetCtx = document.getElementById('budget-actual-chart')?.getContext('2d');
        if (budgetCtx) {
            this.charts.budgetActual = new Chart(budgetCtx, {
                type: 'bar',
                data: {
                    labels: [],
                    datasets: [
                        {
                            label: 'Budget',
                            data: [],
                            backgroundColor: '#007bff'
                        },
                        {
                            label: 'Actual',
                            data: [],
                            backgroundColor: '#17a2b8'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // AR Aging Chart
        const arCtx = document.getElementById('ar-aging-chart')?.getContext('2d');
        if (arCtx) {
            this.charts.arAging = new Chart(arCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Current', '1-30 Days', '31-60 Days', '61-90 Days', '90+ Days'],
                    datasets: [{
                        data: [],
                        backgroundColor: [
                            '#28a745',
                            '#ffc107',
                            '#fd7e14',
                            '#dc3545',
                            '#6c757d'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }

        // AP Aging Chart
        const apCtx = document.getElementById('ap-aging-chart')?.getContext('2d');
        if (apCtx) {
            this.charts.apAging = new Chart(apCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Current', '1-30 Days', '31-60 Days', '61-90 Days', '90+ Days'],
                    datasets: [{
                        data: [],
                        backgroundColor: [
                            '#28a745',
                            '#ffc107',
                            '#fd7e14',
                            '#dc3545',
                            '#6c757d'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    }

    updateAllDashboardWidgets(data) {
        this.updateFinancialKPIs(data);
        this.updateARAPSummary(data);
        this.updateStockSummary(data);
        this.updateCharts(data);
    }

    updateFinancialKPIs(data) {
        // Update Revenue
        const elem = document.getElementById('total-revenue');
        if (elem) elem.textContent = formatters.currency(data.revenue || 0);

        // Update Stock Value
        const stockElem = document.getElementById('stock-value');
        if (stockElem) stockElem.textContent = formatters.currency(data.inventoryValue || 0);

        // Update Payroll
        const payrollElem = document.getElementById('payroll-total');
        if (payrollElem) payrollElem.textContent = formatters.currency(data.payrollTotal || 0);

        // Update Net Income
        const netIncomeElem = document.getElementById('net-income');
        if (netIncomeElem) {
            const netIncome = (data.revenue || 0) - (data.expenses || 0);
            netIncomeElem.textContent = formatters.currency(netIncome);
        }
    }

    updateARAPSummary(data) {
        // Update AR
        const arElem = document.getElementById('ar-outstanding');
        if (arElem) arElem.textContent = formatters.currency(data.arTotal || 0);

        const arOverdueElem = document.getElementById('ar-overdue');
        if (arOverdueElem) arOverdueElem.textContent = formatters.currency(data.arOverdue || 0);

        // Update AP
        const apElem = document.getElementById('ap-outstanding');
        if (apElem) apElem.textContent = formatters.currency(data.apTotal || 0);

        const apDueSoonElem = document.getElementById('ap-due-soon');
        if (apDueSoonElem) apDueSoonElem.textContent = formatters.currency(data.apDueSoon || 0);
    }

    updateStockSummary(data) {
        const stockTable = document.getElementById('stock-summary');
        if (!stockTable || !data.stockCategories) return;

        stockTable.innerHTML = data.stockCategories.map(category => `
            <tr>
                <td>${category.name}</td>
                <td>${category.quantity}</td>
                <td>${formatters.currency(category.value)}</td>
                <td>
                    <span class="badge bg-${this.getStockStatusClass(category.status)}">
                        ${category.status}
                    </span>
                </td>
            </tr>
        `).join('');
    }

    updateCharts(data) {
        // Update Revenue vs Expenses Chart
        if (this.charts.revenueExpenses && data.monthlyFinancials) {
            const { labels, revenue, expenses } = data.monthlyFinancials;
            this.charts.revenueExpenses.data.labels = labels;
            this.charts.revenueExpenses.data.datasets[0].data = revenue;
            this.charts.revenueExpenses.data.datasets[1].data = expenses;
            this.charts.revenueExpenses.update();
        }

        // Update Budget vs Actual Chart
        if (this.charts.budgetActual && data.quarterlyBudget) {
            const { labels, budget, actual } = data.quarterlyBudget;
            this.charts.budgetActual.data.labels = labels;
            this.charts.budgetActual.data.datasets[0].data = budget;
            this.charts.budgetActual.data.datasets[1].data = actual;
            this.charts.budgetActual.update();
        }

        // Update AR Aging Chart
        if (this.charts.arAging && data.arAging) {
            this.charts.arAging.data.datasets[0].data = data.arAging;
            this.charts.arAging.update();
        }

        // Update AP Aging Chart
        if (this.charts.apAging && data.apAging) {
            this.charts.apAging.data.datasets[0].data = data.apAging;
            this.charts.apAging.update();
        }
    }

    async calculatePayrollTotal() {
        const currentDate = new Date();
        const employees = await this.api.read('employees');
        return employees.reduce((total, emp) => total + (emp.salary || 0) + (emp.benefits || 0), 0);
    }

    getStockStatusClass(status) {
        switch (status.toLowerCase()) {
            case 'critical': return 'danger';
            case 'low': return 'warning';
            case 'adequate': return 'success';
            default: return 'secondary';
        }
    }
}
