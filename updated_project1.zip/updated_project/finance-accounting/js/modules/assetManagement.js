// Asset Management Module
class AssetManagement {
    constructor() {
        this.setupAssetSection();
        this.loadAssetData();
        
        // Subscribe to data refresh events
        EventBus.subscribe('dataRefresh', () => this.loadAssetData());
    }

    setupAssetSection() {
        const assetSection = document.createElement('div');
        assetSection.id = 'assets';
        assetSection.className = 'section';
        assetSection.innerHTML = `
            <h2>Asset Management</h2>
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Asset Summary</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <p>Total Assets: <span id="total-assets-value">$0</span></p>
                                    <p>Total Depreciation: <span id="total-depreciation">$0</span></p>
                                </div>
                                <div class="col-md-6">
                                    <p>Net Book Value: <span id="net-book-value">$0</span></p>
                                    <p>Asset Count: <span id="asset-count">0</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Asset Distribution</h5>
                            <canvas id="asset-distribution-chart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Asset Register</h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Asset ID</th>
                                            <th>Name</th>
                                            <th>Purchase Value</th>
                                            <th>Current Value</th>
                                            <th>Depreciation</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody id="asset-register">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.querySelector('.container-fluid').appendChild(assetSection);
    }

    loadAssetData() {
        const assets = db.assets;
        
        // Update summary
        const totalAssetsValue = assets.reduce((sum, asset) => sum + asset.purchaseValue, 0);
        const totalDepreciation = assets.reduce((sum, asset) => sum + asset.depreciation, 0);
        const netBookValue = assets.reduce((sum, asset) => sum + asset.currentValue, 0);

        document.getElementById('total-assets-value').textContent = this.formatCurrency(totalAssetsValue);
        document.getElementById('total-depreciation').textContent = this.formatCurrency(totalDepreciation);
        document.getElementById('net-book-value').textContent = this.formatCurrency(netBookValue);
        document.getElementById('asset-count').textContent = assets.length;

        // Update asset register
        this.updateAssetRegister(assets);
        
        // Update distribution chart
        this.updateAssetDistributionChart(assets);
    }

    updateAssetRegister(assets) {
        const tbody = document.getElementById('asset-register');
        tbody.innerHTML = assets.map(asset => {
            const depreciationPercent = (asset.depreciation / asset.purchaseValue) * 100;
            let status;
            if (depreciationPercent > 75) status = '<span class="badge bg-danger">Replace Soon</span>';
            else if (depreciationPercent > 50) status = '<span class="badge bg-warning">Aging</span>';
            else status = '<span class="badge bg-success">Good</span>';

            return `
                <tr>
                    <td>${asset.id}</td>
                    <td>${asset.name}</td>
                    <td>${this.formatCurrency(asset.purchaseValue)}</td>
                    <td>${this.formatCurrency(asset.currentValue)}</td>
                    <td>${this.formatCurrency(asset.depreciation)}</td>
                    <td>${status}</td>
                </tr>
            `;
        }).join('');
    }

    updateAssetDistributionChart(assets) {
        const ctx = document.getElementById('asset-distribution-chart').getContext('2d');
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: assets.map(asset => asset.name),
                datasets: [{
                    data: assets.map(asset => asset.currentValue),
                    backgroundColor: [
                        '#007bff',
                        '#28a745',
                        '#dc3545',
                        '#ffc107',
                        '#17a2b8'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }
}
