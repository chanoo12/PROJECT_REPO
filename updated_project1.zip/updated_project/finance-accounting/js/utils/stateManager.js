// State management utility for handling application state
export class StateManager {
    constructor() {
        this.state = {
            inventory: [],
            transactions: [],
            accounts: [],
            employees: [],
            assets: [],
            budgets: [],
            taxes: [],
            stockMovements: []
        };
        this.subscribers = new Map();
    }

    // Get current state or subset of state
    getState(path = null) {
        if (!path) return { ...this.state };
        return path.split('.').reduce((obj, key) => obj?.[key], this.state);
    }

    // Update state and notify subscribers
    setState(updates, path = null) {
        if (path) {
            const keys = path.split('.');
            const lastKey = keys.pop();
            const target = keys.reduce((obj, key) => obj[key], this.state);
            target[lastKey] = updates;
        } else {
            this.state = { ...this.state, ...updates };
        }
        this.notifySubscribers(path || '*', this.state);
    }

    // Subscribe to state changes
    subscribe(path, callback) {
        if (!this.subscribers.has(path)) {
            this.subscribers.set(path, new Set());
        }
        this.subscribers.get(path).add(callback);

        // Return unsubscribe function
        return () => this.subscribers.get(path).delete(callback);
    }

    // Notify subscribers of state changes
    notifySubscribers(path, state) {
        // Notify specific path subscribers
        if (this.subscribers.has(path)) {
            this.subscribers.get(path).forEach(callback => callback(state));
        }

        // Notify wildcard subscribers
        if (path !== '*' && this.subscribers.has('*')) {
            this.subscribers.get('*').forEach(callback => callback(state));
        }
    }

    // Reset state to initial values
    reset() {
        this.state = {
            inventory: [],
            transactions: [],
            accounts: [],
            employees: [],
            assets: [],
            budgets: [],
            taxes: [],
            stockMovements: []
        };
        this.notifySubscribers('*', this.state);
    }
}

// Create and export singleton instance
export const stateManager = new StateManager();
