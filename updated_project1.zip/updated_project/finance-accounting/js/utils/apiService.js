// API service for handling data operations
import { validateData } from './validation.js';

class ApiService {
    constructor() {
        // Backend API endpoints
        this.baseUrl = '/api';  // Replace with your actual API base URL
        this.endpoints = {
            inventory: '/inventory',
            transactions: '/transactions',
            accounts: '/accounts',
            employees: '/employees',
            assets: '/assets',
            budgets: '/budgets',
            taxes: '/taxes',
            stockMovements: '/stock-movements'
        };
    }

    // Generic CRUD operations
    async create(collection, data) {
        try {
            const response = await fetch(`${this.baseUrl}${this.endpoints[collection]}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error(`Error creating ${collection}:`, error);
            throw error;
        }
    }

    async read(collection, id = null) {
        try {
            const url = id 
                ? `${this.baseUrl}${this.endpoints[collection]}/${id}`
                : `${this.baseUrl}${this.endpoints[collection]}`;
                
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error(`Error reading ${collection}:`, error);
            throw error;
        }
    }

    async update(collection, id, updates) {
        try {
            const response = await fetch(`${this.baseUrl}${this.endpoints[collection]}/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(updates)
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error(`Error updating ${collection}:`, error);
            throw error;
        }
    }

    async delete(collection, id) {
        try {
            const response = await fetch(`${this.baseUrl}${this.endpoints[collection]}/${id}`, {
                method: 'DELETE'
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return true;
        } catch (error) {
            console.error(`Error deleting from ${collection}:`, error);
            throw error;
        }
    }

    // Specialized queries
    async getInventoryValue() {
        const inventory = await this.read('inventory');
        return inventory.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0);
    }

    async getAccountsReceivable() {
        const transactions = await this.read('transactions');
        return transactions
            .filter(t => t.type === 'receivable' && t.status !== 'paid')
            .reduce((sum, t) => sum + t.amount, 0);
    }

    async getAccountsPayable() {
        const transactions = await this.read('transactions');
        return transactions
            .filter(t => t.type === 'payable' && t.status !== 'paid')
            .reduce((sum, t) => sum + t.amount, 0);
    }

    async getLowStockItems(threshold) {
        const inventory = await this.read('inventory');
        return inventory.filter(item => item.quantity <= (item.minimumStock || threshold));
    }

    // Financial Data queries
    async getMonthlyFinancials() {
        try {
            const response = await fetch(`${this.baseUrl}/reports/monthly-financials`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching monthly financials:', error);
            throw error;
        }
    }

    async getQuarterlyBudget() {
        try {
            const response = await fetch(`${this.baseUrl}/reports/quarterly-budget`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching quarterly budget:', error);
            throw error;
        }
    }

    async getARAgingData() {
        try {
            const response = await fetch(`${this.baseUrl}/reports/ar-aging`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching AR aging data:', error);
            throw error;
        }
    }

    async getAPAgingData() {
        try {
            const response = await fetch(`${this.baseUrl}/reports/ap-aging`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching AP aging data:', error);
            throw error;
        }
    }
}

// Create and export singleton instance
export const apiService = new ApiService();
