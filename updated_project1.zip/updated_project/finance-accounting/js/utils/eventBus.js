// Event Bus for inter-module communication
class EventBus {
    constructor() {
        this.events = new Map();
    }

    // Subscribe to an event
    subscribe(eventName, callback) {
        if (!this.events.has(eventName)) {
            this.events.set(eventName, new Set());
        }
        this.events.get(eventName).add(callback);
        return () => this.unsubscribe(eventName, callback);
    }

    // Unsubscribe from an event
    unsubscribe(eventName, callback) {
        if (this.events.has(eventName)) {
            this.events.get(eventName).delete(callback);
        }
    }

    // Publish an event
    publish(eventName, data) {
        if (this.events.has(eventName)) {
            this.events.get(eventName).forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error(`Error in event handler for ${eventName}:`, error);
                }
            });
        }
    }
}

// Create a singleton instance
const eventBus = new EventBus();
export default eventBus;
