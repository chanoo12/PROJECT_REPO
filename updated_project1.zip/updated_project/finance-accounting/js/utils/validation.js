// Validation utility functions for data integrity
export const validators = {
    required: (value) => {
        return value !== null && value !== undefined && value !== '';
    },
    
    number: (value) => {
        return !isNaN(Number(value));
    },
    
    positive: (value) => {
        return Number(value) > 0;
    },
    
    date: (value) => {
        return !isNaN(Date.parse(value));
    },
    
    email: (value) => {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    }
};

export const validateData = (data, rules) => {
    const errors = {};
    
    for (const [field, fieldRules] of Object.entries(rules)) {
        for (const [rule, errorMessage] of Object.entries(fieldRules)) {
            if (validators[rule] && !validators[rule](data[field])) {
                if (!errors[field]) errors[field] = [];
                errors[field].push(errorMessage);
            }
        }
    }
    
    return {
        isValid: Object.keys(errors).length === 0,
        errors
    };
};

export const formatters = {
    currency: (amount) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    },
    
    date: (date) => {
        return new Date(date).toLocaleDateString();
    },
    
    number: (number, decimals = 2) => {
        return Number(number).toFixed(decimals);
    },
    
    percentage: (value, decimals = 1) => {
        return `${(value * 100).toFixed(decimals)}%`;
    }
};
