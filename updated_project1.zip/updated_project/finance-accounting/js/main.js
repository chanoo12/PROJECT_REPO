// Main Application Logic
import { apiService } from './utils/apiService.js';
import { eventBus } from './utils/eventBus.js';
import { stateManager } from './utils/stateManager.js';

class App {
    constructor() {
        this.modules = new Map();
        this.initializeApp();
    }

    async initializeApp() {
        try {
            await this.loadData();
            await this.initializeModules();
            this.setupEventListeners();
            this.startAutoRefresh();
            
            // Notify all modules that app is ready
            eventBus.publish('appReady', null);
        } catch (error) {
            console.error('Error initializing app:', error);
            eventBus.publish('error', { message: 'Failed to initialize application' });
        }
    }

    async loadData() {
        try {
            await apiService.loadFromLocalStorage();
            
            // Pre-fetch commonly needed data
            await Promise.all([
                apiService.read('transactions'),
                apiService.read('inventory'),
                apiService.read('accounts')
            ]);
            
            eventBus.publish('dataLoaded', null);
        } catch (error) {
            console.error('Error loading data:', error);
            throw error;
        }
    }

    async initializeModules() {
        const currentPage = this.getCurrentPage();
        const modulePromises = [];

        // Always load core modules
        const coreModules = ['dashboard', 'generalLedger'];
        
        // Add current page module if not in core modules
        if (!coreModules.includes(currentPage)) {
            coreModules.push(currentPage);
        }
        
        // Load all required modules in parallel
        for (const moduleName of coreModules) {
            modulePromises.push(
                import(`./modules/${moduleName}.js`)
                    .then(module => {
                        const ModuleClass = module.default;
                        this.modules.set(moduleName, new ModuleClass(apiService, eventBus));
                        eventBus.publish('moduleLoaded', { module: moduleName });
                    })
                    .catch(error => {
                        console.error(`Error loading module ${moduleName}:`, error);
                        eventBus.publish('error', { 
                            message: `Failed to load ${moduleName} module` 
                        });
                    })
            );
        }

        await Promise.all(modulePromises);
    }

    setupEventListeners() {
        // Save data before unloading
        window.addEventListener('beforeunload', () => {
            apiService.saveToLocalStorage();
        });

        // Handle navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', this.handleNavigation.bind(this));
        });

        // Setup event handlers for notifications and errors
        this.setupNotifications();
    }

    setupNotifications() {
        eventBus.subscribe('error', this.showError.bind(this));
        eventBus.subscribe('notification', this.showNotification.bind(this));
    }

    getCurrentPage() {
        const path = window.location.pathname;
        if (path.endsWith('index.html') || path.endsWith('/')) {
            return 'dashboard';
        }
        return path.split('/').pop().replace('.html', '').replace(/-/g, '');
    }

    handleNavigation(event) {
        const link = event.currentTarget;
        
        // Update active states
        document.querySelectorAll('.nav-link').forEach(navLink => 
            navLink.classList.remove('active'));
        link.classList.add('active');
    }

    showError(error) {
        console.error('Application Error:', error);
        // TODO: Implement error UI (e.g., toast notification)
        this.showToast('error', error.message);
    }

    showNotification(notification) {
        console.log('Notification:', notification);
        // TODO: Implement notification UI
        this.showToast(notification.type || 'info', notification.message);
    }

    showToast(type, message) {
        // Basic toast notification implementation
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        
        const container = document.getElementById('toast-container') || 
            this.createToastContainer();
        
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 5000);
    }

    createToastContainer() {
        const container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
        `;
        document.body.appendChild(container);
        return container;
    }

    startAutoRefresh() {
        // Refresh data every 5 minutes
        setInterval(() => {
            eventBus.publish('dataRefresh', null);
        }, 300000);
    }
}

// Initialize the application when the DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.app = new App();
});
