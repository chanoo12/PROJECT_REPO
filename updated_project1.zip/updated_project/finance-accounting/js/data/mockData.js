// Mock Database

const mockData = {
    // General Ledger Data
    GeneralLedger: {
        accounts: [
            { code: '1000', name: 'Assets', type: 'Asset', balance: 0 },
            { code: '1100', name: 'Cash', type: 'Asset', parent: '1000', balance: 150000 },
            { code: '1200', name: 'Accounts Receivable', type: 'Asset', parent: '1000', balance: 75000 },
            { code: '1300', name: 'Inventory', type: 'Asset', parent: '1000', balance: 125000 },
            
            { code: '2000', name: 'Liabilities', type: 'Liability', balance: 0 },
            { code: '2100', name: 'Accounts Payable', type: 'Liability', parent: '2000', balance: 45000 },
            { code: '2200', name: 'Loans Payable', type: 'Liability', parent: '2000', balance: 200000 },
            
            { code: '3000', name: 'Equity', type: 'Equity', balance: 0 },
            { code: '3100', name: 'Common Stock', type: 'Equity', parent: '3000', balance: 100000 },
            { code: '3200', name: 'Retained Earnings', type: 'Equity', parent: '3000', balance: 5000 },
            
            { code: '4000', name: 'Revenue', type: 'Revenue', balance: 0 },
            { code: '4100', name: 'Sales Revenue', type: 'Revenue', parent: '4000', balance: 300000 },
            { code: '4200', name: 'Service Revenue', type: 'Revenue', parent: '4000', balance: 150000 },
            
            { code: '5000', name: 'Expenses', type: 'Expense', balance: 0 },
            { code: '5100', name: 'Salary Expense', type: 'Expense', parent: '5000', balance: 180000 },
            { code: '5200', name: 'Rent Expense', type: 'Expense', parent: '5000', balance: 24000 }
        ],

        // Mock AR/AP data
        receivables: [
            {
                id: 'INV-001',
                customer: 'ABC Corp',
                date: '2025-07-15',
                dueDate: '2025-08-14',
                amount: 15000,
                balance: 15000,
                status: 'Outstanding',
                terms: 'Net 30',
                reference: 'SO-001'
            },
            {
                id: 'INV-002',
                customer: 'XYZ Ltd',
                date: '2025-07-01',
                dueDate: '2025-07-31',
                amount: 25000,
                balance: 25000,
                status: 'Overdue',
                terms: 'Net 30',
                reference: 'SO-002'
            },
            {
                id: 'INV-003',
                customer: 'Tech Solutions',
                date: '2025-08-01',
                dueDate: '2025-08-31',
                amount: 8500,
                balance: 3500,
                status: 'Partial',
                terms: 'Net 30',
                reference: 'SO-003'
            }
        ],

        payables: [
            {
                id: 'BILL-001',
                vendor: 'Supplier A',
                date: '2025-07-20',
                dueDate: '2025-08-19',
                amount: 12000,
                balance: 12000,
                status: 'Pending',
                terms: 'Net 30',
                reference: 'PO-001'
            },
            {
                id: 'BILL-002',
                vendor: 'Supplier B',
                date: '2025-08-01',
                dueDate: '2025-08-31',
                amount: 8000,
                balance: 8000,
                status: 'Pending',
                terms: 'Net 30',
                reference: 'PO-002'
            }
        ],

        journal_entries: [
            {
                id: 'JE001',
                date: '2024-01-15',
                description: 'Sale of goods',
                entries: [
                    { account: '1100', debit: 5000, credit: 0 },
                    { account: '4100', debit: 0, credit: 5000 }
                ],
                status: 'Posted',
                createdBy: 'John Doe'
            },
            {
                id: 'JE002',
                date: '2024-01-16',
                description: 'Rent payment',
                entries: [
                    { account: '5200', debit: 2000, credit: 0 },
                    { account: '1100', debit: 0, credit: 2000 }
                ],
                status: 'Posted',
                createdBy: 'Jane Smith'
            }
        ]
    },

    // CRM Data
    CRM: {
        sales_orders: [
            { 
                id: 1, 
                customer: "ABC Corp", 
                amount: 15000, 
                date: "2024-01-15", 
                status: "unpaid",
                items: [
                    { itemId: 1, quantity: 10, price: 1000 },
                    { itemId: 2, quantity: 5, price: 1000 }
                ],
                taxable: true
            },
            { 
                id: 2, 
                customer: "XYZ Ltd", 
                amount: 25000, 
                date: "2024-01-20", 
                status: "paid",
                items: [
                    { itemId: 3, quantity: 20, price: 1250 }
                ],
                taxable: true
            }
        ]
    },

    // Inventory Data
    Inventory: {
        items: [
            { 
                id: 1, 
                name: "Raw Material A", 
                quantity: 100, 
                value: 5000, 
                type: "raw_material",
                location: "Warehouse A"
            },
            { 
                id: 2, 
                name: "Machine X", 
                quantity: 1, 
                value: 50000, 
                type: "fixed_asset",
                location: "Production Floor",
                depreciation: {
                    method: "straight-line",
                    rate: 0.1,
                    accumulated: 5000
                }
            }
        ],
        
        movements: [
            { 
                id: 'MOV001',
                date: '2024-01-15',
                type: 'inbound',
                value: 5000,
                description: 'Stock Receipt'
            },
            { 
                id: 'MOV002',
                date: '2024-01-16',
                type: 'outbound',
                value: 3000,
                description: 'Stock Issue'
            }
        ]
    }
};

// Database Query Functions
const db = {
    // General Ledger Queries
    getChartOfAccounts: () => mockData.GeneralLedger.accounts,
    
    getJournalEntries: () => mockData.GeneralLedger.journal_entries,
    
    getAccountBalance: (accountCode) => {
        const account = mockData.GeneralLedger.accounts.find(a => a.code === accountCode);
        return account ? account.balance : 0;
    },

    getTotalAssets: () => {
        return mockData.GeneralLedger.accounts
            .filter(a => a.type === 'Asset' && !a.parent)
            .reduce((sum, account) => sum + account.balance, 0);
    },

    getTotalLiabilities: () => {
        return mockData.GeneralLedger.accounts
            .filter(a => a.type === 'Liability' && !a.parent)
            .reduce((sum, account) => sum + account.balance, 0);
    },

    // CRM Queries
    getSalesOrders: (filters = {}) => {
        let orders = mockData.CRM.sales_orders;
        if (filters.status) {
            orders = orders.filter(order => order.status === filters.status);
        }
        if (filters.dateFrom) {
            orders = orders.filter(order => new Date(order.date) >= new Date(filters.dateFrom));
        }
        return orders;
    },

    getSalesTotal: (dateRange = {}) => {
        const orders = db.getSalesOrders(dateRange);
        return orders.reduce((sum, order) => sum + order.amount, 0);
    },

    // Inventory Queries
    getInventoryItems: () => mockData.Inventory.items,

    getInventoryValue: () => {
        return mockData.Inventory.items.reduce((sum, item) => sum + item.value, 0);
    },

    getInventoryMovements: () => mockData.Inventory.movements,

    // Utility Functions
    randomDate: (start, end) => {
        const startTime = start.getTime();
        const endTime = end.getTime();
        const randomTime = startTime + Math.random() * (endTime - startTime);
        const date = new Date(randomTime);
        return date.toISOString().split('T')[0];
    }
};

// Financial Data
const financialData = {
    monthlyFinancials: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        revenue: [45000, 52000, 49000, 58000, 55000, 60000],
        expenses: [38000, 40000, 42000, 45000, 43000, 47000]
    },
    quarterlyBudget: {
        labels: ['Q1', 'Q2', 'Q3', 'Q4'],
        budget: [150000, 165000, 170000, 180000],
        actual: [155000, 168000, 165000, 0]  // Q4 not yet complete
    },
    arAging: [50000, 15000, 8000, 2000, 0],  // Current, 1-30, 31-60, 61-90, 90+
    apAging: [30000, 10000, 5000, 0, 0]      // Current, 1-30, 31-60, 61-90, 90+
};

// Extend db with new methods
Object.assign(db, {
    getMonthlyFinancials: () => financialData.monthlyFinancials,
    getQuarterlyBudget: () => financialData.quarterlyBudget,
    getARAgingData: () => financialData.arAging,
    getAPAgingData: () => financialData.apAging
});

// Make database accessible globally
window.db = db;
