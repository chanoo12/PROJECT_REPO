const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');

// Create Express app
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan('dev')); // Logging

// Serve static files
app.use(express.static(path.join(__dirname)));

// Import route handlers
const inventoryRoutes = require('./routes/inventory');
const transactionsRoutes = require('./routes/transactions');
const accountsRoutes = require('./routes/accounts');
const employeesRoutes = require('./routes/employees');
const assetsRoutes = require('./routes/assets');
const budgetsRoutes = require('./routes/budgets');
const taxesRoutes = require('./routes/taxes');
const stockMovementsRoutes = require('./routes/stockMovements');
const reportsRoutes = require('./routes/reports');

// Routes
app.use('/api/inventory', inventoryRoutes);
app.use('/api/transactions', transactionsRoutes);
app.use('/api/accounts', accountsRoutes);
app.use('/api/employees', employeesRoutes);
app.use('/api/assets', assetsRoutes);
app.use('/api/budgets', budgetsRoutes);
app.use('/api/taxes', taxesRoutes);
app.use('/api/stock-movements', stockMovementsRoutes);
app.use('/api/reports', reportsRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message
  });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
