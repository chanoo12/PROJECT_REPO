
import { db, fmt, notify } from './db.js';

export function initBudgeting(){
  const el = document.getElementById('content');
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Budgeting</h2>
        <button id="btn-add-budget" class="btn btn-primary">New Budget</button>
      </div>
      <div class="card">
        <table class="table">
          <thead><tr><th>Year</th><th>Dept/Project</th><th>Category</th><th>Amount</th><th>Actual</th><th>Variance</th><th>Actions</th></tr></thead>
          <tbody id="budget-rows"></tbody>
        </table>
      </div>
    </section>
  `;
  render();

  document.getElementById('btn-add-budget').onclick = () => {
    const year = parseInt(prompt('Year', new Date().getFullYear())||new Date().getFullYear(),10);
    const scope = prompt('Dept/Project','Ops');
    const category = prompt('Category','OPEX');
    const amount = parseFloat(prompt('Amount','100000')||'0');
    const row = {year, scope, category, amount, actual:0};
    db.set('budgets', [row, ...db.get('budgets')]);
    notify(`Budget for ${scope} added.`,'info');
    render();
  };

  function render(){
    const body = document.getElementById('budget-rows');
    body.innerHTML = (db.get('budgets')||[]).map(b=>{
      const variance = (b.amount||0) - (b.actual||0);
      return `<tr>
        <td>${b.year}</td><td>${b.scope}</td><td>${b.category}</td>
        <td>${fmt.money(b.amount)}</td><td>${fmt.money(b.actual||0)}</td><td>${fmt.money(variance)}</td>
        <td>
          <button onclick="editBudget(${b.year},'${b.scope}')" class="btn">Edit</button>
          <button onclick="deleteBudget(${b.year},'${b.scope}')" class="btn">Delete</button>
        </td>
      </tr>`;
    }).join('');

    window.editBudget = (year, scope) => {
      const budget = db.get('budgets').find(b => b.year === year && b.scope === scope);
      if (!budget) return;

      const newAmount = parseFloat(prompt('Budget Amount', budget.amount)||'0');
      const newCategory = prompt('Category', budget.category);
      
      if (!newAmount || !newCategory) return;

      const budgets = db.get('budgets').map(b => {
        if (b.year === year && b.scope === scope) {
          return {...b, amount: newAmount, category: newCategory};
        }
        return b;
      });

      db.set('budgets', budgets);
      notify(`Budget for ${scope} updated.`,'info');
      render();
    };

    window.deleteBudget = (year, scope) => {
      if (!confirm('Are you sure you want to delete this budget?')) return;
      
      const budgets = db.get('budgets').filter(b => !(b.year === year && b.scope === scope));
      db.set('budgets', budgets);
      notify(`Budget deleted.`,'info');
      render();
    };
  }
}
