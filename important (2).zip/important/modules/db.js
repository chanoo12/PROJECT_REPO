
const KEY = 'fa-suite';

const listeners = {};
export const bus = {
  on(evt, cb){ (listeners[evt] ||= []).push(cb); },
  emit(evt, data){ (listeners[evt]||[]).forEach(cb=>cb(data)); }
};

function load(){
  try{ return JSON.parse(localStorage.getItem(KEY)) || {meta:{vat:12, company:'Company', cash:0}}; }
  catch(e){ return {meta:{vat:12, company:'Company', cash:0}}; }
}
function save(data){ localStorage.setItem(KEY, JSON.stringify(data)); }
let data = load();

export function state(){ return data.meta; }

export const db = {
  get(path){ return data[path] || []; },
  set(path, val){ data[path] = val; save(data); bus.emit('change', {path}); },
  patch(path, partial){
    if(path==='meta'){ data.meta = {...data.meta, ...partial}; }
    else { data[path] = {...(data[path]||{}), ...partial}; }
    save(data); bus.emit('change', {path});
  },
  tx(fn){ fn(); save(data); bus.emit('change', {path:'*'}); }
};

export const fmt = {
  money(n){ return '₱'+(n||0).toLocaleString(undefined,{minimumFractionDigits:2, maximumFractionDigits:2}); },
  date(d){ return new Date(d).toISOString().slice(0,10); },
  uuid(){ return Math.random().toString(36).slice(2,10).toUpperCase(); }
};

// Notification helper
export function notify(text, type='info', ref=null){
  const entry = {id:fmt.uuid(), date: new Date().toISOString(), text, type, ref, read:false};
  const inbox = db.get('notifications'); db.set('notifications', [entry, ...inbox]);
  bus.emit('notif', entry);
}
