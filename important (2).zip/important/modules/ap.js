
import { db, fmt, notify, state } from './db.js';

export function initAP(){
  const el = document.getElementById('content');
  const out = (db.get('bills')||[]).filter(b=>b.status!=='Paid').reduce((s,b)=>s+b.amount,0);
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Accounts Payable</h2>
        <div class="hstack gap-1">
          <button id="btn-add-vendor" class="btn">Add Vendor</button>
          <button id="btn-add-bill" class="btn btn-primary">New Bill</button>
          <button id="btn-pay-bill" class="btn">Record Payment</button>
        </div>
      </div>
      <div class="grid grid-3">
        <div class="kpi"><div class="label">AP Outstanding</div><div class="value" id="ap-out">${fmt.money(out)}</div></div>
        <div class="kpi"><div class="label">Vendors</div><div class="value" id="ap-vendors">${(db.get('vendors')||[]).length}</div></div>
        <div class="kpi"><div class="label">Bills</div><div class="value" id="ap-bills">${(db.get('bills')||[]).length}</div></div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Bills</div></div>
        <table class="table">
          <thead><tr><th>Date</th><th>Vendor</th><th>Ref</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody id="ap-rows"></tbody>
        </table>
      </div>
    </section>
  `;
  render();

  document.getElementById('btn-add-vendor').onclick = () => {
    const id = 'VEND-'+fmt.uuid();
    const name = prompt('Vendor name','New Vendor')||'Vendor';
    db.set('vendors', [...db.get('vendors'), {id, name}]);
    notify(`Vendor ${name} added.`,'info', id);
    initAP();
  };

  document.getElementById('btn-add-bill').onclick = () => {
    const vend = prompt('Vendor name', (db.get('vendors')[0]||{}).name||'Supply Co.');
    const amount = parseFloat(prompt('Bill amount','10000')||'0');
    const ref = 'BILL-'+fmt.uuid();
    const date = fmt.date(new Date());
    const bill = {date, vendor:vend, ref, amount, status:'Open'};
    db.set('bills', [bill, ...db.get('bills')]);
    // VAT input
    const vatRate = (state().vat||12)/100;
    const base = amount / (1+vatRate);
    const vat = amount - base;
    db.set('vatledger', [{date, type:'input', base, vat, ref}, ...db.get('vatledger')]);
    // GL: DR Expense (5100), DR VAT Payable (input as negative liability)?, CR AP (2000)
    const je1 = {date, ref, account:'5100', debit:base, credit:0, memo:`Bill ${vend}`};
    const je2 = {date, ref, account:'2100', debit:vat, credit:0, memo:'VAT Input'};
    const je3 = {date, ref, account:'2000', debit:0, credit:amount, memo:'AP'};
    db.set('journals', [je1, je2, je3, ...db.get('journals')]);
    notify(`Bill ${ref} created (${fmt.money(amount)}).`,'info', ref);
    initAP();
  };

  document.getElementById('btn-pay-bill').onclick = () => {
    const openBills = (db.get('bills')||[]).filter(b=>b.status!=='Paid');
    if(openBills.length===0){ alert('No open bills.'); return; }
    const ref = prompt('Bill ref to pay', openBills[0].ref);
    const bill = (db.get('bills')||[]).find(b=>b.ref===ref);
    if(!bill){ alert('Bill not found'); return; }
    bill.status = 'Paid'; db.set('bills', [...db.get('bills')]);
    // GL: DR AP 2000, CR Cash 1000
    const date = fmt.date(new Date());
    const je1 = {date, ref:'PAY-'+ref, account:'2000', debit:bill.amount, credit:0, memo:'Pay Bill'};
    const je2 = {date, ref:'PAY-'+ref, account:'1000', debit:0, credit:bill.amount, memo:'Cash Out'};
    db.set('journals', [je1, je2, ...db.get('journals')]);
    const meta = db.get('meta'); meta.cash -= bill.amount; db.set('meta', meta);
    notify(`Bill ${ref} paid.`, 'ok', ref);
    initAP();
  };

  function render(){
    const body = document.getElementById('ap-rows');
    body.innerHTML = (db.get('bills')||[]).map(b=>`<tr>
      <td>${b.date}</td><td>${b.vendor}</td><td>${b.ref}</td><td>${fmt.money(b.amount)}</td><td>${b.status}</td>
      <td>
        ${b.status !== 'Paid' ? `
          <button onclick="editBill('${b.ref}')" class="btn">Edit</button>
          <button onclick="deleteBill('${b.ref}')" class="btn">Delete</button>
        ` : ''}
      </td>
    </tr>`).join('');

    window.editBill = (ref) => {
      const bill = db.get('bills').find(b => b.ref === ref);
      if (!bill || bill.status === 'Paid') return;

      const vend = prompt('Vendor name', bill.vendor);
      const amount = parseFloat(prompt('Bill amount', bill.amount)||'0');
      const date = prompt('Date', bill.date);
      
      if (!vend || !amount || !date) return;

      const bills = db.get('bills').map(b => {
        if (b.ref === ref) {
          return {...b, vendor: vend, amount, date};
        }
        return b;
      });

      db.set('bills', bills);
      notify(`Bill ${ref} updated.`,'info', ref);
      initAP();
    };

    window.deleteBill = (ref) => {
      if (!confirm('Are you sure you want to delete this bill?')) return;
      
      const bill = db.get('bills').find(b => b.ref === ref);
      if (bill.status === 'Paid') {
        alert('Cannot delete a paid bill.');
        return;
      }

      const bills = db.get('bills').filter(b => b.ref !== ref);
      db.set('bills', bills);
      notify(`Bill deleted.`,'info', ref);
      initAP();
    };
  }
}
