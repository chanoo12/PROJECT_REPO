
import { db, bus } from './db.js';

export function initAuth(){
  const loginEl = document.getElementById('login-screen');
  const appEl = document.getElementById('app');
  function showApp(){ loginEl.classList.add('hidden'); appEl.classList.remove('hidden'); }
  function showLogin(){ appEl.classList.add('hidden'); loginEl.classList.remove('hidden'); }

  const session = JSON.parse(sessionStorage.getItem('fa-session')||'null');
  if(session?.user==='admin'){ showApp(); }

  document.getElementById('login-form').addEventListener('submit', (e)=>{
    e.preventDefault();
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const errorMsg = document.getElementById('login-error');
    const u = usernameInput.value.trim();
    const p = passwordInput.value.trim();

    // Reset previous error states
    errorMsg.textContent = '';
    usernameInput.classList.remove('error');
    passwordInput.classList.remove('error');

    // Validate inputs
    if (!u) {
      usernameInput.classList.add('error');
      errorMsg.textContent = 'Username is required';
      return;
    }
    if (!p) {
      passwordInput.classList.add('error');
      errorMsg.textContent = 'Password is required';
      return;
    }

    if(u==='admin' && p==='admin'){
      sessionStorage.setItem('fa-session', JSON.stringify({user:'admin', time: Date.now()}));
      bus.emit('notif', {type:'ok', text:'Welcome admin!'});
      showApp();
    } else {
      usernameInput.classList.add('error');
      passwordInput.classList.add('error');
      errorMsg.textContent = 'Invalid username or password';
      bus.emit('notif', {type:'bad', text:'Login failed. Please check your credentials.'});
      // Clear password field for security
      passwordInput.value = '';
    }
  });

  document.getElementById('logout').addEventListener('click', ()=>{
    sessionStorage.removeItem('fa-session');
    bus.emit('notif', {type:'info', text:'Logged out.'});
    showLogin();
  });
}
