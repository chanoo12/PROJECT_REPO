
import { db, fmt, notify } from './db.js';

export function initAssets(){
  const el = document.getElementById('content');
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Asset Management</h2>
        <div class="hstack gap-1">
          <button id="btn-add-asset" class="btn">Add Asset</button>
          <button id="btn-run-depr" class="btn btn-primary">Run Depreciation (Monthly)</button>
        </div>
      </div>
      <div class="card">
        <table class="table">
          <thead><tr><th>Code</th><th>Name</th><th>Cost</th><th>Life (mos)</th><th>Accum Dep</th><th>Net Book</th><th>Start</th><th>Actions</th></tr></thead>
          <tbody id="asset-rows"></tbody>
        </table>
      </div>
    </section>
  `;
  render();

  document.getElementById('btn-add-asset').onclick = () => {
    const code = 'FA-'+fmt.uuid();
    const name = prompt('Asset name','New Asset');
    const cost = parseFloat(prompt('Cost','50000')||'0');
    const life = parseInt(prompt('Useful life (months)','36')||'36',10);
    const start = fmt.date(new Date());
    const asset = {code, name, cost, life, accum:0, start};
    db.set('assets', [asset, ...db.get('assets')]);
    notify(`Asset ${name} added.`,'info', code);
    render();
  };

  document.getElementById('btn-run-depr').onclick = () => {
    const assets = db.get('assets').map(a=>{
      const monthly = a.cost / a.life;
      a.accum = Math.min(a.cost, (a.accum||0)+monthly);
      return a;
    });
    db.set('assets', assets);
    // Post to GL
    const ref = 'DEP-'+fmt.uuid();
    const amount = assets.reduce((s,a)=>s + (a.cost/a.life),0);
    if(amount>0){
      const je1 = {date: fmt.date(new Date()), ref, account:'5300', debit:amount, credit:0, memo:'Monthly Depreciation'};
      const je2 = {date: fmt.date(new Date()), ref, account:'1500', debit:0, credit:amount, memo:'Accumulated Depreciation'};
      db.set('journals', [je1, je2, ...db.get('journals')]);
    }
    notify(`Depreciation run posted (${fmt.money(amount)}).`,'ok', ref);
    render();
  };

  function render(){
    const body = document.getElementById('asset-rows');
    body.innerHTML = (db.get('assets')||[]).map(a=>`<tr>
      <td>${a.code}</td><td>${a.name}</td><td>${fmt.money(a.cost)}</td><td>${a.life}</td>
      <td>${fmt.money(a.accum||0)}</td><td>${fmt.money(a.cost-(a.accum||0))}</td><td>${a.start}</td>
      <td>
        <button onclick="editAsset('${a.code}')" class="btn">Edit</button>
        <button onclick="deleteAsset('${a.code}')" class="btn">Delete</button>
      </td>
    </tr>`).join('');

    window.editAsset = (code) => {
      const asset = db.get('assets').find(a => a.code === code);
      if (!asset) return;

      const name = prompt('Asset name', asset.name);
      const cost = parseFloat(prompt('Cost', asset.cost)||'0');
      const life = parseInt(prompt('Useful life (months)', asset.life)||'36',10);
      
      if (!name) return;

      const assets = db.get('assets').map(a => {
        if (a.code === code) {
          return {...a, name, cost, life};
        }
        return a;
      });

      db.set('assets', assets);
      notify(`Asset ${name} updated.`,'info', code);
      render();
    };

    window.deleteAsset = (code) => {
      if (!confirm('Are you sure you want to delete this asset?')) return;
      
      const assets = db.get('assets').filter(a => a.code !== code);
      db.set('assets', assets);
      notify(`Asset deleted.`,'info', code);
      render();
    };
  }
}
