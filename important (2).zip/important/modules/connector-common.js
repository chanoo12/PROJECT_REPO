import { db, bus, notify } from './db.js';

// Common connector utilities for managing connected department data
export function clearConnectorData(connectorType) {
    // Show modern confirmation dialog with details
    const messages = {
        crm: 'This will delete all CRM data including customer records, sales data, and related transactions.',
        inventory: 'This will delete all inventory items, stock movements, and related transactions.',
        hr: 'This will delete all HR records, employee data, payroll entries, and related transactions.',
        projects: 'This will delete all project data, expenses, and related transactions.'
    };

    const confirmDelete = confirm(`Warning: ${messages[connectorType]}\n\nThis action cannot be undone. Continue?`);
    if (!confirmDelete) return;

    try {
        db.tx(() => {
            // Common transaction references to clean up
            const refPrefix = connectorType.toUpperCase();
            
            // Clear module specific data
            switch(connectorType) {
                case 'crm':
                    // Clear CRM related data
                    const customers = db.get('customers') || [];
                    if (customers.length) {
                        db.set('customers', []);
                        db.set('invoices', (db.get('invoices') || [])
                            .filter(inv => !inv.ref.startsWith('INV-')));
                    }
                    break;
                
                case 'inventory':
                    // Clear Inventory related data
                    db.set('items', []);
                    db.set('movements', (db.get('movements') || [])
                        .filter(mov => !mov.ref.startsWith('STK-')));
                    break;
                
                case 'hr':
                    // Clear HR related data
                    db.set('employees', []);
                    db.set('payruns', (db.get('payruns') || [])
                        .filter(run => !run.ref.startsWith('PAY-')));
                    break;
                
                case 'projects':
                    // Clear Project related data
                    db.set('projects', []);
                    db.set('project_expenses', []);
                    break;
            }

            // Clean up related transactions
            db.set('journals', (db.get('journals') || [])
                .filter(j => !j.ref?.startsWith(refPrefix)));

            // Clean up tax entries if applicable
            if (connectorType === 'crm' || connectorType === 'inventory') {
                db.set('vatledger', (db.get('vatledger') || [])
                    .filter(v => !v.ref?.startsWith(refPrefix)));
            }
        });

        // Notify success with module-specific message
        notify(`Successfully cleared all ${connectorType.toUpperCase()} data and related transactions.`, 'info');
        
        // Trigger UI refresh
        bus.emit('change', { path: '*' });
        
    } catch (error) {
        console.error('Error clearing connector data:', error);
        notify(`Failed to clear ${connectorType.toUpperCase()} data. Please try again.`, 'error');
    }
}

// Helper function to generate reference numbers for different modules
export function generateRef(type, prefix = '') {
    const refMap = {
        crm: 'INV',
        inventory: 'STK',
        hr: 'PAY',
        projects: 'PRJ'
    };
    
    const basePrefix = refMap[type] || type.toUpperCase();
    const uniqueId = Math.random().toString(36).slice(2, 8).toUpperCase();
    return `${prefix || basePrefix}-${uniqueId}`;
}

// Helper function to validate and sanitize imported data
export function validateImportedData(data, type) {
    if (!Array.isArray(data)) return [];
    
    const sanitized = data.filter(item => {
        if (!item || typeof item !== 'object') return false;
        
        // Basic validation based on module type
        switch(type) {
            case 'crm':
                return item.customer && item.amount;
            case 'inventory':
                return item.sku && item.name;
            case 'hr':
                return item.name && item.rate;
            case 'projects':
                return item.name && item.status;
            default:
                return true;
        }
    });
    
    return sanitized;
}

// Helper function to format dates consistently across modules
export function formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toISOString().split('T')[0];
}