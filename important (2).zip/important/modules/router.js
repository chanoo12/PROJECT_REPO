
import { bus } from './db.js';

export function mountRouter(routes){
  const content = document.getElementById('content');
  const nav = document.getElementById('nav');
  const toggle = document.getElementById('toggle-sidebar');
  const sidebar = document.getElementById('sidebar');

  function render(route){
    // set active
    nav.querySelectorAll('.navlink').forEach(a => a.classList.remove('active'));
    const link = nav.querySelector(`[data-route="${route}"]`);
    if(link) link.classList.add('active');
    // call module
    const fn = routes[route] || routes['dashboard'];
    fn();
    window.location.hash = route;
  }

  // hash routing
  const initial = (location.hash||'#dashboard').replace('#','');
  render(initial);

  nav.querySelectorAll('.navlink').forEach(a => a.addEventListener('click', (e)=>{
    e.preventDefault();
    render(a.dataset.route);
  }));

  toggle.addEventListener('click', ()=>{
    sidebar.classList.toggle('show');
  });

  // Close sidebar when clicking outside on mobile
  document.addEventListener('click', (e) => {
    if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
      sidebar.classList.remove('show');
    }
  });

  // Close sidebar when clicking a link on mobile
  nav.addEventListener('click', () => {
    if (window.innerWidth <= 900) {
      sidebar.classList.remove('show');
    }
  });

  // expose
  window.navigate = render;
}
