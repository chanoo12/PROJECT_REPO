
import { bus, db, fmt, state } from './modules/db.js';
import { initAuth } from './modules/auth.js';
import { mountRouter } from './modules/router.js';
import { initUI } from './modules/ui.js';
import { initDashboard } from './modules/dashboard.js';
import { initGL } from './modules/gl.js';
import { initAssets } from './modules/assets.js';
import { initTax } from './modules/tax.js';
import { initAP } from './modules/ap.js';
import { initAR } from './modules/ar.js';
import { initBudgeting } from './modules/budgeting.js';
import { initPayroll } from './modules/payroll.js';
import { initStock } from './modules/stock.js';
import { initCRM } from './modules/crm.js';
import { initInventoryConnector } from './modules/inventory.js';
import { initHRConnector } from './modules/hr.js';
import { initProjects } from './modules/projects.js';

// Global search functionality
function initGlobalSearch() {
  const searchInput = document.getElementById('global-search');
  const searchResults = document.getElementById('search-results');
  if (!searchInput || !searchResults) {
    console.error('Search elements not found');
    return;
  }

  let searchTimeout;
  let currentResults = [];
  let selectedIndex = -1;

  // Navigation menu items for search
  const navItems = [
    { title: 'Dashboard', route: 'dashboard', icon: 'dashboard', type: 'nav' },
    { title: 'General Ledger', route: 'general-ledger', icon: 'book', type: 'nav' },
    { title: 'Asset Management', route: 'asset-management', icon: 'inventory_2', type: 'nav' },
    { title: 'Tax Management', route: 'tax-management', icon: 'receipt_long', type: 'nav' },
    { title: 'Accounts Payable', route: 'apayables', icon: 'payments', type: 'nav' },
    { title: 'Accounts Receivable', route: 'areceivable', icon: 'account_balance_wallet', type: 'nav' },
    { title: 'Budgeting', route: 'budgeting', icon: 'analytics', type: 'nav' },
    { title: 'Payroll', route: 'payroll', icon: 'credit_card', type: 'nav' },
    { title: 'Stock Movement', route: 'stock-movement', icon: 'local_shipping', type: 'nav' }
  ];


  // Navigation menu items for search
  const menuItems = [
    { title: 'Dashboard', route: 'dashboard', icon: 'dashboard', type: 'nav' },
    { title: 'General Ledger', route: 'general-ledger', icon: 'book', type: 'nav' },
    { title: 'Asset Management', route: 'asset-management', icon: 'inventory_2', type: 'nav' },
    { title: 'Tax Management', route: 'tax-management', icon: 'receipt_long', type: 'nav' },
    { title: 'Accounts Payable', route: 'apayables', icon: 'payments', type: 'nav' },
    { title: 'Accounts Receivable', route: 'areceivable', icon: 'account_balance_wallet', type: 'nav' },
    { title: 'Budgeting', route: 'budgeting', icon: 'analytics', type: 'nav' },
    { title: 'Payroll', route: 'payroll', icon: 'credit_card', type: 'nav' },
    { title: 'Stock Movement', route: 'stock-movement', icon: 'local_shipping', type: 'nav' },
    { title: 'CRM (Sales)', route: 'connector-crm', icon: 'groups', type: 'nav' },
    { title: 'Inventory', route: 'connector-inventory', icon: 'inventory', type: 'nav' },
    { title: 'HR', route: 'connector-hr', icon: 'people', type: 'nav' },
    { title: 'Project Management', route: 'connector-projects', icon: 'folder', type: 'nav' }
  ];

  // Search data from all modules
  function searchAllModules(query) {
    query = query.toLowerCase();
    const results = [];
    
    // Search in navigation menu
    navItems.forEach(item => {
      if (item.title.toLowerCase().includes(query)) {
        results.push({
          title: item.title,
          subtitle: 'Navigation Menu',
          module: 'NAV',
          icon: item.icon,
          route: item.route,
          type: 'nav'
        });
      }
    });

    // Search in General Ledger
    (db.get('journals') || []).forEach(entry => {
      if (entry.ref?.toLowerCase().includes(query) ||
          entry.memo?.toLowerCase().includes(query) ||
          entry.account?.toLowerCase().includes(query)) {
        results.push({
          title: entry.memo || 'Journal Entry',
          subtitle: `${entry.ref} - ${fmt.money(entry.debit || entry.credit)}`,
          module: 'GL',
          icon: 'book',
          route: 'general-ledger',
          data: entry,
          type: 'journal'
        });
      }
    });

    // Search in AR
    (db.get('invoices') || []).forEach(inv => {
      if (inv.ref?.toLowerCase().includes(query) ||
          inv.customer?.toLowerCase().includes(query)) {
        results.push({
          title: `Invoice - ${inv.customer}`,
          subtitle: `${inv.ref} - ${fmt.money(inv.amount)}`,
          module: 'AR',
          icon: 'receipt_long',
          route: 'areceivable',
          data: inv,
          type: 'invoice'
        });
      }
    });

    // Search in AP
    (db.get('bills') || []).forEach(bill => {
      if (bill.ref?.toLowerCase().includes(query) ||
          bill.vendor?.toLowerCase().includes(query)) {
        results.push({
          title: `Bill - ${bill.vendor}`,
          subtitle: `${bill.ref} - ${fmt.money(bill.amount)}`,
          module: 'AP',
          icon: 'description',
          route: 'apayables',
          data: bill,
          type: 'bill'
        });
      }
    });

    // Search in Inventory
    (db.get('items') || []).forEach(item => {
      if (item.sku?.toLowerCase().includes(query) ||
          item.name?.toLowerCase().includes(query)) {
        results.push({
          title: item.name,
          subtitle: `${item.sku} - ${item.onHand} units`,
          module: 'INV',
          icon: 'inventory_2',
          route: 'stock-movement',
          data: item,
          type: 'item'
        });
      }
    });

    // Search in Employees/Payroll
    (db.get('employees') || []).forEach(emp => {
      if (emp.name?.toLowerCase().includes(query) ||
          emp.id?.toLowerCase().includes(query)) {
        results.push({
          title: emp.name,
          subtitle: `${emp.id} - ${emp.dept}`,
          module: 'HR',
          icon: 'person',
          route: 'payroll',
          data: emp,
          type: 'employee'
        });
      }
    });

    // Search in Assets
    (db.get('assets') || []).forEach(asset => {
      if (asset.name?.toLowerCase().includes(query) ||
          asset.code?.toLowerCase().includes(query)) {
        results.push({
          title: asset.name,
          subtitle: `${asset.code} - ${fmt.money(asset.cost)}`,
          module: 'ASSET',
          icon: 'inventory_2',
          route: 'asset-management',
          data: asset,
          type: 'asset'
        });
      }
    });

    // Search in invoices
    (db.get('invoices')||[]).forEach(inv => {
      if (inv.ref.toLowerCase().includes(query) || 
          inv.customer.toLowerCase().includes(query)) {
        results.push({
          title: `Invoice - ${inv.customer}`,
          subtitle: `${inv.ref} - ${fmt.money(inv.amount)}`,
          module: 'AR',
          icon: 'receipt_long',
          route: 'areceivable',
          data: inv
        });
      }
    });

    // Search in bills
    (db.get('bills')||[]).forEach(bill => {
      if (bill.ref.toLowerCase().includes(query) || 
          bill.vendor.toLowerCase().includes(query)) {
        results.push({
          title: `Bill - ${bill.vendor}`,
          subtitle: `${bill.ref} - ${fmt.money(bill.amount)}`,
          module: 'AP',
          icon: 'description',
          route: 'apayables',
          data: bill
        });
      }
    });

    // Search in inventory
    (db.get('items')||[]).forEach(item => {
      if (item.sku.toLowerCase().includes(query) || 
          item.name.toLowerCase().includes(query)) {
        results.push({
          title: item.name,
          subtitle: `${item.sku} - ${item.onHand} units`,
          module: 'INV',
          icon: 'inventory_2',
          route: 'stock-movement',
          data: item,
          type: 'item'
        });
      }
    });

    // Search in transactions
    (db.get('journals')||[]).forEach(journal => {
      if (journal.memo?.toLowerCase().includes(query) || 
          journal.ref?.toLowerCase().includes(query) ||
          journal.account?.toLowerCase().includes(query)) {
        results.push({
          title: journal.memo || 'Journal Entry',
          subtitle: `${journal.ref} - ${fmt.money(journal.debit || journal.credit)}`,
          module: 'GL',
          icon: 'book',
          route: 'general-ledger',
          data: journal,
          type: 'transaction'
        });
      }
    });

    // Search in movements
    (db.get('movements')||[]).forEach(mov => {
      if (mov.ref?.toLowerCase().includes(query) || 
          mov.sku?.toLowerCase().includes(query)) {
        results.push({
          title: `${mov.type} - ${mov.sku}`,
          subtitle: `${mov.ref} - Qty: ${mov.qty}`,
          module: 'STK',
          icon: 'local_shipping',
          route: 'stock-movement',
          data: mov,
          type: 'movement'
        });
      }
    });

    // Search in payroll
    (db.get('payruns')||[]).forEach(pay => {
      if (pay.period?.toLowerCase().includes(query)) {
        results.push({
          title: `Payroll - ${pay.period}`,
          subtitle: `${fmt.money(pay.gross)}`,
          module: 'PAY',
          icon: 'payments',
          route: 'payroll',
          data: pay,
          type: 'payroll'
        });
      }
    });

    // Search in employees
    (db.get('employees')||[]).forEach(emp => {
      if (emp.name.toLowerCase().includes(query) || 
          emp.id.toLowerCase().includes(query)) {
        results.push({
          title: emp.name,
          subtitle: `${emp.id} - ${emp.dept}`,
          module: 'HR',
          icon: 'person',
          route: 'connector-hr',
          data: emp
        });
      }
    });

    return results;
  }

  function highlightItem(selector, containerId) {
    setTimeout(() => {
      const container = document.getElementById(containerId);
      const item = document.querySelector(selector);
      if (container && item) {
        container.scrollTo({
          top: item.offsetTop - container.offsetTop - 100,
          behavior: 'smooth'
        });
        item.classList.add('highlight');
        setTimeout(() => item.classList.remove('highlight'), 2000);
      }
    }, 200);
  }

  function navigateToResult(result) {
    if (!result) return;

    // First navigate to the correct module
    const navLink = document.querySelector(`.navlink[data-route="${result.route}"]`);
    if (navLink) {
      navLink.click();

      // Wait for navigation to complete
      setTimeout(() => {
        // Handle specific item types
        switch(result.type) {
          case 'nav':
            // Just navigation is enough
            break;
            
          case 'journal':
            highlightItem(`[data-ref="${result.data.ref}"]`, 'gl-entries');
            break;
            
          case 'invoice':
            highlightItem(`[data-ref="${result.data.ref}"]`, 'ar-list');
            break;
            
          case 'bill':
            highlightItem(`[data-ref="${result.data.ref}"]`, 'ap-list');
            break;
            
          case 'item':
            highlightItem(`[data-sku="${result.data.sku}"]`, 'inventory-list');
            break;
            
          case 'employee':
            highlightItem(`[data-id="${result.data.id}"]`, 'employee-list');
            break;
            
          case 'asset':
            highlightItem(`[data-code="${result.data.code}"]`, 'asset-list');
            break;
        }
      }, 100);
    }

    // Then highlight or scroll to the specific item if needed
    setTimeout(() => {
      switch(result.type) {
        case 'nav':
          // Just navigation is enough
          break;
        case 'transaction':
          // Highlight the transaction in the list
          const transactionEl = document.querySelector(`[data-ref="${result.data.ref}"]`);
          if (transactionEl) {
            transactionEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            transactionEl.classList.add('highlight');
            setTimeout(() => transactionEl.classList.remove('highlight'), 2000);
          }
          break;
        case 'item':
        case 'movement':
        case 'payroll':
          // Scroll to the item if possible
          const itemEl = document.querySelector(`[data-id="${result.data.id || result.data.ref}"]`);
          if (itemEl) {
            itemEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            itemEl.classList.add('highlight');
            setTimeout(() => itemEl.classList.remove('highlight'), 2000);
          }
          break;
      }
    }, 100);

    // Clear search
    searchInput.value = '';
    searchResults.classList.add('hidden');
    searchInput.blur();
  }

  // Handle input changes
  searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    const query = e.target.value.trim();
    
    if (query.length < 2) {
      searchResults.classList.add('hidden');
      selectedIndex = -1;
      return;
    }

    searchTimeout = setTimeout(() => {
      let results = searchAllModules(query);
      
      // Sort results by relevance
      results.sort((a, b) => {
        // Exact matches first
        const aTitle = a.title.toLowerCase();
        const bTitle = b.title.toLowerCase();
        const aExact = aTitle === query;
        const bExact = bTitle === query;
        if (aExact && !bExact) return -1;
        if (!aExact && bExact) return 1;
        
        // Then navigation items
        if (a.type === 'nav' && b.type !== 'nav') return -1;
        if (a.type !== 'nav' && b.type === 'nav') return 1;
        
        // Then by starting with search text
        const aStarts = aTitle.startsWith(query);
        const bStarts = bTitle.startsWith(query);
        if (aStarts && !bStarts) return -1;
        if (!aStarts && bStarts) return 1;
        
        // Then by title length (shorter = more relevant)
        return aTitle.length - bTitle.length;
      });

      // Limit to top 10 results
      results = results.slice(0, 10);
      
      if (results.length) {
        currentResults = results;
        searchResults.innerHTML = results.map((r, idx) => `
          <div class="search-result-item ${idx === selectedIndex ? 'selected' : ''}" 
               data-route="${r.route}" 
               data-index="${idx}"
               data-type="${r.type}">
            <div class="search-result-icon">
              <i class="material-icons">${r.icon}</i>
            </div>
            <div class="search-result-info">
              <div class="search-result-title">${r.title}</div>
              <div class="search-result-subtitle">${r.subtitle}</div>
            </div>
            <div class="search-result-module ${r.type === 'nav' ? 'nav-module' : ''}">${r.module}</div>
          </div>
        `).join('');
        searchResults.classList.remove('hidden');
      } else {
        searchResults.innerHTML = `
          <div class="search-result-item">
            <div class="search-result-info">
              <div class="search-result-title">No results found</div>
              <div class="search-result-subtitle">Try a different search term</div>
            </div>
          </div>
        `;
        searchResults.classList.remove('hidden');
      }
    }, 300);
  });

  // Handle click on search results
  searchResults.addEventListener('click', (e) => {
    const resultItem = e.target.closest('.search-result-item');
    if (resultItem) {
      const index = parseInt(resultItem.dataset.index);
      if (!isNaN(index) && currentResults[index]) {
        navigateToResult(currentResults[index]);
      }
    }
  });

  // Handle keyboard navigation
  searchInput.addEventListener('keydown', (e) => {
    if (searchResults.classList.contains('hidden')) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        selectedIndex = Math.min(selectedIndex + 1, currentResults.length - 1);
        updateSelection();
        break;
      case 'ArrowUp':
        e.preventDefault();
        selectedIndex = Math.max(selectedIndex - 1, -1);
        updateSelection();
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && currentResults[selectedIndex]) {
          navigateToResult(currentResults[selectedIndex]);
        }
        break;
    }
  });

  function updateSelection() {
    const items = searchResults.querySelectorAll('.search-result-item');
    items.forEach((item, idx) => {
      if (idx === selectedIndex) {
        item.classList.add('selected');
        item.scrollIntoView({ block: 'nearest' });
      } else {
        item.classList.remove('selected');
      }
    });
  }

  // Close search results when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-container')) {
      searchResults.classList.add('hidden');
    }
  });

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    // Press / to focus search
    if (e.key === '/' && !e.target.closest('input, textarea')) {
      e.preventDefault();
      searchInput.focus();
    }
    // Press Escape to close search results
    if (e.key === 'Escape') {
      searchResults.classList.add('hidden');
      searchInput.blur();
    }
  });
}

// Boot
initUI();
initAuth();
initGlobalSearch();
mountRouter({
  'dashboard': initDashboard,
  'general-ledger': initGL,
  'asset-management': initAssets,
  'tax-management': initTax,
  'apayables': initAP,
  'areceivable': initAR,
  'budgeting': initBudgeting,
  'payroll': initPayroll,
  'stock-movement': initStock,
  'connector-crm': initCRM,
  'connector-inventory': initInventoryConnector,
  'connector-hr': initHRConnector,
  'connector-projects': initProjects,
  'settings': () => {
    const el = document.getElementById('content');
    el.innerHTML = `
      <section class="grid gap-1">
        <div class="card">
          <div class="card-head"><div class="card-title">Settings</div></div>
          <div class="grid grid-2">
            <label class="field"><span>Company Name</span>
              <input value="${state().company}" id="company-name"/>
            </label>
            <label class="field"><span>Default VAT %</span>
              <input value="${state().vat}" id="company-vat" type="number"/>
            </label>
          </div>
          <div class="hstack gap-1 mt-2">
            <button class="btn btn-primary" id="save-settings">Save</button>
            <button class="btn" id="reset-db">Reset Demo Data</button>
          </div>
        </div>
      </section>
    `;
    document.getElementById('save-settings').onclick = () => {
      const name = document.getElementById('company-name').value;
      const vat = parseFloat(document.getElementById('company-vat').value||'0');
      db.patch('meta', {company: name, vat});
      bus.emit('notif', {type:'info', text:`Settings saved.`});
    };
    document.getElementById('reset-db').onclick = () => {
      if(confirm('Reset all demo data?')){
        localStorage.removeItem('fa-suite');
        location.reload();
      }
    };
  }
});

// Seed demo data once
if(!state().seeded){
  db.tx(() => {
    db.patch('meta', {seeded:true, company:'Demo Corp', vat:12, cash: 250000});
    // COA
    db.set('coa', [
      {code:'1000', name:'Cash', type:'asset'},
      {code:'1100', name:'Accounts Receivable', type:'asset'},
      {code:'1200', name:'Inventory', type:'asset'},
      {code:'1500', name:'Fixed Assets', type:'asset'},
      {code:'2000', name:'Accounts Payable', type:'liability'},
      {code:'2100', name:'VAT Payable', type:'liability'},
      {code:'3000', name:'Equity', type:'equity'},
      {code:'4000', name:'Sales Revenue', type:'income'},
      {code:'4100', name:'Other Income', type:'income'},
      {code:'5000', name:'COGS', type:'expense'},
      {code:'5100', name:'Operating Expense', type:'expense'},
      {code:'5200', name:'Payroll Expense', type:'expense'},
      {code:'5300', name:'Depreciation Expense', type:'expense'}
    ]);
    // Some inventory and items
    db.set('items', [
      {sku:'ITEM-001', name:'Widget A', avgCost:100, onHand:50},
      {sku:'ITEM-002', name:'Widget B', avgCost:150, onHand:20}
    ]);
    db.set('movements', []);
    // AR/AP
    db.set('customers', [{id:'CUST-001', name:'Acme Co.'}]);
    db.set('vendors', [{id:'VEND-001', name:'Supply Co.'}]);
    db.set('invoices', []);
    db.set('bills', []);
    // Payroll/HR
    db.set('employees', [{id:'EMP-001', name:'Juan Dela Cruz', rate:2500, dept:'Ops'}]);
    db.set('payruns', []);
    // Assets
    db.set('assets', [{code:'FA-001', name:'Office Laptop', cost:60000, life:36, accum:10000, start: new Date().toISOString().slice(0,10)}]);
    // GL/Tax
    db.set('journals', []);
    db.set('vatledger', []);
    // Budgets
    db.set('budgets', [{year:new Date().getFullYear(), scope:'Ops', category:'OPEX', amount:150000, actual:0}]);
  });
  bus.emit('notif',{type:'info', text:'Demo data loaded.'});
}
