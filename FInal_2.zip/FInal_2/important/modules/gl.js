
import { db, fmt, notify } from './db.js';

export async function initGL(){
  const el = document.getElementById('content');
  
  // Show loading state
  el.innerHTML = '<div class="loading">Loading General Ledger...</div>';
  
  try {
    const [coa, entries] = await Promise.all([
      db.get('coa'),
      db.get('journals')
    ]);

  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>General Ledger</h2>
        <div class="hstack gap-1">
          <button id="btn-add-journal" class="btn btn-primary">New Journal Entry</button>
          <button id="btn-export-gl" class="btn">Export JSON</button>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Chart of Accounts</div></div>
        <div class="grid grid-3">
          ${coa.map(a=>`<div class="card"><div class="muted tiny">${a.type.toUpperCase()}</div><b>${a.code}</b> - ${a.name}</div>`).join('')}
        </div>
      </div>
      <div class="card">
        <div class="card-head">
          <div class="card-title">Entries</div>
          <div class="hstack gap-1">
            <div class="search-wrapper">
              <i class="material-icons search-icon">search</i>
              <input type="text" id="gl-search" placeholder="Search entries..." class="search-input">
            </div>
          </div>
        </div>
        <div class="transaction-history" id="gl-entries">
          <div id="gl-rows"></div>
        </div>
      </div>
    </section>
  `;

  // Initialize search functionality
  const searchInput = document.getElementById('gl-search');
  searchInput.addEventListener('input', async (e) => {
    await renderRows(e.target.value.trim());
  });

  // Initial render
  await renderRows();

  document.getElementById('btn-add-journal').onclick = async () => {
    const date = prompt('Date (YYYY-MM-DD)', fmt.date(new Date()));
    const account = prompt('Account code (e.g., 1000, 4000, 5000)');
    const debit = parseFloat(prompt('Debit amount (0 if none)','0')||'0');
    const credit = parseFloat(prompt('Credit amount (0 if none)','0')||'0');
    const memo = prompt('Memo','Manual JE');
    const ref = 'JE-'+fmt.uuid();
    const row = {date, ref, account, debit, credit, dept:'-', proj:'-', memo};
    
    try {
      const currentJournals = await db.get('journals');
      await db.set('journals', [row, ...currentJournals]);
      if(account==='1000'){ 
        const meta = await db.get('meta'); 
        meta.cash += (debit-credit); 
        await db.set('meta', meta); 
      }
    await notify({text: `Journal entry added.`, type: 'success', ref: ref});
      await renderRows();
    } catch (error) {
      console.error('Error adding journal entry:', error);
      alert('Error adding journal entry. Please try again.');
    }
  };

  document.getElementById('btn-export-gl').onclick = async () => {
    try {
      const journals = await db.get('journals');
      const blob = new Blob([JSON.stringify(journals, null, 2)], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href=url; a.download='gl_entries.json'; a.click(); URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting GL data:', error);
      alert('Error exporting data. Please try again.');
    }
  };

  async function renderRows(searchTerm = ''){
    try {
      const body = document.getElementById('gl-rows');
      const currentEntries = await db.get('journals');
      const entries = (currentEntries||[]).filter(e => {
        if (!searchTerm) return true;
        const searchLower = searchTerm.toLowerCase();
        return e.ref.toLowerCase().includes(searchLower) ||
               e.memo?.toLowerCase().includes(searchLower) ||
               e.account.toLowerCase().includes(searchLower);
      });

    body.innerHTML = entries.map(e=>{
      const isDebit = e.debit > 0;
      const amount = isDebit ? e.debit : e.credit;
      const icon = isDebit ? 'arrow_downward' : 'arrow_upward';
      const accountInfo = coa.find(a => a.code === e.account) || {};
      const color = isDebit ? 'var(--bad)' : 'var(--ok)';
      
      return `
        <div class="transaction-item" data-ref="${e.ref}">
          <div class="transaction-icon" style="color: ${color}">
            <i class="material-icons">${icon}</i>
          </div>
          <div class="transaction-info">
            <div class="transaction-title">${e.memo || `${accountInfo.name || e.account} Transaction`}</div>
            <div class="transaction-meta">
              <span>${e.date}</span>
              <span>${e.ref}</span>
              <span class="transaction-module">${accountInfo.type?.toUpperCase() || 'GL'}</span>
              ${e.dept !== '-' ? `<span class="transaction-dept">${e.dept}</span>` : ''}
              ${e.proj !== '-' ? `<span class="transaction-proj">${e.proj}</span>` : ''}
            </div>
          </div>
          <div class="transaction-amount" style="color: ${color}">
            ${isDebit ? '-' : '+'}${fmt.money(amount)}
          </div>
          <div class="crud-actions">
            <button onclick="editJournal('${e.ref}')" class="btn-icon" title="Edit">
              <i class="material-icons">edit</i>
            </button>
            <button onclick="deleteJournal('${e.ref}')" class="btn-icon delete" title="Delete">
              <i class="material-icons">delete</i>
            </button>
          </div>
        </div>
      `;
    }).join('');

    window.editJournal = async (ref) => {
      try {
        const journals = await db.get('journals');
        const entry = journals.find(j => j.ref === ref);
        if (!entry) return;

        const date = prompt('Date (YYYY-MM-DD)', entry.date);
        const account = prompt('Account code', entry.account);
        const debit = parseFloat(prompt('Debit amount', entry.debit)||'0');
        const credit = parseFloat(prompt('Credit amount', entry.credit)||'0');
        const memo = prompt('Memo', entry.memo);
        
        if (!date || !account) return;

        const updatedJournals = journals.map(j => {
          if (j.ref === ref) {
            return {...j, date, account, debit, credit, memo};
          }
          return j;
        });

        await db.set('journals', updatedJournals);
    await notify({text: `Journal entry ${ref} updated.`, type: 'info', ref: ref});
        await renderRows();
      } catch (error) {
        console.error('Error editing journal entry:', error);
        alert('Error updating journal entry. Please try again.');
      }
    };

    window.deleteJournal = async (ref) => {
      if (!confirm('Are you sure you want to delete this journal entry?')) return;
      
      try {
        const journals = await db.get('journals');
        const updatedJournals = journals.filter(j => j.ref !== ref);
        await db.set('journals', updatedJournals);
    await notify({text: `Journal entry ${ref} deleted.`, type: 'warning', ref: ref});
        await renderRows();
      } catch (error) {
        console.error('Error deleting journal entry:', error);
        alert('Error deleting journal entry. Please try again.');
      }
    };
    
  } catch (error) {
    console.error('Error rendering GL rows:', error);
    const body = document.getElementById('gl-rows');
    if (body) {
      body.innerHTML = '<div class="error">Error loading journal entries. Please try again.</div>';
    }
  }
}

  } catch (error) {
    console.error('Error loading General Ledger:', error);
    el.innerHTML = '<div class="error">Error loading General Ledger. Please try again.</div>';
  }
}
