
import { db, fmt, state, notify } from './db.js';

export async function initAR(){
  const el = document.getElementById('content');
  let orders = [];
  try {
    orders = await db.get('sales_orders');
  } catch (err) {
    el.innerHTML = `<div class="error">Failed to load sales orders.<br>${err?.message || err}</div>`;
    return;
  }
  const arOutstanding = (orders||[]).filter(o=>o.payment_status==='paid').reduce((s,o)=>s+parseFloat(o.total_amount||0),0);
  const customerCount = new Set((orders||[]).map(o=>o.customer_id)).size;
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Accounts Receivable</h2>
      </div>
      <div class="grid grid-3">
        <div class="kpi"><div class="label">AR Outstanding</div><div class="value" id="ar-out">${fmt.money(arOutstanding)}</div></div>
        <div class="kpi"><div class="label">Customers</div><div class="value" id="ar-customers">${customerCount}</div></div>
        <div class="kpi"><div class="label">Invoices</div><div class="value" id="ar-invoices">${orders.length}</div></div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Invoices</div></div>
        <table class="table">
          <thead><tr><th>Date</th><th>Customer ID</th><th>Order ID</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody id="ar-rows"></tbody>
        </table>
      </div>
    </section>
  `;
  await render();

  // Removed top right Record Payment button logic

  async function render(){
    const body = document.getElementById('ar-rows');
    let orders = [];
    try {
      orders = await db.get('sales_orders');
    } catch (err) {
      body.innerHTML = `<tr><td colspan="6" class="error">Failed to load sales orders.<br>${err?.message || err}</td></tr>`;
      return;
    }
    if (!orders || orders.length === 0) {
      body.innerHTML = `<tr><td colspan="6" class="muted">No invoices found.</td></tr>`;
      return;
    }
    body.innerHTML = (orders||[]).map(o=>`<tr>
      <td>${o.order_date}</td><td>${o.customer_id}</td><td>${o.order_id}</td><td>${fmt.money(o.total_amount)}</td><td>${o.payment_status}</td>
      <td>
          <button class="btn record-payment-btn" data-order-id="${o.order_id}">Record Payment</button>
      </td>
    </tr>`).join('');

    // Attach event listeners after rendering
    body.querySelectorAll('.record-payment-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const order_id = btn.getAttribute('data-order-id');
        try {
          await window.recordPayment(order_id);
        } catch (err) {
          console.error('Payment error:', err);
          alert('Payment failed: ' + (err?.message || err));
        }
      });
    });
  }

  window.recordPayment = async (order_id) => {
    const orders = await db.get('sales_orders');
    const order = orders.find(o => o.order_id == order_id);
    if (!order) return;
    if (order.payment_status !== 'paid') {
      await notify({text: 'Unpaid Orders', type: 'warning', ref: order.order_id});
      return;
    }
    // Add to cash
    const meta = await db.get('meta');
    meta.cash = parseFloat(meta.cash||0) + parseFloat(order.total_amount||0);
    try {
      await db.post('meta', { key: 'default', value: meta }); // Use correct payload for meta update
    } catch (err) {
      console.error('Meta update failed:', err);
    }
    // Remove the paid order from sales_orders
    try {
      await db.delete('sales_orders', order_id); // Use delete to remove the order
    } catch (err) {
      console.error('Order removal failed:', err);
    }
    // Recalculate AR Outstanding
    const updatedOrders = orders.filter(o => o.order_id != order_id);
    const arOutstandingAfter = (updatedOrders||[]).filter(o=>o.payment_status==='paid').reduce((s,o)=>s+parseFloat(o.total_amount||0),0);
    document.getElementById('ar-out').textContent = fmt.money(arOutstandingAfter);
    try {
      await notify({text: `Payment received for order ${order.order_id}.`, type: 'success', ref: order.order_id});
    } catch (err) {
      console.error('Notification failed:', err);
    }
    if (window.initDashboard) await window.initDashboard();
    await initAR();
  };
}
