
import { db, fmt, state, notify } from './db.js';

export async function initTax(){
  const el = document.getElementById('content');
  const meta = await state();
  const vat = meta.vat || 12;
  const vatledger = await db.get('vatledger');
  const vatPayable = (vatledger||[]).reduce((s,v)=>s+v.vat*(v.type==='output'?1:-1),0);
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Tax Management</h2>
        <button id="btn-set-vat" class="btn btn-primary">Set VAT Rate</button>
      </div>
      <div class="grid grid-3">
        <div class="kpi"><div class="label">Current VAT Rate</div><div class="value" id="vat-rate">${vat}%</div></div>
        <div class="kpi"><div class="label">VAT Payable</div><div class="value" id="vat-payable">${fmt.money(vatPayable)}</div></div>
        <div class="kpi"><div class="label">Withholding Tax (Net)</div><div class="value" id="wht-net">${fmt.money(0)}</div></div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">VAT Ledger</div></div>
        <table class="table">
          <thead><tr><th>Date</th><th>Type</th><th>Base</th><th>VAT</th><th>Ref</th></tr></thead>
          <tbody id="vat-rows"></tbody>
        </table>
      </div>
    </section>
  `;

  document.getElementById('btn-set-vat').onclick = async () => {
    const meta = await state();
    const rate = parseFloat(prompt('VAT %', meta.vat||12)||'12');
  await db.patch('meta', {vat: rate});
  await notify({text: `VAT rate set to ${rate}%.`, type: 'info', ref: 'tax'});
    await initTax();
  };

  const rows = document.getElementById('vat-rows');
  rows.innerHTML = (vatledger||[]).map(v=>`<tr>
    <td>${v.date}</td><td>${v.type}</td><td>${fmt.money(v.base)}</td><td>${fmt.money(v.vat)}</td><td>${v.ref}</td>
  </tr>`).join('');
}
