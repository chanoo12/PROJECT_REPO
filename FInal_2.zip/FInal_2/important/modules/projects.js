
import { db, fmt, notify } from './db.js';

export function initProjects(){
  const el = document.getElementById('content');
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Project Management Connector</h2>
        <div class="hstack gap-1">
          <button id="btn-add-proj-budget" class="btn btn-primary">Add Project Budget</button>
          <button id="btn-post-expense" class="btn">Post Project Expense → GL</button>
        </div>
      </div>
      <div class="card">
        <p class="muted">Magdagdag ng budget at mag-post ng gastos na papasok sa GL bilang OPEX (5100) at magre-reflect sa Budgeting variance.</p>
      </div>
    </section>
  `;

  document.getElementById('btn-add-proj-budget').onclick = async () => {
    const year = new Date().getFullYear();
    const name = prompt('Project name','Project Alpha');
    const amount = parseFloat(prompt('Budget Amount','200000')||'0');
    const row = {year, scope:name, category:'PROJECT', amount, actual:0};
    await db.set('budgets', [row, ...db.get('budgets')]);
    await notify({text: `Project budget for "${name}" added.`, type: 'info', ref: name});
    window.navigate('budgeting');
  };

  document.getElementById('btn-post-expense').onclick = async () => {
    const scope = prompt('Project scope to apply','Project Alpha');
    const amount = parseFloat(prompt('Expense Amount','15000')||'0');
    const date = fmt.date(new Date()); const ref = 'PRJ-'+fmt.uuid();
    // GL: DR OPEX 5100, CR Cash 1000
    const je1 = {date, ref, account:'5100', debit:amount, credit:0, memo:`Project ${scope} Expense`};
    const je2 = {date, ref, account:'1000', debit:0, credit:amount, memo:'Cash Out'};
    await db.set('journals', [je1, je2, ...db.get('journals')]);
    // budget actual
    const budgets = db.get('budgets').map(b=>{
      if(b.scope===scope){ b.actual = (b.actual||0) + amount; }
      return b;
    });
    await db.set('budgets', budgets);
    const meta = db.get('meta'); meta.cash -= amount; await db.set('meta', meta);
    await notify({text: `Project expense posted for "${scope}".`, type: 'success', ref: scope});
    window.navigate('budgeting');
  };
}
