
const API_BASE = window.location.origin + '/api';

const listeners = {};
export const bus = {
  on(evt, cb){ (listeners[evt] ||= []).push(cb); },
  emit(evt, data){ (listeners[evt]||[]).forEach(cb=>cb(data)); }
};

// API helper functions
export async function apiCall(endpoint, options = {}) {
  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...options
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      let errorMessage = `API call failed: ${response.status} ${response.statusText}`;
      
      try {
        const errorData = JSON.parse(errorText);
        if (errorData.message) {
          errorMessage += ` - ${errorData.message}`;
        }
      } catch (e) {
        if (errorText) {
          errorMessage += ` - ${errorText}`;
        }
      }
      
      throw new Error(errorMessage);
    }
    
    return await response.json();
  } catch (error) {
    if (error.name === 'TypeError' && error.message.includes('fetch')) {
      throw new Error('Network error: Unable to connect to server. Please check if the server is running.');
    }
    throw error;
  }
}

// Cache for meta data

let metaCache = null;

export async function state() {
  if (!metaCache) {
    metaCache = await apiCall('/data/meta');
  }
  return metaCache;
}

export const db = {
  async get(path) {
    if (path === 'meta') {
      return await state();
    }
    const data = await apiCall(`/data/${path}`);
    return data || [];
  },

  async set(path, val) {
    if (path === 'meta') {
      // No direct PUT for meta, update via patch or backend logic if needed
      metaCache = await apiCall('/data/meta', {
        method: 'PUT',
        body: JSON.stringify(val)
      });
    } else {
      if (Array.isArray(val)) {
        for (const item of val) {
          await this.post(path, item);
        }
      } else {
        await this.post(path, val);
      }
    }
    bus.emit('change', { path });
  },

  async patch(path, partial) {
    if (path === 'meta') {
      const currentMeta = await state();
      const updatedMeta = { ...currentMeta, ...partial };
      if (!updatedMeta || Object.keys(updatedMeta).length === 0) {
        throw new Error('Meta update cannot be empty.');
      }
      metaCache = await apiCall('/data/meta', {
        method: 'PUT',
        body: JSON.stringify(updatedMeta)
      });
    } else {
      const currentData = await this.get(path);
      const updatedData = { ...currentData, ...partial };
      await this.set(path, updatedData);
    }
    bus.emit('change', { path });
  },

  async post(path, data) {
    const result = await apiCall(`/data/${path}`, {
      method: 'POST',
      body: JSON.stringify(data)
    });
    bus.emit('change', { path });
    return result;
  },

  async put(path, id, data) {
    const result = await apiCall(`/data/${path}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
    bus.emit('change', { path });
    return result;
  },

  async delete(path, id) {
    const result = await apiCall(`/data/${path}/${id}`, {
      method: 'DELETE'
    });
    bus.emit('change', { path });
    return result;
  },

  async tx(fn) {
    await fn();
    bus.emit('change', { path: '*' });
  }
};

export const fmt = {
  money(n){ return '₱'+(n||0).toLocaleString(undefined,{minimumFractionDigits:2, maximumFractionDigits:2}); },
  date(d){ return new Date(d).toISOString().slice(0,10); },
  uuid(){ return Math.random().toString(36).slice(2,10).toUpperCase(); }
};

// Notification helper
export async function notify(text, type='info', ref=null) {
  const entry = {
    id: fmt.uuid(), 
    date: new Date().toISOString(), 
    text, 
    type, 
    ref, 
    read: false
  };
  
  try {
  const result = await db.post('fa_notifications', entry);
    if (result === null) {
      console.log('API failed for notification, using bus only');
    }
    bus.emit('notif', entry);
  } catch (error) {
    console.error('Failed to create notification:', error);
    // Still emit the notification even if database fails
    bus.emit('notif', entry);
  }
}
