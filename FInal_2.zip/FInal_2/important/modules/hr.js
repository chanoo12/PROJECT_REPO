
import { db, fmt, notify } from './db.js';

export function initHRConnector(){
  const el = document.getElementById('content');
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>HR Connector</h2>
        <button id="btn-sync-hr" class="btn btn-primary">Sync HR → Payroll & GL</button>
      </div>
      <div class="card">
        <p class="muted">Mag-ge-generate ng payroll run base sa HR employees at ipo-post sa Payroll module at GL (Payroll Expense / Cash).</p>
      </div>
    </section>
  `;

  document.getElementById('btn-sync-hr').onclick = async () => {
    const days = parseInt(prompt('Days worked for sync','10')||'0',10);
    const gross = (db.get('employees')||[]).reduce((s,e)=>s + e.rate*days,0);
    const tax = gross*0.1; const net = gross-tax;
    const date = fmt.date(new Date());
    const run = {date, period:`${days} days (HR Sync)`, gross, net};
    await db.set('payruns', [run, ...db.get('payruns')]);
    const ref = 'HRP-'+fmt.uuid();
    const je1 = {date, ref, account:'5200', debit:gross, credit:0, memo:'Payroll Expense (HR Sync)'};
    const je2 = {date, ref, account:'1000', debit:0, credit:net, memo:'Cash Out'};
    await db.set('journals', [je1, je2, ...db.get('journals')]);
    const meta = db.get('meta'); meta.cash -= net; await db.set('meta', meta);
    await notify({text: `HR sync to payroll complete.`, type: 'success', ref: 'hr'});
    window.navigate('payroll');
  };
}
