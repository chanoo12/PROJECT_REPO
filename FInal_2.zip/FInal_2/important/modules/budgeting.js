
import { db, fmt, notify } from './db.js';
export async function initBudgeting(){
  const el = document.getElementById('content');
  // Fetch budgeting balance and cash balance
  let meta = await db.get('meta');
  let budgetingBalance = meta?.budgetingBalance || 0;
  let cashBalance = meta?.cash || 0;
  // Fetch projects for approval
  const budgets = await db.get('budgets');
  const projectBudgets = (budgets||[]).filter(b => b.category === 'PROJECT');
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Budgeting</h2>
        <div class="hstack gap-1">
          <div class="kpi" style="margin-right:1em;">
            <div class="label">Budgeting Balance</div>
            <div class="value" id="budgeting-balance">${fmt.money(budgetingBalance)}</div>
          </div>
          <button id="btn-set-balance" class="btn">Set Budgeting Balance</button>
          <button id="btn-approve-project" class="btn btn-primary">Approve/Decline Project</button>
          <button id="btn-add-budget" class="btn btn-primary">New Budget</button>
        </div>
      </div>
      <div class="card">
        <table class="table">
          <thead><tr><th>Year</th><th>Dept/Project</th><th>Category</th><th>Amount</th><th>Actual</th><th>Variance</th><th>Actions</th></tr></thead>
          <tbody id="budget-rows"></tbody>
        </table>
      </div>
    </section>
  `;
  await render();

  document.getElementById('btn-set-balance').onclick = async () => {
    meta = await db.get('meta');
    cashBalance = meta?.cash || 0;
    const input = prompt('Enter new budgeting balance amount:', cashBalance);
    const amount = parseFloat(input||'0');
    if (isNaN(amount) || amount < 0) return alert('Invalid amount.');
    if (amount > cashBalance) return alert('Not enough cash balance!');
    meta.budgetingBalance = (meta.budgetingBalance||0) + amount;
    meta.cash -= amount;
    await db.set('meta', meta);
  document.getElementById('budgeting-balance').innerText = fmt.money(meta.budgetingBalance);
  await notify({text: `Budgeting balance set to ${fmt.money(amount)}.`, type: 'success', ref: 'budgeting'});
  };

  document.getElementById('btn-approve-project').onclick = async () => {
    // Get all unique categories from budgets
    const budgets = await db.get('budgets');
    const categories = [...new Set((budgets||[]).map(b => b.category))];
    if (categories.length === 0) return alert('No categories found.');
    const catList = categories.map((c,i)=>`${i+1}. ${c}`).join('\n');
    const catIdx = parseInt(prompt(`Select category to approve/reject:\n${catList}`)||'0',10)-1;
    if (isNaN(catIdx) || catIdx < 0 || catIdx >= categories.length) return;
    const selectedCategory = categories[catIdx];
    // Only show pending budgets in selected category
    const items = (budgets||[]).filter(b => b.category === selectedCategory && (b.status === 'pending' || !b.status));
    if (items.length === 0) return alert(`No pending items to approve in category: ${selectedCategory}`);
    const itemNames = items.map((p,i)=>`${i+1}. ${p.scope} (${fmt.money(p.amount)}) [${p.status||'pending'}]`).join('\n');
    const idx = parseInt(prompt(`Select item to approve/reject in ${selectedCategory}:\n${itemNames}`)||'0',10)-1;
    if (isNaN(idx) || idx < 0 || idx >= items.length) return;
    const item = items[idx];
    const action = prompt(`Approve or Reject "${item.scope}"? (Type 'approve' or 'reject')`).toLowerCase();
    let meta = await db.get('meta');
    if (action === 'approve') {
  if ((meta.budgetingBalance||0) < item.amount) return alert('Not enough budgeting balance!');
  meta.budgetingBalance -= item.amount;
  await db.set('meta', meta);
  await db.put('budgets', item.id, { status: 'approved' });
  await notify({text: `Project "${item.scope}" approved.`, type: 'success', ref: item.id});
  document.getElementById('budgeting-balance').innerText = fmt.money(meta.budgetingBalance);
    } else if (action === 'reject') {
  await db.put('budgets', item.id, { status: 'rejected' });
  await notify({text: `Project "${item.scope}" rejected.`, type: 'warning', ref: item.id});
    } else {
      alert('Invalid action. Type approve or reject.');
    }
    await render();
  };

  document.getElementById('btn-add-budget').onclick = async () => {
  const year = parseInt(prompt('Year', new Date().getFullYear())||new Date().getFullYear(),10);
  const scope = prompt('Dept/Project','Ops');
  const category = prompt('Category','OPEX');
  const amount = parseFloat(prompt('Amount','100000')||'0');
  let description = '';
  if (category === 'PROJECT') {
    description = prompt("Enter project description:", "Project details...") || '';
  }
  const row = {year, scope, category, amount, actual:0, description, status: category === 'PROJECT' ? 'pending' : ''};
  await db.set('budgets', row);
  if (category === 'PROJECT') {
    await notify({text: `New project budget created for "${scope}".`, type: 'info', ref: scope});
  } else {
    await notify({text: `New budget created for "${scope}".`, type: 'info', ref: scope});
  }
  await render();
};

  async function render(){
    const body = document.getElementById('budget-rows');
    if (!body) return; // Prevents error if element is missing
    let budgets = await db.get('budgets');
    
    body.innerHTML = (budgets||[]).map(b=>{
      const variance = (b.amount||0) - (b.actual||0);
      return `<tr>
        <td>${b.year}</td><td>${b.scope}</td><td>${b.category}</td>
        <td>${fmt.money(b.amount)}</td><td>${fmt.money(b.actual||0)}</td><td>${fmt.money(variance)}</td>
        <td>${b.status||''}</td>
        <td>${b.description||''}</td>
        <td>
          <button class="btn edit-btn" data-year="${b.year}" data-scope="${b.scope}">Edit</button>
          <button class="btn delete-btn" data-year="${b.year}" data-scope="${b.scope}">Delete</button>
        </td>
      </tr>`;
    }).join('');

    // Attach event listeners for edit and delete buttons
    body.querySelectorAll('.edit-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const year = parseInt(btn.dataset.year, 10);
        const scope = btn.dataset.scope;
        await window.editBudget(year, scope);
      });
    });
    body.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const year = parseInt(btn.dataset.year, 10);
        const scope = btn.dataset.scope;
        await window.deleteBudget(year, scope);
      });
    });
    // ...existing editBudget and deleteBudget logic, update Neon as above if needed...
  }

    window.editBudget = async (year, scope) => {
  const budgets = await db.get('budgets');
  const budget = budgets.find(b => b.year === year && b.scope === scope);
  if (!budget) return;

  const newAmount = parseFloat(prompt('Budget Amount', budget.amount)||'0');
  const newCategory = prompt('Category', budget.category);
  let newDescription = budget.description;
  if (newCategory === 'PROJECT') {
    newDescription = prompt('Project Description', budget.description||'') || '';
  }
  if (!newAmount || !newCategory) return;

  const updatedBudgets = budgets.map(b => {
    if (b.year === year && b.scope === scope) {
      return {...b, amount: newAmount, category: newCategory, description: newDescription};
    }
    return b;
  });

  await db.set('budgets', updatedBudgets);

  await notify({text: `Budget for "${scope}" updated.`, type: 'info', ref: scope});
  await render();
};

    window.deleteBudget = async (year, scope) => {
  if (!confirm('Are you sure you want to delete this budget?')) return;
  const budgets = await db.get('budgets');
  const updatedBudgets = budgets.filter(b => !(b.year === year && b.scope === scope));
  await db.set('budgets', updatedBudgets);

  await notify({text: `Budget for "${scope}" deleted.`, type: 'warning', ref: scope});
  await render();
    };
  }

