
import { db, fmt, notify } from './db.js';

export async function initPayroll(){
  const el = document.getElementById('content');
  const payruns = await db.get('payruns');
  const ytd = (payruns||[]).reduce((s,p)=>s+p.gross,0);
  const last = (payruns[0]||{}).date || '—';
  el.innerHTML = `
    <section class="grid gap-1">
      <div class="hstack" style="justify-content:space-between">
        <h2>Payroll</h2>
        <div class="hstack gap-1">
          <button id="btn-add-emp" class="btn">Add Employee</button>
          <button id="btn-run-payroll" class="btn btn-primary">Run Payroll</button>
        </div>
      </div>
      <div class="grid grid-3">
        <div class="kpi"><div class="label">Employees</div><div class="value" id="pay-emps">${(db.get('employees')||[]).length}</div></div>
        <div class="kpi"><div class="label">Last Payroll</div><div class="value" id="pay-last">${last}</div></div>
        <div class="kpi"><div class="label">Total Payroll (YTD)</div><div class="value" id="pay-ytd">${fmt.money(ytd)}</div></div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">Employees</div></div>
        <table class="table">
          <thead><tr><th>Emp #</th><th>Name</th><th>Rate</th><th>Dept</th><th>Actions</th></tr></thead>
          <tbody id="emp-rows"></tbody>
        </table>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Payroll Runs</div></div>
        <table class="table">
          <thead><tr><th>Date</th><th>Period</th><th>Gross</th><th>Net</th></tr></thead>
          <tbody id="prun-rows"></tbody>
        </table>
      </div>
    </section>
  `;
  await render();

  document.getElementById('btn-add-emp').onclick = async () => {
    const id = 'EMP-'+fmt.uuid();
    const name = prompt('Employee name','New Employee')||'Employee';
    const rate = parseFloat(prompt('Daily Rate','2000')||'0');
    const dept = prompt('Department','Ops');
    const employees = await db.get('employees');
    await db.set('employees', [...employees, {id, name, rate, dept}]);
    await notify({text: `Employee "${name}" added.`, type: 'info', ref: id});
    await initPayroll();
  };

  document.getElementById('btn-run-payroll').onclick = async () => {
    const days = parseInt(prompt('Days worked (this period)','10')||'0',10);
    const employees = await db.get('employees');
    const gross = (employees||[]).reduce((s,e)=>s + e.rate*days,0);
    const tax = gross * 0.1;
    const net = gross - tax;
    const date = fmt.date(new Date());
    const run = {date, period:`${days} days`, gross, net};
    const payruns = await db.get('payruns');
    await db.set('payruns', [run, ...payruns]);
    // GL: DR Payroll Expense 5200, CR Cash 1000, CR Withholding (ignore ledger)
    const je1 = {date, ref:'PAY-'+fmt.uuid(), account:'5200', debit:gross, credit:0, memo:'Payroll Expense'};
    const je2 = {date, ref:je1.ref, account:'1000', debit:0, credit:net, memo:'Cash Out'};
    const journals = await db.get('journals');
    await db.set('journals', [je1, je2, ...journals]);
    // Cash down
    const meta = await db.get('meta'); meta.cash -= net; await db.set('meta', meta);
    await notify({text: `Payroll run completed.`, type: 'success', ref: 'payroll'});
    await initPayroll();
  };

  async function render(){
    const ebody = document.getElementById('emp-rows');
    const employees = await db.get('employees');
    ebody.innerHTML = (employees||[]).map(e=>`<tr>
      <td>${e.id}</td><td>${e.name}</td><td>${fmt.money(e.rate)}</td><td>${e.dept}</td>
      <td>
        <button onclick="editEmployee('${e.id}')" class="btn">Edit</button>
        <button onclick="deleteEmployee('${e.id}')" class="btn">Delete</button>
      </td>
    </tr>`).join('');

    window.editEmployee = async (id) => {
      const employees = await db.get('employees');
      const employee = employees.find(e => e.id === id);
      if (!employee) return;

      const name = prompt('Employee name', employee.name);
      const rate = parseFloat(prompt('Daily Rate', employee.rate)||'0');
      const dept = prompt('Department', employee.dept);
      
      if (!name || !rate || !dept) return;

      const updatedEmployees = employees.map(e => {
        if (e.id === id) {
          return {...e, name, rate, dept};
        }
        return e;
      });

      await db.set('employees', updatedEmployees);
    await notify({text: `Employee "${name}" updated.`, type: 'info', ref: id});
      await initPayroll();
    };

    window.deleteEmployee = async (id) => {
      if (!confirm('Are you sure you want to delete this employee?')) return;
      const employees = await db.get('employees');
      const updatedEmployees = employees.filter(e => e.id !== id);
      await db.set('employees', updatedEmployees);
    await notify({text: `Employee "${id}" deleted.`, type: 'warning', ref: id});
      await initPayroll();
    };
    const pbody = document.getElementById('prun-rows');
    const payruns = await db.get('payruns');
    pbody.innerHTML = (payruns||[]).map(p=>`<tr>
      <td>${p.date}</td><td>${p.period}</td><td>${fmt.money(p.gross)}</td><td>${fmt.money(p.net)}</td>
    </tr>`).join('');
  }
// removed extra closing brace
}
