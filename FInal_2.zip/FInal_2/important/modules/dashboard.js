
import { db, fmt } from './db.js';

export async function initDashboard(){
  const el = document.getElementById('content');
  
  // Show loading state
  el.innerHTML = '<div class="loading">Loading dashboard...</div>';
  
  try {
    const [meta, invoices, bills, items, journals] = await Promise.all([
      db.get('meta'),
      db.get('invoices'),
      db.get('bills'),
      db.get('items'),
      db.get('journals')
    ]);
    
    const cash = meta?.cash || 0;
    const ar = (invoices||[]).filter(i=>i.status!=='Paid').reduce((s,i)=>s+i.amount,0);
    const ap = (bills||[]).filter(b=>b.status!=='Paid').reduce((s,b)=>s+b.amount,0);
    const invValue = (items||[]).reduce((s,i)=>s+i.avgCost*i.onHand,0);

  el.innerHTML = `
    <section class="grid gap-1">
      <div class="grid grid-4">
        <div class="kpi"><div class="label">Cash Balance</div><div class="value" id="kpi-cash">${fmt.money(cash)}</div></div>
        <div class="kpi"><div class="label">AR Outstanding</div><div class="value" id="kpi-ar">${fmt.money(ar)}</div></div>
        <div class="kpi"><div class="label">AP Outstanding</div><div class="value" id="kpi-ap">${fmt.money(ap)}</div></div>
        <div class="kpi"><div class="label">Inventory Value</div><div class="value" id="kpi-inv">${fmt.money(invValue)}</div></div>
      </div>

      <div class="grid grid-3">
        <div class="card">
          <div class="card-head"><div class="card-title">Revenue vs COGS (Monthly)</div><span class="tag">GL</span></div>
          <canvas id="chart-rev-cogs" height="140"></canvas>
        </div>
        <div class="card">
          <div class="card-head"><div class="card-title">Operating Expenses</div><span class="tag">GL</span></div>
          <canvas id="chart-opex" height="140"></canvas>
        </div>
        <div class="card">
          <div class="card-head"><div class="card-title">Cash Flow (12 mo)</div><span class="tag">GL</span></div>
          <canvas id="chart-cf" height="140"></canvas>
        </div>
      </div>

      <div class="grid grid-2">
        <div class="card">
          <div class="card-head"><div class="card-title">AR Aging</div><span class="tag">AR</span></div>
          <div id="ar-aging" class="aging"></div>
        </div>
        <div class="card">
          <div class="card-head"><div class="card-title">AP Aging</div><span class="tag">AP</span></div>
          <div id="ap-aging" class="aging"></div>
        </div>
      </div>

      <div class="card transaction-card">
        <div class="card-head">
          <div class="card-title">Transaction History</div>
          <div class="transaction-filters">
            <button class="filter-btn active" data-filter="all">All</button>
            <button class="filter-btn" data-filter="ar">AR</button>
            <button class="filter-btn" data-filter="ap">AP</button>
            <button class="filter-btn" data-filter="inv">Inventory</button>
            <button class="filter-btn" data-filter="pay">Payroll</button>
          </div>
        </div>
        <div class="transaction-history" id="transaction-history"></div>
      </div>
    </section>
  `;

  // Charts from GL entries
  const j = journals||[];
  const byMonth = {};
  j.forEach(e => {
    const m = e.date.slice(0,7);
    byMonth[m] ||= {rev:0,cogs:0,opex:0,cash:0};
    if(e.account.startsWith('4')) byMonth[m].rev += e.credit - e.debit;
    if(e.account==='5000') byMonth[m].cogs += e.debit - e.credit;
    if(e.account==='5100' || e.account==='5200' || e.account==='5300') byMonth[m].opex += e.debit - e.credit;
    if(e.account==='1000') byMonth[m].cash += e.debit - e.credit;
  });
  const labels = Object.keys(byMonth).sort();
  const rev = labels.map(m=>byMonth[m].rev||0);
  const cogs = labels.map(m=>byMonth[m].cogs||0);
  const opex= labels.map(m=>byMonth[m].opex||0);
  const cashF= labels.map(m=>byMonth[m].cash||0);

  const ctx1 = document.getElementById('chart-rev-cogs');
  new Chart(ctx1, {type:'line', data:{labels, datasets:[{label:'Revenue', data:rev}, {label:'COGS', data:cogs}]}});

  const ctx2 = document.getElementById('chart-opex');
  new Chart(ctx2, {type:'bar', data:{labels, datasets:[{label:'OPEX', data:opex}]}});

  const ctx3 = document.getElementById('chart-cf');
  new Chart(ctx3, {type:'line', data:{labels, datasets:[{label:'Cash Flow', data:cashF}]}});

  // Aging
  function aging(list){
    const buckets = { '0-30':0, '31-60':0, '61-90':0, '90+':0 };
    const today = new Date();
    list.forEach(i=>{
      const dt = new Date(i.date);
      const days = Math.floor((today - dt)/(1000*60*60*24));
      const a = i.amount;
      if(days<=30) buckets['0-30'] += a;
      else if(days<=60) buckets['31-60'] += a;
      else if(days<=90) buckets['61-90'] += a;
      else buckets['90+'] += a;
    });
    return buckets;
  }
  const arBuckets = aging((invoices||[]).filter(i=>i.status!=='Paid'));
  const apBuckets = aging((bills||[]).filter(b=>b.status!=='Paid'));
  document.getElementById('ar-aging').innerHTML = Object.entries(arBuckets).map(([k,v])=>`<span class="tag">${k}: <b>${fmt.money(v)}</b></span>`).join('');
  document.getElementById('ap-aging').innerHTML = Object.entries(apBuckets).map(([k,v])=>`<span class="tag">${k}: <b>${fmt.money(v)}</b></span>`).join('');

  // Transaction History
  const movements = await db.get('movements');
  const payruns = await db.get('payruns');
  
  const transactions = [
    // AR Transactions
    ...(invoices||[]).map(i => ({
      date: i.date,
      ref: i.ref,
      title: `Invoice - ${i.customer}`,
      amount: i.amount,
      type: 'ar',
      isPositive: true,
      icon: 'receipt_long',
      status: i.status
    })),
    // AP Transactions
    ...(bills||[]).map(b => ({
      date: b.date,
      ref: b.ref,
      title: `Bill - ${b.vendor}`,
      amount: b.amount,
      type: 'ap',
      isPositive: false,
      icon: 'description',
      status: b.status
    })),
    // Inventory Transactions
    ...(movements||[]).map(m => ({
      date: m.date,
      ref: m.ref,
      title: `${m.type} - ${m.sku}`,
      amount: m.qty * (m.unit || 0),
      type: 'inv',
      isPositive: m.type === 'RECEIPT',
      icon: 'inventory_2',
      status: 'Posted'
    })),
    // Payroll Transactions
    ...(payruns||[]).map(p => ({
      date: p.date,
      ref: 'PAY-' + p.date,
      title: `Payroll - ${p.period}`,
      amount: p.gross,
      type: 'pay',
      isPositive: false,
      icon: 'payments',
      status: 'Processed'
    }))
  ].sort((a, b) => new Date(b.date) - new Date(a.date));

  const transactionList = document.getElementById('transaction-history');
  const filterBtns = document.querySelectorAll('.filter-btn');

  function renderTransactions(filter = 'all') {
    const filtered = filter === 'all' ? transactions : transactions.filter(t => t.type === filter);
    transactionList.innerHTML = filtered.map(t => `
      <div class="transaction-item">
        <div class="transaction-icon">
          <i class="material-icons">${t.icon}</i>
        </div>
        <div class="transaction-info">
          <div class="transaction-title">${t.title}</div>
          <div class="transaction-meta">
            <span>${new Date(t.date).toLocaleDateString()}</span>
            <span>${t.ref}</span>
            <span class="transaction-module">${t.status}</span>
          </div>
        </div>
        <div class="transaction-amount ${t.isPositive ? 'positive' : 'negative'}">
          ${t.isPositive ? '+' : '-'}${fmt.money(Math.abs(t.amount))}
        </div>
      </div>
    `).join('');
  }

  // Initial render
  renderTransactions();

  // Filter handlers
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderTransactions(btn.dataset.filter);
    });
  });
  
  } catch (error) {
    console.error('Error loading dashboard:', error);
    el.innerHTML = '<div class="error">Error loading dashboard. Please try again.</div>';
  }
}
