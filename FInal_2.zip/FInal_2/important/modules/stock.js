
import { db, fmt, notify } from './db.js';

async function updateInventoryValue(){
  const items = await db.get('items');
  const value = (items||[]).reduce((s,i)=>s+i.avgCost*i.onHand,0);
  const meta = await db.get('meta'); meta.inventoryValue = value; await db.set('meta', meta);
}

async function initStock(){
  const el = document.getElementById('content');
  let items = await db.get('inventory_items') || [];
  let products = await db.get('products') || [];
  let pricing = await db.get('product_pricing') || [];
  // Map product_id to product details
  const productMap = Object.fromEntries(products.map(p => [p.product_id, p]));
  // Map product_id to price (use latest price if multiple)
  const priceMap = {};
  pricing.forEach(p => {
    priceMap[p.product_id] = parseFloat(p.price) || 0;
  });
  // Attach product_id and price to each item
  items = items.map(i => ({
    ...i,
    product_id: i.product_id,
    product_price: priceMap[i.product_id] || 0
  }));
  const totalProducts = items.length;
  const totalQty = items.reduce((sum, i) => sum + (i.total_quantity || 0), 0);
  // Inventory value: sum of total_quantity * product_price for each item
  const inventoryValue = items.reduce((sum, i) => sum + (i.total_quantity || 0) * (i.product_price || 0), 0);
  el.innerHTML = `
    <section class="grid gap-1">
      <h2>Inventory Stock</h2>
      <div class="grid grid-3">
        <div class="kpi"><div class="label">Total Products</div><div class="value" id="inv-products">${totalProducts}</div></div>
        <div class="kpi"><div class="label">Total Quantity</div><div class="value" id="inv-qty">${totalQty}</div></div>
        <div class="kpi"><div class="label">Inventory Value</div><div class="value" id="inv-value">${fmt.money(inventoryValue)}</div></div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Inventory Items</div></div>
        <table class="table">
          <thead>
            <tr>
              <th>Item Code</th>
              <th>Product ID</th>
              <th>Category</th>
              <th>Status</th>
              <th>Price</th>
              <th>Total Quantity</th>
              <th>Created At</th>
              <th>Updated At</th>
            </tr>
          </thead>
          <tbody id="item-rows">
            ${items.map(i => `
              <tr>
                <td>${i.item_code}</td>
                <td>${i.product_id}</td>
                <td>${i.category_id || ''}</td>
                <td>${i.status || ''}</td>
                <td>${fmt.money(i.product_price)}</td>
                <td>${i.total_quantity}</td>
                <td>${fmt.date(i.created_at)}</td>
                <td>${fmt.date(i.updated_at)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </section>
  `;


  async function render(){
    const tbody = document.getElementById('item-rows');
    const items = await db.get('items');
    tbody.innerHTML = (items||[]).map(i=>`<tr>
      <td>${i.sku}</td><td>${i.name}</td><td>${fmt.money(i.avgCost)}</td><td>${i.onHand}</td>
      <td>
        <button onclick="editItem('${i.sku}')" class="btn">Edit</button>
        <button onclick="deleteItem('${i.sku}')" class="btn">Delete</button>
      </td>
    </tr>`).join('');

    window.editItem = async (sku) => {
      const items = await db.get('items');
      const item = items.find(i => i.sku === sku);
      if (!item) return;

      const name = prompt('Item name', item.name);
      const avgCost = parseFloat(prompt('Average Cost', item.avgCost)||'0');
      const onHand = parseInt(prompt('On-hand Quantity', item.onHand)||'0',10);
      
      if (!name) return;

      const updatedItems = items.map(i => {
        if (i.sku === sku) {
          return {...i, name, avgCost, onHand};
        }
        return i;
      });

  await db.set('items', updatedItems);
  await notify({text: `Item "${name}" updated.`, type: 'info', ref: sku});
      await updateInventoryValue();
      await initStock();
    };

    window.deleteItem = async (sku) => {
      if (!confirm('Are you sure you want to delete this item?')) return;
      const items = await db.get('items');
      const updatedItems = items.filter(i => i.sku !== sku);
  await db.set('items', updatedItems);
  await notify({text: `Item "${sku}" deleted.`, type: 'warning', ref: sku});
      await updateInventoryValue();
      await initStock();
    };
    const mbody = document.getElementById('mov-rows');
    const movements = await db.get('movements');
    mbody.innerHTML = (movements||[]).map(m=>`<tr>
      <td>${m.date}</td><td>${m.type}</td><td>${m.sku}</td><td>${m.qty}</td><td>${fmt.money(m.unit)}</td><td>${m.ref}</td>
      <td>
        <button onclick="deleteMovement('${m.ref}', '${m.sku}', ${m.qty}, ${m.unit})" class="btn">Delete</button>
      </td>
    </tr>`).join('');

    window.deleteMovement = async (ref, sku, qty, unit) => {
      if (!confirm('Are you sure you want to delete this movement? This will affect inventory quantities.')) return;
      // Reverse the quantity effect on the item
      const items = await db.get('items');
      const updatedItems = items.map(i => {
        if (i.sku === sku) {
          if (qty > 0) { // If it was a receipt, reduce quantity
            i.onHand -= qty;
          } else { // If it was an issue, add back quantity
            i.onHand += Math.abs(qty);
          }
          return i;
        }
        return i;
      });
      const movements = await db.get('movements');
      const updatedMovements = movements.filter(m => m.ref !== ref);
  await db.set('items', updatedItems);
  await db.set('movements', updatedMovements);
  await updateInventoryValue();
  await notify({text: `Movement ${ref} deleted.`, type: 'warning', ref: ref});
      await initStock();
    };
  }
}

export { initStock };
