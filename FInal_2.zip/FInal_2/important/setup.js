#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('🚀 Finance and Accounting System Setup');
console.log('=====================================\n');

// Check if .env file exists
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  console.log('✅ .env file already exists');
} else {
  console.log('📝 Creating .env file...');
  
  const envContent = `# Neon Database Configuration
DATABASE_URL=postgresql://neondb_owner:npg_J1gloZUcFQS2@ep-still-truth-a1051s4o-pooler.ap-southeast-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require

# Server Configuration
PORT=1000
NODE_ENV=development

# Optional: Database Pool Configuration
DB_POOL_MIN=2
DB_POOL_MAX=10
`;

  fs.writeFileSync(envPath, envContent);
  console.log('✅ .env file created successfully');
}

// Check if node_modules exists
const nodeModulesPath = path.join(__dirname, 'node_modules');
if (fs.existsSync(nodeModulesPath)) {
  console.log('✅ Dependencies already installed');
} else {
  console.log('📦 Installing dependencies...');
  console.log('   Run: npm install');
}

console.log('\n🎯 Next Steps:');
console.log('1. Run: npm install (if not already done)');
console.log('2. Run: npm start');
console.log('3. Open: http://localhost:1000');
console.log('\n📚 For more information, see README.md');

