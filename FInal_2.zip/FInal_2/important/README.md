# Finance and Accounting System

A comprehensive finance and accounting system with Neon database integration.

## Features

- General Ledger Management
- Accounts Payable & Receivable
- Asset Management
- Tax Management
- Budgeting
- Payroll
- Stock Movement Tracking
- CRM Integration
- Inventory Management
- HR Management
- Project Management

## Setup Instructions

### 1. Install Dependencies

```bash
npm install
```

### 2. Database Configuration

Create a `.env` file in the root directory with your Neon database connection:

```env
# Neon Database Configuration
DATABASE_URL=postgresql://neondb_owner:npg_J1gloZUcFQS2@ep-still-truth-a1051s4o-pooler.ap-southeast-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require

# Server Configuration
PORT=1000
NODE_ENV=development

# Optional: Database Pool Configuration
DB_POOL_MIN=2
DB_POOL_MAX=10
```

### 3. Run the Application

```bash
# Start the server
npm start

# Or for development with auto-restart
npm run dev
```

The application will be available at `http://localhost:3000`

## Database Schema

The system automatically creates the following tables in your Neon database:

- `meta` - Application metadata and settings
- `coa` - Chart of Accounts
- `journals` - General Ledger entries
- `invoices` - Accounts Receivable
- `bills` - Accounts Payable
- `items` - Inventory items
- `movements` - Stock movements
- `customers` - Customer master data
- `vendors` - Vendor master data
- `employees` - Employee master data
- `payruns` - Payroll runs
- `assets` - Fixed assets
- `vatledger` - VAT transactions
- `budgets` - Budget data
- `notifications` - System notifications

## API Endpoints

The server provides RESTful API endpoints for all database operations:

- `GET /api/health` - Health check
- `GET /api/meta` - Get application metadata
- `PUT /api/meta` - Update application metadata
- `GET /api/data/:table` - Get all records from a table
- `POST /api/data/:table` - Create a new record
- `PUT /api/data/:table/:id` - Update a record
- `DELETE /api/data/:table/:id` - Delete a record

## Development

The application is built with:
- **Frontend**: Vanilla JavaScript with ES6 modules
- **Backend**: Node.js with Express.js
- **Database**: PostgreSQL (Neon)
- **Styling**: Custom CSS with modern design

## Demo Data

The system automatically loads demo data on first run, including:
- Chart of Accounts
- Sample inventory items
- Demo customers and vendors
- Sample employee data
- Asset records

## Security Features

- CORS enabled for cross-origin requests
- Helmet.js for security headers
- Input validation and sanitization
- SQL injection protection through parameterized queries
- SSL/TLS encryption for database connections

## Troubleshooting

### Database Connection Issues

1. **Create a `.env` file** in the root directory with your database connection:
   ```env
   DATABASE_URL=postgresql://username:password@host:port/database?sslmode=require
   PORT=1000
   NODE_ENV=development
   ```

2. **Verify your Neon database connection string** is correct
3. **Ensure your Neon database is active** and accessible
4. **Check that SSL mode is properly configured**

### Common Error Fixes

- **400 Bad Request errors**: Usually indicate database connection issues or missing environment variables
- **API call failed errors**: Check that your `.env` file exists and has the correct DATABASE_URL
- **Demo data seeding errors**: Ensure database tables are created properly

### Port Already in Use

If port 1000 is already in use, you can change it in the `.env` file:

```env
PORT=3000
```

### Demo Data Not Loading

If demo data doesn't load automatically:
1. Check the browser console for errors
2. Verify the database connection
3. Check that the `.env` file exists and has correct values
4. Manually trigger a reset from the Settings page

### Quick Setup

1. Copy `env.example` to `.env`
2. Update the DATABASE_URL with your actual database connection string
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:1000` in your browser

## License

MIT License
