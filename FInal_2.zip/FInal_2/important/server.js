// ...existing code...

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';
import pkg from 'pg';
const { Pool } = pkg;

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 1000;

let pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  max: parseInt(process.env.DB_POOL_MAX) || 10,
  min: parseInt(process.env.DB_POOL_MIN) || 2,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// Test database connection
pool.on('connect', () => {
  console.log('Connected to Neon database');
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
  process.exit(-1);
});
// Middleware
// Add route to update meta data by key (default)
app.put('/api/data/meta', async (req, res) => {
  try {
    const data = req.body;
    if (!data || Object.keys(data).length === 0) {
      return res.status(400).json({ error: 'Meta data cannot be null or empty.' });
    }
    const client = await pool.connect();
    // Always update the row with key 'default'
    const result = await client.query(
      'UPDATE meta SET value = $1, updated_at = CURRENT_TIMESTAMP WHERE key = $2 RETURNING *',
      [JSON.stringify(data), 'default']
    );
    client.release();
    if (result.rows.length === 0) {
      // If not exists, insert
      const insertResult = await pool.query(
        'INSERT INTO meta (key, value) VALUES ($1, $2) RETURNING *',
        ['default', JSON.stringify(data)]
      );
      return res.json(insertResult.rows[0]);
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating meta:', error);
    res.status(500).json({ error: 'Database error' });
  }
});
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));
app.use(cors());
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(__dirname));

// Database initialization
async function initializeDatabase() {
  // Always use database, no fallback
  try {
    const client = await pool.connect();
    
    // Create tables if they don't exist
    await client.query(`
      CREATE TABLE IF NOT EXISTS meta (
        id SERIAL PRIMARY KEY,
        key VARCHAR(255) UNIQUE NOT NULL,
        value JSONB NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS coa (
        id SERIAL PRIMARY KEY,
        code VARCHAR(50) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        type VARCHAR(50) NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS journals (
        id SERIAL PRIMARY KEY,
        ref VARCHAR(255) NOT NULL,
        date DATE NOT NULL,
        account VARCHAR(255) NOT NULL,
        memo TEXT,
        debit DECIMAL(15,2) DEFAULT 0,
        credit DECIMAL(15,2) DEFAULT 0
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS invoices (
        id SERIAL PRIMARY KEY,
        ref VARCHAR(255) UNIQUE NOT NULL,
        customer VARCHAR(255) NOT NULL,
        date DATE NOT NULL,
        amount DECIMAL(15,2) NOT NULL,
        status VARCHAR(50) DEFAULT 'pending'
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS bills (
        id SERIAL PRIMARY KEY,
        ref VARCHAR(255) UNIQUE NOT NULL,
        vendor VARCHAR(255) NOT NULL,
        date DATE NOT NULL,
        amount DECIMAL(15,2) NOT NULL,
        status VARCHAR(50) DEFAULT 'pending'
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS items (
        id SERIAL PRIMARY KEY,
        sku VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        avg_cost DECIMAL(15,2) DEFAULT 0,
        on_hand INTEGER DEFAULT 0
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS movements (
        id SERIAL PRIMARY KEY,
        ref VARCHAR(255) NOT NULL,
        sku VARCHAR(255) NOT NULL,
        type VARCHAR(50) NOT NULL,
        qty INTEGER NOT NULL,
        date DATE NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS customers (
        id SERIAL PRIMARY KEY,
        customer_id VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS vendors (
        id SERIAL PRIMARY KEY,
        vendor_id VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS employees (
        id SERIAL PRIMARY KEY,
        employee_id VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        rate DECIMAL(15,2) DEFAULT 0,
        dept VARCHAR(255)
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS payruns (
        id SERIAL PRIMARY KEY,
        period VARCHAR(255) NOT NULL,
        gross DECIMAL(15,2) DEFAULT 0,
        net DECIMAL(15,2) DEFAULT 0,
        date DATE NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS assets (
        id SERIAL PRIMARY KEY,
        code VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        cost DECIMAL(15,2) NOT NULL,
        life INTEGER DEFAULT 0,
        accum DECIMAL(15,2) DEFAULT 0,
        start_date DATE
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS vatledger (
        id SERIAL PRIMARY KEY,
        ref VARCHAR(255) NOT NULL,
        date DATE NOT NULL,
        type VARCHAR(50) NOT NULL,
        amount DECIMAL(15,2) NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS budgets (
        id SERIAL PRIMARY KEY,
        year INTEGER NOT NULL,
        scope VARCHAR(255) NOT NULL,
        category VARCHAR(255) NOT NULL,
        amount DECIMAL(15,2) NOT NULL,
        actual DECIMAL(15,2) DEFAULT 0
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fa_notifications (
        id VARCHAR(255) PRIMARY KEY,
        date TIMESTAMP NOT NULL,
        text TEXT NOT NULL,
        type VARCHAR(50) DEFAULT 'info',
        ref VARCHAR(255),
        read BOOLEAN DEFAULT FALSE
      );
    `);

    // Initialize default meta data if not exists
    const metaResult = await client.query('SELECT * FROM meta WHERE key = $1', ['default']);
    if (metaResult.rows.length === 0) {
      await client.query(
        'INSERT INTO meta (key, value) VALUES ($1, $2)',
        ['default', JSON.stringify({
          vat: 12,
          company: 'Company',
          cash: 0,
          seeded: false
        })]
      );
    }

    client.release();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Database initialization error:', error);
    throw error; // Re-throw to be handled by startServer
  }
}

// API Routes
// Dedicated DELETE route for custom primary keys
app.delete('/api/data/:table/:id', async (req, res) => {
  try {
    const { table, id } = req.params;
    let pk = 'id';
    if (table === 'coa') pk = 'code';
    else if (table === 'items') pk = 'sku';
    else if (table === 'customers') pk = 'customer_id';
    else if (table === 'vendors') pk = 'vendor_id';
    else if (table === 'employees') pk = 'employee_id';
    else if (table === 'assets') pk = 'code';
    else if (table === 'fa_notifications') pk = 'id';
    else if (table === 'sales_orders') pk = 'order_id';
    else if ([
      'invoices', 'bills', 'movements', 'vatledger', 'payruns', 'budgets', 'journals'
    ].includes(table)) pk = 'id';
    const client = await pool.connect();
    const delQuery = `DELETE FROM ${table} WHERE ${pk} = $1 RETURNING *`;
    const delResult = await client.query(delQuery, [id]);
    client.release();
    if (delResult.rows.length === 0) {
      return res.status(404).json({ error: 'Not found' });
    }
    res.json(delResult.rows[0]);
  } catch (error) {
    console.error(`Error deleting from ${req.params.table}:`, error);
    res.status(500).json({ error: 'Database error' });
  }
});
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Generic CRUD operations
app.get('/api/data/:table', async (req, res) => {
  // Always use database, no fallback
  try {
    const { table } = req.params;
    const client = await pool.connect();
    // Removed ORDER BY created_at DESC for compatibility with all tables
    const result = await client.query(`SELECT * FROM ${table}`);
    client.release();
    res.json(result.rows);
  } catch (error) {
    console.error(`Error fetching from ${req.params.table}:`, error);
    res.status(500).json({ error: 'Database error' });
  }
});

app.post('/api/data/:table', async (req, res) => {
  try {
    const { table } = req.params;
    const data = req.body;
    const client = await pool.connect();
    
    // Handle different table structures
    let result;
    switch (table) {
      case 'meta':
        result = await client.query(
          'INSERT INTO meta (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = $2, updated_at = CURRENT_TIMESTAMP RETURNING *',
          [data.key, JSON.stringify(data.value)]
        );
        break;
      case 'coa':
        result = await client.query(
          'INSERT INTO coa (code, name, type) VALUES ($1, $2, $3) ON CONFLICT (code) DO UPDATE SET name = $2, type = $3 RETURNING *',
          [data.code, data.name, data.type]
        );
        break;
      case 'journals':
        result = await client.query(
          'INSERT INTO journals (ref, date, account, memo, debit, credit) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
          [data.ref, data.date, data.account, data.memo, data.debit || 0, data.credit || 0]
        );
        break;
      case 'invoices':
        result = await client.query(
          'INSERT INTO invoices (ref, customer, date, amount, status) VALUES ($1, $2, $3, $4, $5) RETURNING *',
          [data.ref, data.customer, data.date, data.amount, data.status || 'pending']
        );
        break;
      case 'bills':
        result = await client.query(
          'INSERT INTO bills (ref, vendor, date, amount, status) VALUES ($1, $2, $3, $4, $5) RETURNING *',
          [data.ref, data.vendor, data.date, data.amount, data.status || 'pending']
        );
        break;
      case 'items':
        result = await client.query(
          'INSERT INTO items (sku, name, avg_cost, on_hand) VALUES ($1, $2, $3, $4) ON CONFLICT (sku) DO UPDATE SET name = $2, avg_cost = $3, on_hand = $4 RETURNING *',
          [data.sku, data.name, data.avgCost || 0, data.onHand || 0]
        );
        break;
      case 'movements':
        result = await client.query(
          'INSERT INTO movements (ref, sku, type, qty, date) VALUES ($1, $2, $3, $4, $5) RETURNING *',
          [data.ref, data.sku, data.type, data.qty, data.date]
        );
        break;
      case 'customers':
        result = await client.query(
          'INSERT INTO customers (customer_id, name) VALUES ($1, $2) ON CONFLICT (customer_id) DO UPDATE SET name = $2 RETURNING *',
          [data.id, data.name]
        );
        break;
      case 'vendors':
        result = await client.query(
          'INSERT INTO vendors (vendor_id, name) VALUES ($1, $2) ON CONFLICT (vendor_id) DO UPDATE SET name = $2 RETURNING *',
          [data.id, data.name]
        );
        break;
      case 'employees':
        result = await client.query(
          'INSERT INTO employees (employee_id, name, rate, dept) VALUES ($1, $2, $3, $4) ON CONFLICT (employee_id) DO UPDATE SET name = $2, rate = $3, dept = $4 RETURNING *',
          [data.id, data.name, data.rate || 0, data.dept]
        );
        break;
      case 'payruns':
        result = await client.query(
          'INSERT INTO payruns (period, gross, net, date) VALUES ($1, $2, $3, $4) RETURNING *',
          [data.period, data.gross || 0, data.net || 0, data.date]
        );
        break;
      case 'assets':
        result = await client.query(
          'INSERT INTO assets (code, name, cost, life, accum, start_date) VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT (code) DO UPDATE SET name = $2, cost = $3, life = $4, accum = $5, start_date = $6 RETURNING *',
          [data.code, data.name, data.cost, data.life || 0, data.accum || 0, data.start]
        );
        break;
      case 'vatledger':
        result = await client.query(
          'INSERT INTO vatledger (ref, date, type, amount) VALUES ($1, $2, $3, $4) RETURNING *',
          [data.ref, data.date, data.type, data.amount]
        );
        break;
      case 'budgets':
        if (data.created_at) {
          result = await client.query(
            'INSERT INTO budgets (year, scope, category, amount, actual, created_at, description, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
            [
              data.year,
              data.scope,
              data.category,
              data.amount,
              data.actual || 0,
              data.created_at,
              data.description || '',
              data.status || 'pending'
            ]
          );
        } else {
          result = await client.query(
            'INSERT INTO budgets (year, scope, category, amount, actual, description, status) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
            [
              data.year,
              data.scope,
              data.category,
              data.amount,
              data.actual || 0,
              data.description || '',
              data.status || 'pending'
            ]
          );
        }
        break;
      case 'fa_notifications':
        result = await client.query(
          'INSERT INTO fa_notifications (id, date, text, type, ref, read) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
          [data.id, data.date, data.text, data.type || 'info', data.ref, data.read || false]
        );
        break;
      default:
        throw new Error(`Unknown table: ${table}`);
    }
    
    client.release();
    res.json(result.rows[0]);
  } catch (error) {
    console.error(`Error inserting into ${req.params.table}:`, error);
    res.status(500).json({ error: 'Database error' });
  }
});

app.put('/api/data/:table/:id', async (req, res) => {
  try {
    const { table, id } = req.params;
    const data = req.body;
    const client = await pool.connect();

    // Determine primary key column
    let pk = 'id';
    if (table === 'coa') pk = 'code';
    else if (table === 'items') pk = 'sku';
    else if (table === 'customers') pk = 'customer_id';
    else if (table === 'vendors') pk = 'vendor_id';
    else if (table === 'employees') pk = 'employee_id';
    else if (table === 'assets') pk = 'code';
    else if (table === 'fa_notifications') pk = 'id';
    else if ([
      'invoices', 'bills', 'movements', 'vatledger', 'payruns', 'budgets', 'journals'
    ].includes(table)) pk = 'id';

    // Special handling for budgets: only allow updating valid columns
    let allowedCols = null;
    if (table === 'budgets') {
      allowedCols = ['year','scope','category','amount','actual','created_at','description','status'];
    }

    // Remove _delete pseudo-field if present
    if (data._delete) {
      const delQuery = `DELETE FROM ${table} WHERE ${pk} = $1 RETURNING *`;
      const delResult = await client.query(delQuery, [id]);
      client.release();
      return res.json(delResult.rows[0]);
    }

    // Build update query
    let keys = Object.keys(data);
    let values = Object.values(data);
    if (allowedCols) {
      // Only allow updating columns that exist in the table
      keys = keys.filter(k => allowedCols.includes(k));
      values = keys.map(k => data[k]);
    }
    if (keys.length === 0) throw new Error('No fields to update');
    const setClause = keys.map((k, i) => `${k} = $${i + 1}`).join(', ');
    const query = `UPDATE ${table} SET ${setClause} WHERE ${pk} = $${keys.length + 1} RETURNING *`;
    const result = await client.query(query, [...values, id]);
    client.release();
    res.json(result.rows[0]);
  } catch (error) {
    console.error(`Error updating ${req.params.table}:`, error);
    res.status(500).json({ error: 'Database error' });
  }
});

// Start the server (must be at the end, after all code and after 'pool' is defined)
initializeDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}).catch((err) => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});